# IMPLEMENTATION_STATUS

Fortschritts- und Entscheidungsprotokoll der Camunda-7-Demoanwendung
**insurance-correspondence-demo** (Versicherungskorrespondenz).

Diese Datei wird nach jeder Phase aktualisiert (Auftrag 0.2). Sie dokumentiert
Phasen, Annahmen, ausgeführte Befehle, Testergebnisse, offene Punkte und
bekannte Einschränkungen.

---

## Umgebung (Bestandsaufnahme, Phase 0)

Verifiziert am 2026-06-20 auf Windows 11 Home (Zielplattform laut Auftrag 2.1: Win 11 Pro,
funktional identisch für diese Demo). Tooling entspricht exakt der mitgelieferten
PDF-Anleitung *Camunda 7 Schulungsumgebung – Stand 27.05.2026*:

| Komponente | Erwartet (PDF) | Gefunden | Status |
|---|---|---|---|
| Java | MS OpenJDK 17.0.19 LTS | 17.0.19+10-LTS | OK |
| Maven | 3.9.16 | 3.9.16 | OK |
| Git | 2.54.0 | 2.54.0.windows.1 | OK |
| Ports 8080–8082 | frei | alle frei | OK |
| Toolroot | `C:\Training` | vorhanden | OK |

- `JAVA_HOME` = `C:\Users\olive\AppData\Local\Programs\Microsoft\jdk-17.0.19.10-hotspot`
- `MAVEN_HOME` = `C:\Training\tools\apache-maven-3.9.16`
- Projektverzeichnis: `C:\Training\workspace\insurance-correspondence-demo`
- **Keine globale Installation nötig** (Auftrag 0.5 erfüllt). Eine `SETUP_WINDOWS.md`
  als Stopp-Punkt war damit nicht erforderlich; die vorhandene PDF deckt das Setup ab.

---

## Phasenüberblick

| Phase | Inhalt | Status |
|---|---|---|
| 0 | Projektgerüst, Maven Wrapper, Status-Doku, ADRs | **abgeschlossen** |
| 1 | Orchestrator: Webapps, REST, H2, Demo-Benutzer, Minimalprozess | **abgeschlossen** |
| 2 | shared-contracts, Simulator, Worker, Happy Path bis PDF | **abgeschlossen** |
| 3 | DMN-Modelle, Degradation, Tests | **abgeschlossen** |
| 4 | User Task, Form, Gruppe, manuelle Entscheidungen | **abgeschlossen** |
| 5 | Receive Task, Timer, Callback-Inbox, Restart-Nachweis | **abgeschlossen** |
| 6 | Delivery-Outbox, Idempotenz, Duplicate Callback, Reconciliation | **abgeschlossen** |
| 7 | Batch-Planer, Backpressure, Load Generator, PostgreSQL-Profil | **abgeschlossen** |
| 8 | Incident-Demo, Cockpit-Leitfaden, Metrics, History TTL | **abgeschlossen** |
| 9 | Doku, PowerShell-Skripte, Formatierung, Security, Final Verify | **abgeschlossen** |

---

## Phase 0 — Projektgerüst

**Ziel / Gate:** Multi-Modul-Struktur steht, Maven Wrapper auf 3.9.16 gepinnt,
leerer `mvnw clean verify` läuft erfolgreich durch.

### Angelegte Struktur
```
insurance-correspondence-demo/
├─ pom.xml                      (Parent, packaging=pom, BOM-Importe, Enforcer, Spotless, JaCoCo)
├─ mvnw / mvnw.cmd / .mvn/      (Maven Wrapper, gepinnt auf 3.9.16)
├─ shared-contracts/            (DTOs, Enums, Verträge – kein Engine-Code)
├─ orchestrator-app/            (Camunda Engine, Webapps, REST – Port 8080)
├─ worker-app/                  (External Task Client – Port 8081)
├─ external-systems-simulator/  (Quellsysteme + Output-Management – Port 8082)
├─ load-generator/              (Last-CLI)
├─ docs/adr/                    (Architecture Decision Records)
├─ scripts/                     (PowerShell)
└─ requests/                    (demo.http u.a.)
```

### Getroffene Entscheidungen (siehe ADRs)
- Projektort `C:\Training\workspace\…` statt Home-Verzeichnis: nutzt die etablierte
  Workspace-Konvention der Schulungs-PDF (Maven/Tools liegen unter `C:\Training`).
- Versionen fest gepinnt: Spring Boot 3.5.5, Camunda 7.24.0, Java 17, OpenPDF 1.3.43.
- Formatierung über Spotless (palantir-java-format), Coverage über JaCoCo.

### Ausgeführte Befehle
- `mvn -N wrapper:wrapper -Dmaven=3.9.16` → BUILD SUCCESS (Wrapper erzeugt).
- `.\mvnw.cmd -B clean verify` → **BUILD SUCCESS** (alle 6 Reactor-Module).
- `git init` + `git add -A` → 18 Dateien gestaged (noch kein Commit).

### Testergebnisse (Gate)
- Reactor: insurance-correspondence-demo, shared-contracts, orchestrator-app,
  worker-app, external-systems-simulator, load-generator → alle SUCCESS.
- Enforcer (Maven [3.9,4) / Java [17,18)) erfüllt, Spotless-Check grün (noch keine
  Java-Dateien), JaCoCo-Agent aktiv (noch keine Tests).
- Gesamtzeit ~27 s.

### Offene Punkte / Einschränkungen
- Module sind in Phase 0 bewusst leer; Inhalte folgen phasenweise.
- Spotless-Formatter (palantir-java-format 2.39.0) ist erst ab Phase 1 mit echten
  Java-Dateien wirksam getestet; ggf. Versionsanpassung nötig.
- `.gitattributes` ergänzt (mvnw=LF, *.cmd/*.ps1=CRLF); Commit auf Wunsch des Nutzers.

**Phase 0 abgeschlossen am 2026-06-20.**

---

## Phase 1 — Orchestrator

**Ziel / Gate:** Orchestrator startet mit Camunda Webapps, REST und persistentem H2;
Login in Cockpit/Tasklist möglich; Smoke-Test grün.

### Umgesetzt
- `orchestrator-app` als Spring-Boot-3.5.5-Anwendung mit
  `camunda-bpm-spring-boot-starter-webapp` + `-rest` (Camunda 7.24.0).
- Profile: `application.yaml` (gemeinsam, Bindung 127.0.0.1:8080, History audit,
  Actuator health/metrics/prometheus, History-TTL-Default P30D, Resource-Whitelist
  inkl. Bindestrich), `application-demo.yaml` (persistentes H2 unter `var/db`,
  Admin `demo/demo`), `application-test.yaml` (H2 in-memory, Job-Executor aus).
- `DemoIdentityInitializer` (`@Profile({"demo","test"})`, `@PostConstruct`,
  idempotent): Gruppe `document-ops`, Benutzer `ops/ops`, Mitgliedschaft.
- Minimaler deploybarer Prozess `smoke_process` (`smoke-process.bpmn`, mit BPMN-DI,
  `historyTimeToLive=P30D`).
- Smoke-Test `OrchestratorSmokeTest` (SpringBootTest, Profil test).

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd -pl orchestrator-app -am clean verify` → **BUILD SUCCESS**,
  2 Tests grün (Engine + Deployment, Demo-Identitäten).
- Realer Start aus Projektwurzel (`java -jar orchestrator-app.jar`, Demo-Profil):
  - Health `UP` nach ~6 s.
  - `GET /engine-rest/engine` → `default`.
  - `GET /engine-rest/process-definition?key=smoke_process` → v1 deployed.
  - `GET /camunda/app/welcome/default/` → HTTP 200 (Webapps erreichbar).
  - `user demo`=1, `user ops`=1, `group document-ops`=1.
  - Listening-Socket ausschließlich `127.0.0.1:8080`.
  - Danach kontrolliert gestoppt, Port frei.

### Behobene Probleme (dokumentiert für Reproduzierbarkeit)
1. Fehlender `PlatformTransactionManager` → `spring-boot-starter-jdbc` ergänzt.
2. `PostDeployEvent` feuert ohne ProcessApplication nicht → Initializer auf
   `@PostConstruct` (injizierte, bereits gestartete `ProcessEngine`) umgestellt.
3. Camunda lehnt Bindestrich in Resource-IDs ab → `generalResourceWhitelistPattern`
   auf `[a-zA-Z0-9-]+` gesetzt (Gruppe `document-ops`).
4. H2 unterstützt `AUTO_SERVER=TRUE && DB_CLOSE_ON_EXIT=FALSE` nicht → `AUTO_SERVER`
   entfernt (Orchestrator ist alleiniger DB-Nutzer; Worker geht über REST).

### Offene Punkte / Einschränkungen
- Webapp-Authorization ist im Demo-Profil bewusst nicht hart erzwungen; Login mit
  `demo/demo` (admin) und `ops/ops` funktioniert. Produktiv würde Authorization
  aktiviert und feingranular vergeben.
- `smoke_process` ist ein Platzhalter zur Engine-/Deployment-Demonstration; der
  fachliche Kernprozess `document_fulfillment` folgt ab Phase 2.

**Phase 1 abgeschlossen am 2026-06-20.**

---

## Phase 2 — shared-contracts, Simulator, Worker, Happy Path bis PDF

**Ziel / Gate:** vollständiger Happy Path bis zum echten PDF; automatisierter
End-to-End-Happy-Path.

### Umgesetzt
- **shared-contracts**: 9 Enums, Records (DocumentRequest, DeliveryResultCallback,
  CustomerData/ContractData/TariffData, DeliveryDispatchRequest/Response,
  ProviderStatusResponse), `ProcessConstants` (Schlüssel/Messages/Topics/Variablen),
  `DemoFixtures`, Validierungstest.
- **external-systems-simulator** (Port 8082): Quellsysteme (Kunde/Vertrag/Tarif) mit
  deterministischer Fehlerprofil-Behandlung, Output-Management mit idempotenter
  Dispatch-Annahme (dedup je documentJobId) + Statusendpunkt für Reconciliation,
  `AttemptTracker` für transiente Fehler. Integrationstest (4 Fälle).
- **worker-app** (Port 8081): `ExternalTaskClient` gegen `/engine-rest`, Handler
  `load-customer/contract/tariff-data`, `render-document` (echtes PDF via OpenPDF,
  SHA-256, Pfad-Normalisierung), `dispatch-document`. Re-Fetch der Inhalte beim Render
  hält PII aus Prozessvariablen. Unit-Test (PDF-Bytes, Hash, Pfadsicherheit).
- **orchestrator**: `document-fulfillment.bpmn` (Happy-Path mit DI: MessageStart →
  normalize (Delegate) → 3 External Tasks → render → dispatch → finalize (Delegate) →
  End), JavaDelegates, REST (`POST/GET /api/document-requests` idempotent per Business
  Key, `POST /api/demo/events`), RFC-7807-Fehler. BPMN-Happy-Path-Prozesstest.

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` (voller Reactor) → **BUILD SUCCESS**, alle Tests grün
  (shared-contracts 3, simulator 4, worker 3, orchestrator 3 inkl.
  `DocumentFulfillmentHappyPathTest` → FULLY_DISPATCHED).
- Realer 3-App-E2E (Start aller drei Jars, `POST /api/document-requests`):
  - HEALTH orchestrator/simulator/worker = UP.
  - outcome **FULLY_DISPATCHED**, Status COMPLETED.
  - echtes PDF unter `var/documents/DOC-E2E-1/document.pdf` (1362 B, Signatur `%PDF-`).
  - idempotenter Doppel-POST → `duplicate=true`, kein zweiter Prozess.
  - Nebenbefund: die Instanz überlebte einen Orchestrator-Neustart im persistenten H2
    und wurde fortgesetzt (Vorgriff auf Phase 5).

### Behobene Probleme
- Jackson deserialisierte Records zu `null` → `-parameters` im Compiler-Plugin global.
- External Task Client benötigt JAXB zur Laufzeit → `jakarta.xml.bind-api` +
  `jaxb-runtime` im Worker.

### Offene Punkte / Einschränkungen
- DMN-Entscheidungen (Variante/Kanal/Vollständigkeit) folgen in Phase 3; bis dahin
  setzen Worker/Delegates sinnvolle Defaults (deliveryChannel aus Kundenpräferenz,
  templateId aus documentType).
- Idempotenter Start nutzt aktuell den Business Key; die Unique-Constraint-Absicherung
  über `document_request_registry` (Race zweier paralleler Starts) folgt mit Flyway in
  Phase 5/6.
- Receive Task / Timer / Inbox noch nicht im Prozess (Phase 5); der Happy Path endet
  nach Dispatch direkt mit dem finalen Outcome.

**Phase 2 abgeschlossen am 2026-06-20.**

---

## Phase 3 — DMN-Modelle, Degradation, Tests

**Ziel / Gate:** vollständige DMN-Tests; Outcomes FULLY_DISPATCHED und
DEGRADED_DISPATCHED erreichbar.

### Umgesetzt
- 3 DMN-Tabellen (Hit Policy FIRST, je Default-Regel, `historyTimeToLive=P30D`):
  - `data-completeness.dmn` → completenessClass, degraded, degradationAllowed,
    missingRequiredFields, degradationReasons.
  - `document-variant.dmn` → templateId, legalTextKey, attachmentKeys.
  - `delivery-policy.dmn` → deliveryChannel, requiresTechnicalAck,
    acknowledgementTimeout, maxStatusChecks, deliveryPriority.
- Kernprozess erweitert: Business Rule Tasks evalCompleteness/evalVariant/evalPolicy,
  **asyncBefore an evalCompleteness** (bewusste TX-Grenze, Auftrag 4.3), Exclusive
  Gateway auf completenessClass (MANUAL_REQUIRED → Platzhalter-End, ersetzt in Phase 4).
- `MapResultFlattenerListener` (klassenbasiert, camunda:field): mappt das
  singleResult-Map der Business Rule Tasks auf einzelne Prozessvariablen.

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` (voller Reactor) → **BUILD SUCCESS**.
- `DmnDecisionTest` (parametrisiert): data-completeness 7 Fälle inkl. FIRST-Vorrang
  und Default; document-variant 5; delivery-policy 3.
- `DocumentFulfillmentProcessTest`: FULLY_DISPATCHED, **DEGRADED_DISPATCHED**,
  MANUAL_REQUIRED → Platzhalter (kein Outcome).
- Realer 3-App-E2E: `failureProfile=HAPPY` → FULLY_DISPATCHED;
  `failureProfile=OPTIONAL_DATA_MISSING` → **DEGRADED_DISPATCHED**; beide PDFs erzeugt.

### Offene Punkte / Einschränkungen
- MANUAL_REQUIRED endet in Phase 3 an einem Platzhalter-Endereignis; die User Task
  „Dokumentauftrag manuell klären" folgt in Phase 4.
- document-variant nutzt documentType+language; Produkt/Bundesland als dokumentierte
  Erweiterung (exercises.md, Phase 9).

**Phase 3 abgeschlossen am 2026-06-20.**

---

## Phase 4 — User Task, Form, manuelle Entscheidungen

**Ziel / Gate:** Tasklist-Demo + Prozesstests für Retry, Reduced und Cancel.

### Umgesetzt
- User Task „Dokumentauftrag manuell klären: ${documentJobId}" (dynamischer Name),
  Candidate Group `document-ops`, Generated Task Form: zeigt documentJobId,
  documentType, manualReason, missingRequiredFields, degradationReasons,
  deliveryResultStatus; erfasst manualResolution (RETRY_ENRICHMENT/DELIVER_REDUCED/
  CANCEL_REQUEST), manualComment, correctedEmail, correctedPostalAddress.
- `ManualReviewTaskListener` (create: setzt manualReason; complete: validiert
  Entscheidung, lehnt DELIVER_REDUCED ab, wenn `degradationAllowed=false`).
- Routing-Gateway gw_manual: CANCEL → cancelOutcome (CANCELLED_AFTER_MANUAL_REVIEW);
  RETRY → zurück zu loadCustomer; DELIVER_REDUCED → markDegraded → Variante/Politik/
  Render/Dispatch. Delegates `cancelOutcomeDelegate`, `markDegradedDelegate`.
- Simulator/Worker: `MANDATORY_DATA_MISSING` lässt nur die Pflicht-Zieladresse weg;
  `LoadCustomerDataHandler` berücksichtigt correctedEmail/-PostalAddress → RETRY nach
  Korrektur wird vollständig.

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` → **BUILD SUCCESS**; `DocumentFulfillmentProcessTest`:
  User Task erreicht, **CANCEL → CANCELLED_AFTER_MANUAL_REVIEW**, **RETRY → FULLY**,
  **DELIVER_REDUCED abgelehnt** bei degradationAllowed=false, **DELIVER_REDUCED erlaubt
  → DEGRADED_DISPATCHED**.
- Realer Nachweis über Engine-REST (laufende App, User Task geclaimt/abgeschlossen):
  - `MANDATORY_DATA_MISSING` → User Task erscheint; CANCEL_REQUEST →
    **CANCELLED_AFTER_MANUAL_REVIEW**.
  - RETRY_ENRICHMENT + correctedEmail → erneute Anreicherung → **FULLY_DISPATCHED**.

### Offene Punkte / Einschränkungen
- Authorization bleibt im Demo-Profil offen; `ops` kann die Aufgabe in Tasklist
  claimen/bearbeiten (Filter „Alle Aufgaben"). Produktiv würde Authorization aktiviert.
- DELIVER_REDUCED ist über den MANUAL_REQUIRED-Eintrag (degradationAllowed=false) im
  Normalfall nicht erlaubt; erlaubte Degradation an der User Task entsteht erst über die
  späteren Provider-/Timeout-Eintritte (Phase 5/6).

**Phase 4 abgeschlossen am 2026-06-20.**

---

## Phase 5 — Receive Task, Timer, Callback-Inbox, Restart

**Ziel / Gate:** reproduzierbarer Neustartnachweis am Wait State.

### Umgesetzt
- Kernprozess: Receive Task „Auf technische Annahme warten" (Message
  DeliveryResultReceived, Korrelation über Business Key) + **interrupting Timer
  Boundary Event** (`${acknowledgementTimeout}`, Demo PT15S) →
  `reconcile-delivery` External Task → Gateway: ACCEPTED→Abschluss, PENDING &
  statusCheckCount<maxStatusChecks→Increment→zurück zur Receive Task,
  sonst→User Task. `incrementStatusCheckDelegate`.
- **Inbox** (Auftrag 9.4): JPA-Entity `delivery_callback_inbox` via **Flyway** (V1),
  `POST /api/delivery-results`. Speicherung (`InboxStorage`) und Korrelation
  (`MessageCorrelator`) in **getrennten Transaktionen** → robust gegen fehlende
  Warteinstanz und parallelen Job-Executor; `InboxCorrelationScheduler` versucht
  PENDING-Einträge erneut. Doppelte Callbacks (Unique `callback_event_id`) idempotent.
- Worker `reconcile-delivery`-Handler (fragt Providerstatus beim Simulator ab).
- Simulator `CallbackPublisher`: sendet die technische Annahme zeitversetzt und
  deterministisch je Fehlerprofil (HAPPY/DELAYED/REJECTED/TIMEOUT/DUPLICATE), mit
  Backoff-Retry (überbrückt einen kurz nicht erreichbaren Orchestrator).
- JPA `ddl-auto=validate`, Flyway `baseline-on-migrate` (akzeptiert vorhandenes
  Camunda-Schema).

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` → **BUILD SUCCESS**; Prozesstests u. a.:
  Happy via Inbox-Korrelation → FULLY; **Duplicate-Callback** → genau ein Fortschritt;
  **Timeout → Reconcile PENDING → Rückschleife → ACCEPTED** → FULLY;
  **Rejection** → User Task.
- **Realer Neustartnachweis** (nur Orchestrator neu gestartet, Worker/Simulator laufen):
  - Receive Task: `DELIVERY_TIMEOUT` → Prozess wartet an receiveResult → Orchestrator
    gestoppt + neu gestartet → **status=ACTIVE** (Zustand überlebt) → gepufferter
    ACCEPTED-Callback → **FULLY_DISPATCHED**.
  - User Task: `MANDATORY_DATA_MISSING` → User Task → Neustart → **Task weiterhin
    vorhanden** → CANCEL → **CANCELLED_AFTER_MANUAL_REVIEW**.

### Offene Punkte / Einschränkungen
- Delivery-Outbox des Workers (atomar mit Delivery Request) + render-/dispatch-Idempotenz
  über Worker-Tabellen folgen in Phase 6; aktuell dedupliziert der Simulator den Dispatch.

**Phase 5 abgeschlossen am 2026-06-20.**

---

## Phase 6 — Delivery-Outbox, Idempotenz, Reconciliation

**Ziel / Gate:** Tests für verlorenes Complete-Response, doppelte Provideranforderung,
Callback-Dublette.

### Umgesetzt
- Worker-DB (eigene H2, Flyway V1): `document_artifact`, `delivery_request`,
  `outbox_event` (jeweils `document_job_id`/`delivery_request_id` eindeutig).
- `DeliveryOutboxService.createOrGet`: schreibt Delivery Request + Outbox Event in
  **einer lokalen Transaktion**, idempotent je documentJobId. dispatch-document
  schließt den External Task erst nach dem Commit ab (Auftrag 9.5/9.6).
- `OutboxPublisher` (@Scheduled, abschaltbar): sendet NEW-Outbox-Einträge an den
  Simulator (HTTP außerhalb der DB-Transaktion), markiert nach Annahme SENT;
  Simulator dedupliziert → erneutes Senden unschädlich.
- render-document idempotent: vorhandenes `document_artifact` wird wiederverwendet
  (kein zweites Rendern).
- reconcile-delivery bereits aus Phase 5.

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` → **BUILD SUCCESS**; `DeliveryOutboxIdempotencyTest`:
  wiederholter Dispatch → genau **ein** Delivery Request + **ein** Outbox-Eintrag
  (verlorenes Complete-Response-Szenario); wiederholtes Render → **ein** Artefakt.
- Realer 3-App-E2E: HAPPY läuft **über die Outbox** → FULLY_DISPATCHED;
  DUPLICATE_CALLBACK → FULLY_DISPATCHED (genau ein Fortschritt, Inbox-Dedup);
  DELIVERY_REJECTED → User Task.

**Phase 6 abgeschlossen am 2026-06-20.**

---

## Phase 7 — Batch-Planer, Backpressure, Load Generator, PostgreSQL

**Ziel / Gate:** kleiner Lastlauf mit konsistenter Ergebnisbilanz.

### Umgesetzt
- `document-batch-planner.bpmn`: Timer Start (täglich 03:00) + manueller REST-Start;
  `plan-batch` (External Task) → Backpressure-Schleife (`backpressureCheckDelegate`
  zählt aktive Instanzen, Timer PT3S bei `maxInFlight`) → `publish-batch-page`
  (External Task) → weitere Seiten/Ende. **Keine** Multi-Instance/Riesen-Collection.
- Worker `plan-batch` + `publish-batch-page`: veröffentlicht Seiten unabhängiger
  Aufträge über `OrchestratorClient` → idempotentes `POST /api/document-requests`
  (deterministische documentJobIds → Re-Run je batchId ohne Duplikate).
- REST `POST /api/demo/batches`, `GET /api/demo/batches/{batchId}` (BatchStatusService:
  planned/started/active/manual/incident/fully/degraded/cancelled).
- `load-generator` (CLI, JDK-HttpClient): Modi event/batch/mixed; count/rate/concurrency/
  seed/failureProfile/batchSize; misst Durchsatz, Dubletten, HTTP-Fehler, p50/p95/p99;
  Bericht nach `var/reports/`.
- `postgres`-Profil (Orchestrator + Worker: Treiber + Flyway-Postgres-Modul, Config aus
  Umgebungsvariablen, größere Pools, eindeutige WORKER_ID) und `load`-Profil
  (METADATA_ONLY, kürzere Latenz). `docs/load-test.md`.

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` → **BUILD SUCCESS** (LoadMetricsTest: Perzentile/Zählung).
- Realer Lauf: `POST /api/demo/batches count=20 HAPPY` →
  **started=20, active=0, fullyDispatched=20, planned=20** → Bilanz konsistent
  (`started == fully + degraded + cancelled + active + manual`).
- `load-generator --mode=event --count=10 --rate=5` → 10 angefordert, 10 akzeptiert,
  0 Dubletten, 0 HTTP-Fehler, p50≈45 ms, p95≈201 ms.

### Offene Punkte / Einschränkungen
- Großer 30.000er-Lauf in dieser Umgebung **nicht** ausgeführt (kein PostgreSQL/Docker);
  Generator + postgres-Profil sind dafür vollständig vorbereitet (Auftrag 15.8 / 24.13).

**Phase 7 abgeschlossen am 2026-06-20.**

---

## Phase 8 — Incident-Demo, Metrics, MDC, History TTL

**Ziel / Gate:** reproduzierbarer Incident mit erfolgreichem Retry nach Fehlerbehebung.

### Umgesetzt
- Fehlerklassifizierung im `render-document`-Handler (Auftrag 8.10.2): bei
  `PERMANENT_RENDER_FAILURE` dekrementiert `handleFailure` die Retries bis 0 → Incident.
- Micrometer-Zähler (Auftrag 17.2): `documents.started`, `documents.dispatched{outcome}`,
  `documents.incidents`, `worker.render.failures`, `worker.outbox.attempts`,
  `callback.duplicates`. `/actuator/prometheus` aktiv (micrometer-registry-prometheus).
- MDC-Logging (Auftrag 17.1): `documentJobId`/`externalTaskId` in den Worker-Handlern,
  `logback-spring.xml`-Pattern; keine PII im Log.
- History: TTL P30D auf allen BPMN/DMN; History-Cleanup-Fenster 00:00–06:00 (Auftrag 14.5).
- External-Task-Client: kürzere `async-response-timeout`/`lock-duration` + Backoff-Obergrenze,
  damit Retries zeitnah greifen.

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` → **BUILD SUCCESS**.
- Realer Incident-E2E (`failureProfile=PERMANENT_RENDER_FAILURE`):
  - Worker-Zähler `documents.incidents=1` + Engine-Incident (≈4 s) → **reproduzierbarer
    Incident**.
  - Fix: Prozessvariable `failureProfile=HAPPY` + External-Task-Retries via REST hochgesetzt
    → Incident **aufgelöst** (engine-incidents danach 0) → **FULLY_DISPATCHED**.

### Hinweis (Lehre aus dem Test)
- Die Incident-Erkennung im PowerShell-Smoke nutzt `| Where-Object { $_.id }`, weil
  `@($null).Count` in PowerShell fälschlich 1 ergibt (leere REST-Antwort). Der
  Worker-Zähler `documents.incidents` ist das autoritative Signal.

**Phase 8 abgeschlossen am 2026-06-20.**

---

## Phase 9 — Doku, Skripte, Security, Final Verify

**Ziel / Gate:** Definition of Done (Abschnitt 24).

### Umgesetzt
- `README.md` + `docs/`: architecture (Mermaid), process-model, transaction-boundaries,
  error-handling, idempotency-outbox-reconciliation, trainer-guide, exercises, load-test,
  camunda8-outlook; ADRs.
- 10 PowerShell-Skripte (`scripts/`): setup-check, build, start-demo, stop-demo, reset-demo,
  run-smoke, run-manual-review-demo, run-incident-demo, run-restart-demo, run-load +
  `_common.ps1`. `requests/demo.http`. `/api/demo/summary`.
- Security-Review (Timeouts, Pfad-Normalisierung, keine Secrets, Validation/RFC-7807,
  feste Versionen) — Zusammenfassung in `FINAL_REPORT.md`.

### Ausgeführte Befehle & Ergebnisse
- `.\mvnw.cmd clean verify` → **BUILD SUCCESS** (alle Module/Tests).
- Vollständiger Skript-Durchlauf gegen die laufende Demo:
  start-demo (3× UP) → run-smoke (FULLY + PDF) → run-incident-demo -AutoFix (Incident → FULLY,
  0 verbleibend) → run-restart-demo (ACTIVE überlebt → FULLY) → run-manual-review-demo (User Task)
  → run-load 20 (Bilanz konsistent, Generator 20/20, 0 Fehler) → stop-demo (sauber).

## Definition of Done (Auftrag 24)

| # | Kriterium | Status |
|---|---|---|
| 24.1 | `mvnw clean verify` ohne externe Cloud-Dienste | ✅ |
| 24.2 | `start-demo.ps1` startet alle Dienste, Health grün | ✅ |
| 24.3 | Cockpit/Tasklist/Admin erreichbar; demo/demo, ops/ops | ✅ |
| 24.4 | Einzelereignis → echtes PDF, FULLY_DISPATCHED | ✅ |
| 24.5 | Optionaler Datenfehler → DEGRADED_DISPATCHED | ✅ |
| 24.6 | Pflichtdatenmangel → User Task, alle 3 Entscheidungen | ✅ |
| 24.7 | Technische Annahme async über Receive Task + Korrelation | ✅ |
| 24.8 | Timerpfad → Reconciliation (ggf. User Task) | ✅ |
| 24.9 | Neustart während Receive Task **und** User Task ohne Zustandsverlust | ✅ |
| 24.10 | Doppelter Start/External Task/Callback → keine doppelten Seiteneffekte | ✅ |
| 24.11 | Technischer Fehler → Incident, nach Behebung weitergeführt | ✅ |
| 24.12 | Batch-Planer: unabhängige Instanzen, Seiten, Backpressure, keine Multi-Instance | ✅ |
| 24.13 | Load Generator: kleiner Lauf; für 20–30k im postgres-Profil konfigurierbar | ✅ (Großlauf nicht ausgeführt, vorbereitet) |
| 24.14 | Keine Binärdokumente/große Listen als Prozessvariablen | ✅ |
| 24.15 | Alle BPMN/DMN mit History TTL | ✅ |
| 24.16 | README, Trainerleitfaden, Transaktions-/Fehler-/Lastkonzept, Übungen, C8-Ausblick, ADRs | ✅ |

**Phase 9 abgeschlossen am 2026-06-20. Definition of Done erfüllt.**
