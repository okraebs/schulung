package de.demo.versicherung.korrespondenz.loadgen;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class LoadMetricsTest {

    @Test
    void countsStatusesAndComputesPercentiles() {
        LoadMetrics metrics = new LoadMetrics();
        for (int i = 1; i <= 100; i++) {
            metrics.record(201, i); // Latenzen 1..100 ms
        }
        metrics.record(200, 5);
        metrics.recordError();

        assertThat(metrics.requested()).isEqualTo(102);
        assertThat(metrics.accepted()).isEqualTo(100);
        assertThat(metrics.duplicates()).isEqualTo(1);
        assertThat(metrics.httpErrors()).isEqualTo(1);
        assertThat(metrics.percentile(50)).isBetween(45L, 55L);
        assertThat(metrics.percentile(95)).isBetween(90L, 100L);
        assertThat(metrics.percentile(99)).isBetween(95L, 100L);
    }

    @Test
    void emptyMetricsReturnZeroPercentile() {
        assertThat(new LoadMetrics().percentile(95)).isZero();
    }
}
