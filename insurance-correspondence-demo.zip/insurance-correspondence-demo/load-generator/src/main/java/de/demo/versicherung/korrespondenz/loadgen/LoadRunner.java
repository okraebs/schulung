package de.demo.versicherung.korrespondenz.loadgen;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.demo.versicherung.korrespondenz.contracts.DocumentRequest;
import de.demo.versicherung.korrespondenz.contracts.DocumentType;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.RequestSource;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Treibt die Last (Auftrag 15.3): Modi {@code event}, {@code batch}, {@code mixed}. Misst Durchsatz,
 * Dubletten, HTTP-Fehler und p50/p95/p99 der Einreichungslatenz. Verändert die Engine-DB nie direkt.
 */
@Component
public class LoadRunner implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(LoadRunner.class);

    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    private final HttpClient http =
            HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    @Override
    public void run(String... args) throws Exception {
        Map<String, String> opts = parse(args);
        if (opts.isEmpty() || "help".equals(opts.get("mode"))) {
            printUsage();
            return;
        }
        String mode = opts.getOrDefault("mode", "event");
        String orchestrator = opts.getOrDefault("orchestrator", "http://127.0.0.1:8080");
        int count = intOpt(opts, "count", 20);
        int rate = intOpt(opts, "rate", 3);
        int concurrency = intOpt(opts, "concurrency", 4);
        long seed = Long.parseLong(opts.getOrDefault("seed", "42"));
        FailureProfile profile = FailureProfile.valueOf(opts.getOrDefault("failureProfile", "HAPPY"));
        int batchSize = intOpt(opts, "batchSize", 25);

        log.info(
                "Lastlauf mode={} count={} rate={}/s concurrency={} seed={} profile={}",
                mode,
                count,
                rate,
                concurrency,
                seed,
                profile);

        LoadMetrics metrics = new LoadMetrics();
        Instant start = Instant.now();
        switch (mode) {
            case "event" -> runEvents(orchestrator, count, rate, concurrency, seed, profile, metrics);
            case "batch" -> runBatch(orchestrator, count, batchSize, profile);
            case "mixed" -> {
                runEvents(orchestrator, count / 2, rate, concurrency, seed, profile, metrics);
                runBatch(orchestrator, count - count / 2, batchSize, profile);
            }
            default -> printUsage();
        }
        long elapsedMs = Math.max(1, Duration.between(start, Instant.now()).toMillis());
        writeReport(mode, count, rate, seed, profile, metrics, elapsedMs);
    }

    private void runEvents(
            String base, int count, int rate, int concurrency, long seed, FailureProfile profile, LoadMetrics metrics)
            throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, concurrency));
        long intervalMs = rate > 0 ? 1000L / rate : 0L;
        for (int i = 0; i < count; i++) {
            final int index = i;
            pool.submit(() -> submitEvent(base, seed, index, profile, metrics));
            if (intervalMs > 0) {
                Thread.sleep(intervalMs);
            }
        }
        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.MINUTES);
    }

    private void submitEvent(String base, long seed, int index, FailureProfile profile, LoadMetrics metrics) {
        String id = "load-" + seed + "-" + index;
        DocumentRequest request = new DocumentRequest(
                id,
                "evt-" + id,
                RequestSource.SINGLE_EVENT,
                DocumentType.CONTRACT_CHANGE_CONFIRMATION,
                "C-" + (index % 1000),
                "V-" + index,
                Instant.now(),
                null,
                profile);
        long t0 = System.nanoTime();
        try {
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(base + "/api/document-requests"))
                    .timeout(Duration.ofSeconds(15))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(request)))
                    .build();
            HttpResponse<Void> response = http.send(httpRequest, HttpResponse.BodyHandlers.discarding());
            long latencyMs = (System.nanoTime() - t0) / 1_000_000;
            metrics.record(response.statusCode(), latencyMs);
        } catch (Exception e) {
            metrics.recordError();
        }
    }

    private void runBatch(String base, int count, int batchSize, FailureProfile profile) {
        try {
            String body = mapper.writeValueAsString(Map.of(
                    "count", count, "pageSize", batchSize, "failureProfile", profile.name(), "maxInFlight", 100));
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(base + "/api/demo/batches"))
                    .timeout(Duration.ofSeconds(15))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
            log.info("Batch gestartet: HTTP {} {}", response.statusCode(), response.body());
        } catch (Exception e) {
            log.error("Batchstart fehlgeschlagen: {}", e.getMessage());
        }
    }

    private void writeReport(
            String mode, int count, int rate, long seed, FailureProfile profile, LoadMetrics m, long elapsedMs)
            throws Exception {
        double throughput = m.requested() * 1000.0 / elapsedMs;
        String report =
                """
                === Lastlauf-Bericht ===
                mode=%s count=%d rate=%d/s seed=%d profile=%s
                angefordert=%d  akzeptiert(201)=%d  dubletten(200)=%d  http-fehler=%d
                dauer=%d ms  einreichungsdurchsatz=%.2f/s
                latenz p50=%d ms  p95=%d ms  p99=%d ms
                """
                        .formatted(
                                mode,
                                count,
                                rate,
                                seed,
                                profile,
                                m.requested(),
                                m.accepted(),
                                m.duplicates(),
                                m.httpErrors(),
                                elapsedMs,
                                throughput,
                                m.percentile(50),
                                m.percentile(95),
                                m.percentile(99));
        System.out.println(report);
        Path dir = Path.of("./var/reports");
        Files.createDirectories(dir);
        Files.writeString(dir.resolve("load-" + mode + "-" + seed + ".txt"), report);
    }

    private void printUsage() {
        System.out.println(
                """
                Load Generator — Verwendung:
                  --mode=event|batch|mixed  (Standard: event)
                  --count=N --rate=R --concurrency=C --seed=S
                  --batchSize=B --failureProfile=HAPPY|OPTIONAL_DATA_MISSING|...
                  --orchestrator=http://127.0.0.1:8080
                """);
    }

    private static Map<String, String> parse(String[] args) {
        Map<String, String> opts = new HashMap<>();
        for (String arg : args) {
            if (arg.startsWith("--") && arg.contains("=")) {
                int eq = arg.indexOf('=');
                opts.put(arg.substring(2, eq), arg.substring(eq + 1));
            }
        }
        return opts;
    }

    private static int intOpt(Map<String, String> opts, String key, int fallback) {
        String value = opts.get(key);
        return value == null ? fallback : Integer.parseInt(value);
    }
}
