package de.demo.versicherung.korrespondenz.loadgen;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Sammelt Lastmesswerte threadsicher und berechnet Perzentile (Auftrag 15.4). */
public class LoadMetrics {

    private final List<Long> latenciesMs = Collections.synchronizedList(new ArrayList<>());
    private final AtomicInteger requested = new AtomicInteger();
    private final AtomicInteger accepted = new AtomicInteger();
    private final AtomicInteger duplicates = new AtomicInteger();
    private final AtomicInteger httpErrors = new AtomicInteger();

    public void record(int statusCode, long latencyMs) {
        requested.incrementAndGet();
        latenciesMs.add(latencyMs);
        if (statusCode == 201) {
            accepted.incrementAndGet();
        } else if (statusCode == 200) {
            duplicates.incrementAndGet();
        } else {
            httpErrors.incrementAndGet();
        }
    }

    public void recordError() {
        requested.incrementAndGet();
        httpErrors.incrementAndGet();
    }

    public long percentile(double p) {
        List<Long> sorted;
        synchronized (latenciesMs) {
            if (latenciesMs.isEmpty()) {
                return 0;
            }
            sorted = new ArrayList<>(latenciesMs);
        }
        Collections.sort(sorted);
        int index = (int) Math.ceil(p / 100.0 * sorted.size()) - 1;
        index = Math.max(0, Math.min(index, sorted.size() - 1));
        return sorted.get(index);
    }

    public int requested() {
        return requested.get();
    }

    public int accepted() {
        return accepted.get();
    }

    public int duplicates() {
        return duplicates.get();
    }

    public int httpErrors() {
        return httpErrors.get();
    }
}
