package de.demo.versicherung.korrespondenz.loadgen;

import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Last-CLI (Auftrag 3.5 / 15.3): erzeugt Einzelereignisse, Batchlaeufe und Mischlast. Kein
 * Webserver; läuft als Kommandozeilenprogramm und beendet sich nach dem Lauf.
 */
@SpringBootApplication
public class LoadGeneratorApplication {

    public static void main(String[] args) {
        new SpringApplicationBuilder(LoadGeneratorApplication.class)
                .web(WebApplicationType.NONE)
                .run(args);
    }
}
