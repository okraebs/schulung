# Lasttest-Leitfaden

## Lastmodell
Die reale Zielgröße sind 20.000–30.000 Dokumentaufträge in wenigen Stunden. 30.000 Aufträge in
drei Stunden entsprechen rund **2,8 Aufträge/Sekunde**; als fachlicher Referenzpunkt dient eine
Zielrate von **3/s** plus kurze Burst-Tests (Auftrag 15.1).

Jeder Auftrag ist eine **unabhängige** `document_fulfillment`-Instanz. Der `document_batch_planner`
veröffentlicht seitenweise (`plan-batch` → Backpressure-Schleife → `publish-batch-page`) über den
**idempotenten Startservice** `POST /api/document-requests`. Es gibt keine Multi-Instance über
zehntausende Elemente und keine Riesen-Collection als Prozessvariable (Auftrag 22.1/22.2).

## Profile
- **demo** (H2-Datei): funktionale Nachweise und kleine Lastdemos. Ergebnisse sind **keine**
  produktiven Leistungswerte (Auftrag 15.2 / 22.12).
- **postgres**: produktionsnahe Basis für 20.000–30.000 Aufträge; Zugangsdaten aus
  Umgebungsvariablen, größere Pools, mehrere Worker-Instanzen mit eindeutiger `WORKER_ID`.
- **load** (mit `postgres` kombinieren): `document.render.mode=METADATA_ONLY`, kürzere
  Simulatorlatenz, reduzierte Logs.

```
# PostgreSQL bereitstellen (Beispiel) und Umgebungsvariablen setzen:
$env:POSTGRES_URL = "jdbc:postgresql://127.0.0.1:5432/correspondence"
$env:POSTGRES_USER = "correspondence"; $env:POSTGRES_PASSWORD = "..."
java -jar orchestrator-app.jar --spring.profiles.active=postgres
java -jar worker-app.jar       --spring.profiles.active=postgres,load --worker.... (WORKER_ID je Instanz)
```

## Backpressure
Der Planer prüft vor jeder Seite die Zahl aktiver `document_fulfillment`-Instanzen. Ist
`maxInFlight` erreicht, wartet er über einen Timer (PT3S) und prüft erneut. Standardwerte:
- demo: `pageSize=25`, `maxInFlight=100`
- postgres (Ausgangswerte, konfigurierbar): `pageSize=250`, `maxInFlight=2000`

Diese Werte sind **keine** universelle Tuningempfehlung (Auftrag 15.6).

## Kommandos
```
# Batch über REST
POST /api/demo/batches { "count": 20000, "pageSize": 250, "maxInFlight": 2000, "failureProfile": "HAPPY" }
GET  /api/demo/batches/{batchId}

# Load-Generator (CLI)
java -jar load-generator.jar --mode=event --count=10000 --rate=3 --concurrency=8 --orchestrator=http://127.0.0.1:8080
java -jar load-generator.jar --mode=batch --count=20000 --batchSize=250
java -jar load-generator.jar --mode=mixed --count=5000  --rate=3
```

## Messwerte (Auftrag 15.4)
Der Load-Generator misst angeforderte Aufträge, akzeptierte Starts (HTTP 201), Dubletten (HTTP 200),
HTTP-Fehler, Einreichungsdurchsatz und p50/p95/p99 der Einreichungslatenz. Berichte landen unter
`var/reports/`. Engine-Durchsatz, aktive Instanzen, offene External Tasks, manuelle Tasks und
Incidents lassen sich über `GET /api/demo/batches/{batchId}`, Cockpit und Actuator-Metrics ablesen.

## Konsistenzbilanz (Auftrag 15.5)
Ein Lauf gilt als fachlich konsistent, wenn
`started == fullyDispatched + degradedDispatched + cancelled + active + manual`
(keine unbemerkten Verluste, keine doppelten Seiteneffekte).

## Ausgeführter Smoke-Lauf (diese Umgebung)
- Batch `count=20`, `pageSize=10`, HAPPY → `started=20, active=0, fullyDispatched=20, planned=20`
  → Bilanz konsistent.
- Load-Generator `--mode=event --count=10 --rate=5` → 10 angefordert, 10 akzeptiert, 0 Dubletten,
  0 HTTP-Fehler, p50≈45 ms, p95≈201 ms.

## Grenzen
H2 ist nicht für 20.000–30.000 Aufträge als Leistungsnachweis geeignet. Der große Lauf ist in
dieser Umgebung **nicht** ausgeführt (kein PostgreSQL/Docker vorhanden); der Generator und das
PostgreSQL-Profil sind dafür vollständig vorbereitet (Auftrag 15.8 / 24.13).
