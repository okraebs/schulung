# Übungen (BPMN- und DMN-Training)

Jede Übung nennt Ziel, betroffene Dateien und eine Erfolgskontrolle (Test/Skript).

## 1. Neue Dokumentvariante
- **Ziel:** Eine weitere Sprache/Variante (z. B. `fr`) ergänzen.
- **Dateien:** `orchestrator-app/.../dmn/document-variant.dmn`, `worker-app/.../render/PdfRenderer.java`.
- **Kontrolle:** Parametrisierten Fall in `DmnDecisionTest` ergänzen; Smoke-Test rendert die Variante.

## 2. Zusätzliche DMN-Regel (Produkt/Bundesland)
- **Ziel:** `document-variant.dmn` um eine Eingabespalte `product` oder `customerFederalState`
  erweitern und Regeln ergänzen (im Auslieferungsstand bewusst weggelassen).
- **Dateien:** `document-variant.dmn`, ggf. `LoadCustomer/ContractDataHandler` (Variable setzen).
- **Kontrolle:** Neue Zeilen in der Regelmatrix von `DmnDecisionTest`.

## 3. Timerpfad / Reconciliation
- **Ziel:** `acknowledgementTimeout` und `maxStatusChecks` in `delivery-policy.dmn` variieren und das
  Verhalten beobachten (`DELIVERY_DELAYED`, `DELIVERY_TIMEOUT`).
- **Kontrolle:** `DocumentFulfillmentProcessTest` (Timeout → Reconcile-Loop) anpassen/ergänzen.

## 4. Neue User-Task-Entscheidung
- **Ziel:** Eine vierte manuelle Entscheidung einführen (z. B. `ESCALATE`) mit eigenem Pfad.
- **Dateien:** `ManualResolution`, `document-fulfillment.bpmn` (Gateway + Flow),
  `ManualReviewTaskListener` (Validierung).
- **Kontrolle:** Prozesstest für den neuen Pfad.

## 5. Zusätzlicher fachlicher Fehlerfall
- **Ziel:** Ein neues `FailureProfile` im Simulator ergänzen und im Fehlerkonzept einordnen.
- **Dateien:** `FailureProfile`, `SyntheticDataFactory`/`CallbackPublisher`,
  `data-completeness.dmn` bzw. Handler.
- **Kontrolle:** Realer E2E mit dem neuen Profil; erwartetes Outcome dokumentieren.

## 6. Parallele Datenbeschaffung (optionale Übung)
- **Ziel:** `loadCustomer/Contract/Tariff` als parallele Gateways modellieren und den Join über
  Integrationstests stabil absichern (Auftrag 6.1.2 – Hauptvariante bleibt sequenziell).
- **Kontrolle:** Prozesstest mit parallelem Join; Verhalten unter Last vergleichen.

## 7. Kompensation (optional, nicht Teil der Definition of Done)
- **Ziel:** Stornierung einer **noch nicht angenommenen** Druckreservierung als kleine
  Compensation-Übung modellieren. Eine bereits versendete E-Mail/ein gedruckter Brief kann nicht
  zurückgeholt werden – Compensation ist hier bewusst **nicht** der Hauptmechanismus.
