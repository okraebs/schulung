# Skript · `setup-check.ps1` — Umgebung prüfen

> **Datei:** `scripts/setup-check.ps1`
> **Zweck:** prüft das Tooling (Java 17, javac, Git, Maven‑Wrapper) und die Ports 8080–8082. **Verändert nichts** global.
> **Voraussetzung:** keine (außer einer PowerShell). Idealerweise als **erster** Schritt auf einem neuen PC.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | keine |
| **Schreibt etwas?** | nein (reine Diagnose) |
| **Exit‑Code** | `0` = bestanden, `1` = mit Fehlern |
| **Aufruf** | `.\scripts\setup-check.ps1` |

## 2. Was es prüft (Reihenfolge)

| # | Prüfung | Erwartung | Wie |
|---|---|---|---|
| 1 | **Java** | Version enthält `17.` | `java -version` |
| 2 | **javac** | Version enthält `17.` | `javac -version` |
| 3 | **Git** | vorhanden | `git --version` |
| 4 | **Maven Wrapper** | `mvnw.cmd` existiert | `Test-Path` |
| 5–7 | **Ports 8080/8081/8082** | frei | `Get-NetTCPConnection` (belegt → `[WARN]`) |

Ausgabe je Zeile `[ OK ]` / `[FAIL]` / `[WARN]`; am Ende „Setup‑Check bestanden." oder „… mit Fehlern." (+ Exit 1).

## 3. Nachverfolgen
Reine Konsolenausgabe; nichts wird persistiert. Bei `[WARN] Port … belegt` zeigt die Meldung die belegende PID — meist eine noch laufende Demo (→ [`stop-demo`](stop-demo.md)).

## 4. Querverweise
- Danach: [`build`](build.md) → [`start-demo`](start-demo.md)
- Bibliothek: [`_common`](_common.md)
