# Skript · `start-demo.ps1` — Demo starten

> **Datei:** `scripts/start-demo.ps1`
> **Zweck:** startet Orchestrator, Simulator und Worker in getrennten Prozessen, schreibt PID‑Dateien und Logs und wartet auf die Health Checks.
> **Voraussetzung:** gebaute Jars (→ [`build`](build.md)). Ports 8080–8082 frei.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | keine |
| **Aufruf** | `.\scripts\start-demo.ps1` |
| **Startet** | 3 Java‑Prozesse (siehe `$Apps` in [`_common`](_common.md)) |
| **Erfolg** | „Demo laeuft. Cockpit/Tasklist: http://127.0.0.1:8080/camunda" |

## 2. Was es tut (Reihenfolge)

1. `Initialize-Dirs` legt `var\{logs,run,…}` an.
2. **Für jede App** in `$Apps` (Orchestrator → Simulator → Worker):
   - prüft, ob das Jar existiert (sonst: „Jar fehlt … zuerst build.ps1" + Exit 1),
   - startet `java -jar <jar>` via `Start-Process` mit Arbeitsverzeichnis `$Root`,
   - leitet stdout/stderr nach `var\logs\<name>.out.log` / `.err.log`,
   - schreibt die PID nach `var\run\<name>.pid`.
3. **Danach** wartet es je App auf den Health Check (`Wait-Health`, bis zu 120 s) und meldet `UP` / `NICHT ERREICHBAR`.
4. Alle oben → grüne Erfolgsmeldung; sonst Hinweis auf `var\logs` + Exit 1.

```mermaid
flowchart LR
  s[start-demo.ps1] --> o[java -jar orchestrator 8080]
  s --> sim[java -jar simulator 8082]
  s --> w[java -jar worker 8081]
  o & sim & w -. PID .-> run[(var/run/*.pid)]
  o & sim & w -. Log .-> log[(var/logs/*.log)]
  s --> hc{alle /actuator/health UP?}
```

> 🔌 **Warum getrennte Prozesse + PID‑Dateien?** Die drei Dienste sind eigenständige Spring‑Boot‑Apps (Engine, Quell-/Output‑System, Worker). Getrennte Prozesse = realistische Verteilung und der Beweis, dass der Worker **entkoppelt** über REST arbeitet. Die PID‑Dateien erlauben [`stop-demo`](stop-demo.md), **genau** diese Prozesse (und nur sie) sauber zu beenden.

## 3. Nachverfolgen
| Quelle | Inhalt |
|---|---|
| `var\logs\orchestrator.out.log` | Engine‑Start, Deployments (BPMN/DMN) |
| `var\logs\worker.out.log` | `fetchAndLock`/`complete` der External Tasks |
| `var\logs\simulator.out.log` | Quell-/Output‑Requests, Callbacks |
| `var\run\*.pid` | laufende PIDs |
| Cockpit | `http://127.0.0.1:8080/camunda` (`demo`/`demo`) |

## 4. Querverweise
- Gegenstück: [`stop-demo`](stop-demo.md) · Aufräumen: [`reset-demo`](reset-demo.md)
- Danach Szenarien: [`run-smoke`](run-smoke.md) usw.
