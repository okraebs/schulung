# Skript · `run-load.ps1` — Batch & Last

> **Datei:** `scripts/run-load.ps1`
> **Profil:** `HAPPY` (Standard, parametrierbar) · **Erzwungener Pfad:** [`document-batch-planner`](../bpmn/document-batch-planner.md) → viele **unabhängige** [`document-fulfillment`](../bpmn/document-fulfillment.md)-Instanzen
> **Voraussetzung:** laufende Demo; für den Lastteil die gebaute `load-generator.jar`.

Zeigt **Skalierung mit Backpressure**: ein Stapel (Batch) wird seitenweise/gedrosselt veröffentlicht, zusätzlich erzeugt der Load‑Generator Einzel‑Last. Am Ende steht eine **Konsistenzbilanz**.

---

## 1. Auf einen Blick

| Parameter | Default | Bedeutung |
|---|---|---|
| `-Count` | 20 | Anzahl Dokumente im Batch |
| `-PageSize` | 10 | Seitengröße der Veröffentlichung |
| `-Rate` | 3 | Rate des Load‑Generators (pro Zeiteinheit) |
| `-Concurrency` | 4 | parallele Erzeuger im Load‑Generator |
| `-FailureProfile` | `HAPPY` | Fehlerprofil für **alle** Aufträge des Laufs |

**Aufruf:** `.\scripts\run-load.ps1 -Count 20` · **Erfolg:** konsistente Bilanz (`konsistent=True`), Bericht unter `var\reports\`.

## 2. Was passiert Schritt für Schritt

| # | Skript‑Aktion | REST / Effekt |
|---|---|---|
| 1 | Batch starten | `POST /api/demo/batches` mit `{count, pageSize, maxInFlight:100, failureProfile}` → startet `document_batch_planner` |
| 2 | `batchId` merken | aus der Antwort |
| 3 | Polling (max. 60×3 s) | `GET /api/demo/batches/$batchId` bis `active==0 && started>=Count` |
| 4 | **Bilanz** rechnen | `started == fully + degraded + cancelled + active + manual` ? |
| 5 | Load‑Generator | `java -jar load-generator.jar --mode=event --count … --rate … --orchestrator …` (falls Jar vorhanden) |
| 6 | Bericht speichern | `var\reports\batch-<batchId>.json` |

## 3. Der erzwungene BPMN‑Pfad (und **warum**)

Der Batch‑Planer veröffentlicht je Auftrag eine **eigene** `document_fulfillment`-Instanz über den idempotenten Start. Die Batch‑Aufträge nutzen Dokumentart **`PREMIUM_ADJUSTMENT`** (siehe `PublishBatchPageHandler`), daher andere DMN‑Treffer als beim Smoke:

```
document_batch_planner:
   plan-batch → [checkBackpressure → unter maxInFlight? ] → publish-batch-page → (weitere Seiten?) …

je veröffentlichtem Auftrag (Profil HAPPY):
   … evalVariant   [document-variant → Regel 3/4: PA_DE/PA_EN, Anlage tariff_sheet]
   … evalPolicy    [delivery-policy → Regel 3: EMAIL, maxStatusChecks=5, Priorität HIGH]
   … → FULLY_DISPATCHED
```

| Stelle | Eingabe | Ergebnis | Warum |
|---|---|---|---|
| `document-variant` | `PREMIUM_ADJUSTMENT` + Sprache | `PA_DE`/`PA_EN` + `tariff_sheet` | Beitragsanpassung braucht Tarifblatt |
| `delivery-policy` (Regel 3) | `documentType=PREMIUM_ADJUSTMENT` | `maxStatusChecks=5`, `HIGH` | wichtige, zeitkritische Post |
| `gw_bp` | `belowLimit` (maxInFlight=100) | i. d. R. sofort publizieren | bei `-Count 20` keine echte Drosselung |

> 💡 Mit anderen Profilen (`-FailureProfile MANDATORY_DATA_MISSING` o. ä.) kann man die **Bilanz** gezielt „verbiegen" (mehr `manual`/`incident`) — schön, um die Aggregation des Batch‑Status zu verstehen.

## 4. Die Konsistenzbilanz

`GET /api/demo/batches/<id>` liefert: `planned, started, active, manual, incident, fullyDispatched, degradedDispatched, cancelled`. Das Skript prüft:

```
started == fullyDispatched + degradedDispatched + cancelled + active + manual
```
Geht die Gleichung auf (`konsistent=True`), ist **kein** Auftrag „verloren" — jede Instanz ist eindeutig einem Zustand zugeordnet.

## 5. Wo/wie nachverfolgen?

| Quelle | Was du siehst |
|---|---|
| **Batch‑REST** | `GET /api/demo/batches/<batchId>` (Live‑Bilanz) |
| **Cockpit** | die *eine* Planer‑Instanz + die *vielen* `document_fulfillment`-Instanzen (Filter nach `batchId`) |
| **Bericht** | `var\reports\batch-<batchId>.json` |
| **Load‑Generator** | Konsolenausgabe des Jars |

## 6. Stolpersteine
- Fehlt `load-generator.jar`, überspringt das Skript den Lastteil mit Hinweis „… zuerst build.ps1" — der Batchteil läuft trotzdem.
- `maxInFlight` ist im Skript fest auf 100 → für kleine `-Count` greift die Backpressure‑Drossel nicht sichtbar; für den Effekt `-Count` deutlich > 100 wählen.

## 7. Querverweise
- Prozesse: [`document-batch-planner`](../bpmn/document-batch-planner.md), [`document-fulfillment`](../bpmn/document-fulfillment.md)
- DMN: [`document-variant`](../dmn/document-variant.md) (PA‑Regeln), [`delivery-policy`](../dmn/delivery-policy.md) (Regel 3)
