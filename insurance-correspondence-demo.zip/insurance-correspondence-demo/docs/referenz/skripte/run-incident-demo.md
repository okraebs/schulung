# Skript · `run-incident-demo.ps1` — technischer Incident & Recovery

> **Datei:** `scripts/run-incident-demo.ps1`
> **Profil:** `PERMANENT_RENDER_FAILURE` · **Erzwungener Pfad:** **Incident** an `renderDocument` (kein Gateway!)
> **Voraussetzung:** laufende Demo.

Zeigt den Unterschied zwischen **fachlicher** Abweichung (DMN/User Task) und **technischer** Störung: Ein dauerhafter Renderfehler erzeugt einen **Incident** — die klassische „Reparaturstelle" im Cockpit. Mit `-AutoFix` führt das Skript die Reparatur gleich vor.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | `-AutoFix` (optional: behebt die Ursache automatisch) |
| **Aufruf** | `.\scripts\run-incident-demo.ps1` oder `… -AutoFix` |
| **Auftrags‑ID** | `INCIDENT-<zufallszahl>` |
| **Erfolg (ohne Fix)** | mind. 1 Incident an der Instanz |
| **Erfolg (mit Fix)** | Outcome `FULLY_DISPATCHED`, 0 verbleibende Incidents |

## 2. Was passiert Schritt für Schritt

| # | Skript‑Aktion | REST / Effekt |
|---|---|---|
| 1 | `Submit-DocumentRequest $id "PERMANENT_RENDER_FAILURE"` | startet den Prozess |
| 2 | `processInstanceId` holen | aus `Get-RequestStatus` |
| 3 | Schleife (max. 45×2 s) | `Get-IncidentCount` bis ≥ 1 |
| 4 | Ausgabe | Cockpit‑Schritte zur manuellen Behebung |
| 5 | **nur `-AutoFix`** | `PUT …/variables/failureProfile = HAPPY`, dann `PUT …/external-task/<id>/retries = 3`, dann `Wait-Outcome` |

## 3. Der erzwungene BPMN‑Pfad (und **warum**)

Profil `PERMANENT_RENDER_FAILURE` ⇒ der **Worker** (`RenderDocumentHandler`) wirft **deterministisch** eine Ausnahme, **bevor** überhaupt gerendert wird:

```
… evalPolicy → renderDocument
      Versuch 1: Handler wirft → handleFailure(retries: 1)
      Versuch 2: Handler wirft → handleFailure(retries: 0)  ⟶  INCIDENT
```

| Schritt | Mechanik | Quelle |
|---|---|---|
| Fehler erzeugen | `if (failureProfile == PERMANENT_RENDER_FAILURE) throw …` | `RenderDocumentHandler` |
| Retries herunterzählen | `INITIAL_RETRIES=1` → `max(0, n-1)` → 0 | `handleFailure(...)` |
| Incident | bei `retries==0` erzeugt die **Engine** einen Incident an `renderDocument` | Camunda |

> 🧩 **Wichtig:** Das ist **kein** BPMN‑Error‑Boundary und **keine** DMN‑Entscheidung, sondern ein **technischer Incident** über aufgebrauchte External‑Task‑Retries. Der Simulator ist hier unbeteiligt — die Logik sitzt komplett im Worker. So lernt man die natürliche Behandlung technischer Störungen in Camunda (Cockpit → Incident → Ursache beheben → Retries erhöhen).

## 4. Die Recovery (`-AutoFix` macht genau das von Hand Mögliche)

1. **Ursache beheben:** Prozessvariable `failureProfile` auf `HAPPY` setzen (`PUT /engine-rest/process-instance/<pi>/variables/failureProfile`) — damit wirft der Handler beim nächsten Versuch nicht mehr.
2. **Retries erhöhen:** `PUT /engine-rest/external-task/<taskId>/retries` auf `3` — die Engine stellt die Aufgabe wieder zur Bearbeitung.
3. Der Worker rendert nun erfolgreich → der Auftrag läuft den Rest des Happy Path → **`FULLY_DISPATCHED`**, Incident verschwindet.

## 5. Wo/wie nachverfolgen?

| Quelle | Was du siehst |
|---|---|
| **Cockpit** (`demo`/`demo`) | roter **Incident**‑Marker an „Dokument erzeugen" (`render-document`); Incident‑Meldung, Retries = 0 |
| **Engine‑REST** | `GET /engine-rest/incident?processInstanceId=<pi>`; `GET /engine-rest/external-task?processInstanceId=<pi>` |
| **Worker‑Log** | `var\logs\worker.out.log`: „render-document … erschöpft (retries=0) -> Incident" |
| **Metriken** | Zähler `worker.render.failures`, `documents.incidents` |

## 6. Stolpersteine
- Der Incident entsteht erst beim **zweiten** Render‑Versuch (Retries 1→0); das Skript wartet dafür (bis 90 s).
- Ohne `-AutoFix` bleibt die Instanz mit Incident liegen — bewusst, zum manuellen Üben im Cockpit. Mit [`reset-demo`](reset-demo.md) später aufräumen.

## 7. Querverweise
- Prozess: [`document-fulfillment`](../bpmn/document-fulfillment.md) (§6 Fehlerbehandlung, Task `renderDocument`)
- Kontrast: [`run-smoke`](run-smoke.md) (Render gelingt)
