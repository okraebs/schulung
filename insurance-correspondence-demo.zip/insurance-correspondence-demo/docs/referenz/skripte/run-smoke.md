# Skript · `run-smoke.ps1` — der fachliche Happy Path

> **Datei:** `scripts/run-smoke.ps1`
> **Profil:** `HAPPY` · **Erzwungener Pfad:** der gerade Hauptpfad durch [`document-fulfillment`](../bpmn/document-fulfillment.md) → **`FULLY_DISPATCHED`**
> **Voraussetzung:** laufende Demo ([`start-demo`](start-demo.md)).

Der „echte" Smoke‑Test: ein Auftrag von der Anfrage bis zum fertigen PDF, vollautomatisch, ohne jede Abzweigung. Beweist, dass die **komplette Fachkette** (Daten → DMN → PDF → Versand → Annahme → Abschluss) funktioniert.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | keine |
| **Aufruf** | `.\scripts\run-smoke.ps1` |
| **Auftrags‑ID** | `SMOKE-<zufallszahl>` |
| **Erfolg** | „SMOKE OK." — Outcome `FULLY_DISPATCHED` **und** gültiges PDF |

## 2. Was passiert Schritt für Schritt

| # | Skript‑Aktion | REST / Effekt |
|---|---|---|
| 1 | `Submit-DocumentRequest $id "HAPPY"` | `POST /api/document-requests` → startet `document_fulfillment` |
| 2 | `Wait-Outcome $id 90` | pollt `GET /api/document-requests/$id` bis `outcome` gesetzt |
| 3 | PDF prüfen | liest `var\documents\<id>\document.pdf`, prüft Signatur `%PDF-` |
| 4 | Bewertung | Erfolg nur wenn `outcome == FULLY_DISPATCHED` **und** PDF‑Signatur ok |

## 3. Der erzwungene BPMN‑Pfad (und **warum**)

Profil `HAPPY` ⇒ der Simulator liefert **vollständige** Daten, akzeptiert die Zustellung und sendet **zeitnah** (≈2 s) den Annahme‑Callback. Dadurch feuern überall die „grünen" Regeln:

```
start → normalizeRequest → loadCustomer → loadContract → loadTariff
  → evalCompleteness  [DMN data-completeness → Regel 6: FULL]
  → gw_completeness   (FULL → kein Manual)
  → evalVariant       [DMN document-variant → Regel 1: CCC_DE]
  → evalPolicy        [DMN delivery-policy → Regel 4: EMAIL, PT15S, 3, NORMAL]
  → renderDocument    (echtes PDF, OpenPDF)
  → dispatchDocument  (Outbox → Simulator)
  → receiveResult     (Callback ACCEPTED nach ~2 s)
  → gw_delivery       (ACCEPTED)
  → finalizeOutcome   → outcome = FULLY_DISPATCHED → end
```

| Entscheidung | Eingaben | Ergebnis | Warum dieser Zweig |
|---|---|---|---|
| `data-completeness` | alle Status `OK` | `FULL` | HAPPY = keine fehlenden Felder |
| `gw_completeness` | `completenessClass=FULL` | weiter (kein Manual) | nur `MANUAL_REQUIRED` ginge zur User Task |
| `document-variant` | `CONTRACT_CHANGE_CONFIRMATION` + `de` | `CCC_DE` | Standard‑Dokumentart der Demo |
| `delivery-policy` | Kanalpräferenz + Dokumentart | `EMAIL`/`PT15S`/3/`NORMAL` | Default‑Regel |
| `gw_delivery` | `deliveryResultStatus=ACCEPTED` | Abschluss | Callback kam rechtzeitig (vor `PT15S`) |

> 💡 Es wird **keine** Abzweigung genommen: kein Manual, keine Degradation, kein Incident, kein Timeout, keine Reconciliation‑Schleife. Genau das ist der Sinn von „Smoke".

## 4. Wo/wie nachverfolgen?

| Quelle | Was du siehst |
|---|---|
| **Cockpit** (`/camunda`, `demo`/`demo`) | die Instanz wandert in Sekunden durch alle Tasks bis „abgeschlossen"; *Called Decision Instances* zeigen `FULL`/`CCC_DE` |
| **Status‑REST** | `GET /api/document-requests/SMOKE-…` → `outcome: FULLY_DISPATCHED` |
| **Dateisystem** | `var\documents\SMOKE-…\document.pdf` (öffnet als echtes PDF) |
| **Worker‑Log** | `var\logs\worker.out.log`: `load-customer-data … render-document … dispatch-document …` |

## 5. Stolpersteine
- Läuft nur bei **laufender** Demo (sonst Timeout). Vorher `start-demo`.
- Das PDF entsteht erst nach `renderDocument`; bei sehr langsamem ersten Start ggf. wenige Sekunden Geduld (Timeout 90 s ist großzügig).

## 6. Querverweise
- Prozess: [`document-fulfillment`](../bpmn/document-fulfillment.md) · DMN: [`data-completeness`](../dmn/data-completeness.md), [`document-variant`](../dmn/document-variant.md), [`delivery-policy`](../dmn/delivery-policy.md)
- Kontrast: [`run-manual-review-demo`](run-manual-review-demo.md) (Abzweigung Manual), [`run-incident-demo`](run-incident-demo.md) (Incident)
