# Skript · `run-restart-demo.ps1` — Wait‑State überlebt Neustart

> **Datei:** `scripts/run-restart-demo.ps1`
> **Profil:** `DELIVERY_TIMEOUT` · **Erzwungener Pfad:** anhalten an der **Receive Task** `receiveResult`, dann Fortsetzung per **gepuffertem Callback**
> **Voraussetzung:** laufende Demo.

Das Lehrstück zu **langlaufenden Transaktionen**: Ein Auftrag wartet auf die technische Annahme (Wait‑State), der **Orchestrator wird neu gestartet**, und der Auftrag läuft danach korrekt weiter — der Zustand lag persistent in der Datenbank.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | keine |
| **Aufruf** | `.\scripts\run-restart-demo.ps1` |
| **Auftrags‑ID** | `RESTART-<zufallszahl>` |
| **Erfolg** | „RESTART‑NACHWEIS OK." — Receive Task erreicht **und** Status nach Neustart `ACTIVE` **und** Outcome `FULLY_DISPATCHED` |

## 2. Was passiert Schritt für Schritt

| # | Skript‑Aktion | REST / Effekt |
|---|---|---|
| 1 | `Submit-DocumentRequest $id "DELIVERY_TIMEOUT"` | startet den Prozess |
| 2 | warten bis `activeActivity ~ receiveResult` | `GET /api/document-requests/$id` |
| 3 | **Orchestrator stoppen** | `Stop-Process` auf die PID aus `var\run\orchestrator.pid` |
| 4 | **Orchestrator neu starten** | `java -jar orchestrator-app.jar`, neue PID, `Wait-Health` |
| 5 | Zustand prüfen | `GET …/$id` → `status == ACTIVE`? (überlebt) |
| 6 | **gepufferten Callback senden** | `POST /api/delivery-results` mit `deliveryResultStatus=ACCEPTED` |
| 7 | Ergebnis | `Wait-Outcome` → `FULLY_DISPATCHED` |

## 3. Der erzwungene BPMN‑Pfad (und **warum**)

Profil `DELIVERY_TIMEOUT` ist hier der Schlüssel: Der Simulator setzt den Providerstatus auf **`PENDING`** und sendet **bewusst keinen** automatischen Annahme‑Callback (`CallbackPublisher` loggt nur „kein Callback …"). Dadurch **bleibt** der Prozess garantiert an der Receive Task stehen — der ideale, reproduzierbare Wait‑State für den Neustart‑Nachweis.

```
… dispatchDocument → receiveResult   ⟵ wartet (DELIVERY_TIMEOUT: kein Auto-Callback)
        │  [Orchestrator-Neustart]   ← Zustand liegt in der DB, überlebt
        ▼
   POST /api/delivery-results (ACCEPTED)  → Inbox → MessageCorrelator
        → DeliveryResultReceived korreliert (Business Key = documentJobId)
   receiveResult → gw_delivery (ACCEPTED) → finalizeOutcome → FULLY_DISPATCHED
```

> 🔌 **Warum der manuelle `POST /api/delivery-results`?** Weil der Simulator für `DELIVERY_TIMEOUT` absichtlich nie einen Callback schickt. Das Skript spielt den **gepufferten** Callback selbst ein und beweist damit gleich zwei Dinge: (1) der Wait‑State überlebt den Neustart, (2) ein **nach** dem Neustart eintreffender Callback wird über **Inbox + Korrelation** sauber zugestellt und setzt den Prozess fort. Genau dafür gibt es die `delivery_callback_inbox` und den `InboxCorrelationScheduler`.

## 4. Wo/wie nachverfolgen?

| Quelle | Was du siehst |
|---|---|
| **Cockpit** (`demo`/`demo`) | vor **und** nach dem Neustart dieselbe Instanz `ACTIVE`, Token auf `receiveResult` |
| **Status‑REST** | `GET /api/document-requests/RESTART-…` → `status: ACTIVE` (vor Callback), dann `outcome: FULLY_DISPATCHED` |
| **Orchestrator‑Log** | `var\logs\orchestrator.out.log`: Stop, Neustart, dann Korrelation des Callbacks |

## 5. Stolpersteine
- Das Skript startet **nur** den Orchestrator neu (Worker/Simulator laufen weiter) — gewollt, um den Engine‑Wait‑State isoliert zu zeigen.
- Der Timer `timer_ack` (`PT15S`) zählt nur, während die Engine läuft; während der Downtime ruht er. Der eingespielte Callback führt die Instanz dennoch sauber zu `FULLY_DISPATCHED`.
- Braucht die PID‑Datei `var\run\orchestrator.pid` (von `start-demo`).

## 6. Querverweise
- Prozess: [`document-fulfillment`](../bpmn/document-fulfillment.md) (Receive Task `receiveResult`, Timer `timer_ack`, Inbox/Korrelation)
- DMN: [`delivery-policy`](../dmn/delivery-policy.md) (Frist `acknowledgementTimeout`)
- Verwandt: [`run-smoke`](run-smoke.md) (Callback kommt automatisch)
