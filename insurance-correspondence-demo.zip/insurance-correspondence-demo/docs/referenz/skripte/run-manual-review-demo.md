# Skript · `run-manual-review-demo.ps1` — die menschliche Klärung

> **Datei:** `scripts/run-manual-review-demo.ps1`
> **Profil:** `MANDATORY_DATA_MISSING` · **Erzwungener Pfad:** Abzweigung in die **User Task** `manualReview`
> **Voraussetzung:** laufende Demo.

Zeigt den **Human‑in‑the‑Loop**: Fehlt ein Pflichtfeld, läuft der Auftrag **nicht** automatisch durch, sondern landet als Aufgabe in der Tasklist. Das Skript erzeugt den Fall und führt dich an die richtige Stelle.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | keine |
| **Aufruf** | `.\scripts\run-manual-review-demo.ps1` |
| **Auftrags‑ID** | `MANUAL-<zufallszahl>` |
| **Erfolg** | „User Task vorhanden: …" + Anleitung; die Instanz **wartet** auf einen Menschen |

## 2. Was passiert Schritt für Schritt

| # | Skript‑Aktion | REST / Effekt |
|---|---|---|
| 1 | `Submit-DocumentRequest $id "MANDATORY_DATA_MISSING"` | startet den Prozess |
| 2 | Schleife (max. 30×2 s) | `GET /engine-rest/task?processInstanceBusinessKey=$id` bis eine Task erscheint |
| 3 | Ausgabe | druckt die nächsten Schritte für die **Tasklist** (`ops`/`ops`) und die drei Entscheidungsoptionen |

> Das Skript **schließt die Aufgabe nicht ab** — das ist bewusst Aufgabe des Menschen in der Tasklist.

## 3. Der erzwungene BPMN‑Pfad (und **warum**)

Profil `MANDATORY_DATA_MISSING` ⇒ der Simulator blendet beim Kunden **`email` UND `postalAddress`** aus (beides Pflicht‑Empfängerfelder; `fullName` und Optionsfelder bleiben erhalten!). Folge:

```
… loadCustomer  → customerDataStatus = MANDATORY_MISSING
  → evalCompleteness  [DMN data-completeness → Regel 1]
       completenessClass = MANUAL_REQUIRED, degradationAllowed = false,
       missingRequiredFields = "customerMandatory"
  → gw_completeness  (MANUAL_REQUIRED) → manualReview  ⟵ HÄLT HIER
```

| Entscheidung | Eingabe | Ergebnis |
|---|---|---|
| `LoadCustomerDataHandler` | email+postalAddress fehlen | `customerDataStatus = MANDATORY_MISSING` |
| `data-completeness` (Regel 1) | `customerDataStatus=MANDATORY_MISSING` | `MANUAL_REQUIRED`, `degradationAllowed=false` |
| `gw_completeness` | `completenessClass=MANUAL_REQUIRED` | → **User Task** |
| `ManualReviewTaskListener` (create) | `missingRequiredFields` gesetzt | `manualReason = MISSING_MANDATORY_DATA` |

## 4. Die drei Entscheidungen in der Tasklist (`ops`/`ops`)

| Auswahl `manualResolution` | Folgepfad | Ergebnis |
|---|---|---|
| **`RETRY_ENRICHMENT`** (+ `correctedEmail`/`correctedPostalAddress`) | zurück zu `loadCustomer` | mit Korrektur wird der Auftrag wieder **vollständig** → i. d. R. `FULLY_DISPATCHED` |
| **`CANCEL_REQUEST`** | `cancelOutcome` | Outcome **`CANCELLED_AFTER_MANUAL_REVIEW`** |
| **`DELIVER_REDUCED`** | — | ❌ hier **nicht zulässig**: `degradationAllowed=false` → `ManualReviewTaskListener` wirft beim Abschließen eine Exception, die Task bleibt offen |

> 🧠 **Lehrpunkt:** Bei **Pflicht**datenmangel ist „reduziert ausliefern" bewusst **verboten** — der Listener erzwingt das. „Reduziert" gibt es nur bei `OPTIONAL_DATA_MISSING` (dann `degradationAllowed=true`). Genau diese Regel macht die Demo robust gegen Fehlbedienung.

## 5. Wo/wie nachverfolgen?

| Quelle | Was du siehst |
|---|---|
| **Tasklist** (`/camunda`, `ops`/`ops`) | Aufgabe „Dokumentauftrag manuell klaeren: MANUAL-…" mit Formular (Klärungsgrund, fehlende Pflichtfelder) |
| **Cockpit** (`demo`/`demo`) | Token „leuchtet" auf `manualReview`; Variablen `completenessClass=MANUAL_REQUIRED`, `manualReason` |
| **Engine‑REST** | `GET /engine-rest/task?processInstanceBusinessKey=MANUAL-…` |

## 6. Querverweise
- Prozess: [`document-fulfillment`](../bpmn/document-fulfillment.md) (User Task `manualReview`, Gateway `gw_manual`)
- DMN: [`data-completeness`](../dmn/data-completeness.md) (Regel 1)
- Kontrast: [`run-smoke`](run-smoke.md) (kein Manual)
