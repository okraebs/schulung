# Skript · `stop-demo.ps1` — Demo stoppen

> **Datei:** `scripts/stop-demo.ps1`
> **Zweck:** beendet **ausschließlich** die in den PID‑Dateien registrierten Prozesse — nichts anderes.
> **Voraussetzung:** eine zuvor mit [`start-demo`](start-demo.md) gestartete Demo.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | keine |
| **Aufruf** | `.\scripts\stop-demo.ps1` |
| **Wirkung** | stoppt Orchestrator, Simulator, Worker; entfernt deren PID‑Dateien |

## 2. Was es tut

Für jede App in `$Apps`:
1. liest `var\run\<name>.pid`,
2. wenn der Prozess noch läuft → `Stop-Process -Force` → „… gestoppt.",
3. sonst → „… lief nicht mehr.",
4. löscht die PID‑Datei.
Fehlt die PID‑Datei: „Keine PID‑Datei fuer …". Am Ende: „Demo gestoppt."

> 🔒 **Warum nur PID‑gesteuert?** Das Skript ruft **kein** pauschales `Stop-Process java` auf — das würde auch fremde Java‑Prozesse (z. B. eine IDE) abschießen. Es beendet **nur** die PIDs, die `start-demo` selbst geschrieben hat. Sicher und gezielt.

## 3. Nachverfolgen / Prüfen
```powershell
Get-Content var\run\*.pid            # sollte danach nichts mehr finden
Get-NetTCPConnection -LocalPort 8080,8081,8082 -State Listen -EA SilentlyContinue
```
Beides leer = sauber gestoppt.

## 4. Stolperstein
Wird ein Dienst „von außen" (z. B. Task‑Manager) beendet, bleibt die PID‑Datei verwaist — `stop-demo` meldet dann korrekt „lief nicht mehr" und räumt die Datei auf. Kein Problem.

## 5. Querverweise
- Gegenstück: [`start-demo`](start-demo.md) · Daten zusätzlich löschen: [`reset-demo`](reset-demo.md)
