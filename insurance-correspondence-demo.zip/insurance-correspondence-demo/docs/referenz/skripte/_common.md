# Skript · `_common.ps1` — die gemeinsame Werkzeugkiste

> **Datei:** `scripts/_common.ps1`
> **Typ:** **Bibliothek** (keine eigenständige Ausführung) — wird von **allen** anderen Skripten per Dot‑Sourcing (`. "$PSScriptRoot\_common.ps1"`) eingebunden.
> **Reines PowerShell, keine `cmd.exe`-Syntax.**

Dieses Skript definiert einmal zentral, was alle Demo‑Skripte brauchen: Pfade, Dienst‑URLs, die App‑Liste und ein paar REST‑Hilfsfunktionen. Wer die anderen Skripte verstehen will, liest am besten **zuerst** dieses.

---

## 1. Globale Einstellung

```powershell
$ErrorActionPreference = "Stop"
```
Lässt jedes Skript **beim ersten Fehler abbrechen** (fail‑fast) — gewollt, damit eine kaputte Demo nicht „halb" weiterläuft.

## 2. Pfad‑ und Dienst‑Variablen (`$script:`‑Scope)

| Variable | Wert | Zweck |
|---|---|---|
| `$Root` | Projektwurzel (Elternordner von `scripts/`) | Basis für alle Pfade |
| `$VarDir` | `<Root>\var` | Laufzeitdaten |
| `$LogDir` | `<Root>\var\logs` | Prozess‑Logs |
| `$RunDir` | `<Root>\var\run` | PID‑Dateien |
| `$Orchestrator` | `http://127.0.0.1:8080` | Engine + REST |
| `$Worker` | `http://127.0.0.1:8081` | External‑Task‑Worker |
| `$Simulator` | `http://127.0.0.1:8082` | Quell-/Output‑System |

> 🔒 Alle Dienste binden bewusst an **`127.0.0.1`** (nur lokal erreichbar) — Schulungs-/Demosicherheit.

## 3. Die App‑Liste `$Apps`

```powershell
$Apps = @(
  @{ Name="orchestrator"; Jar="orchestrator-app\target\orchestrator-app.jar";              Health="$Orchestrator/actuator/health" },
  @{ Name="simulator";    Jar="external-systems-simulator\target\external-systems-simulator.jar"; Health="$Simulator/actuator/health" },
  @{ Name="worker";       Jar="worker-app\target\worker-app.jar";                          Health="$Worker/actuator/health" }
)
```
Diese **Reihenfolge** (Orchestrator → Simulator → Worker) ist die Startreihenfolge in [`start-demo`](start-demo.md): Der Worker braucht Orchestrator (Tasks ziehen) und Simulator (Daten) — er kommt zuletzt.

## 4. Funktionen

| Funktion | Ruft auf / tut | Rückgabe |
|---|---|---|
| `Initialize-Dirs` | legt `var\{logs,run,db,documents,reports}` an | — |
| `Wait-Health($Url,$TimeoutSec=120)` | pollt alle 2 s `GET $Url` bis `.status -eq "UP"` | `$true`/`$false` |
| `Submit-DocumentRequest($DocumentJobId,$FailureProfile="HAPPY",$DocumentType="CONTRACT_CHANGE_CONFIRMATION")` | **`POST /api/document-requests`** mit festen Demodaten (`customerId=C-1001`, `contractId=V-2001`, `requestedAt=2026-06-20T08:00:00Z`) | Antwortobjekt |
| `Get-RequestStatus($DocumentJobId)` | **`GET /api/document-requests/{id}`** (Fehler → `$null`) | Status‑Objekt |
| `Wait-Outcome($DocumentJobId,$TimeoutSec=90)` | pollt `Get-RequestStatus` bis `.outcome` gesetzt ist | Outcome‑String oder `"(timeout)"` |
| `Get-IncidentCount($ProcessInstanceId)` | **`GET /engine-rest/incident?processInstanceId=…`**, gefiltert | Anzahl Incidents |

> 🐛 **Lehrreicher Gotcha in `Get-IncidentCount`:** PowerShell macht aus einem leeren REST‑Array `@($null)` eine Länge **1** statt 0. Deshalb wird mit `... | Where-Object { $_.id }` gefiltert, bevor `.Count` gebildet wird — sonst meldete die Inzidenzzählung fälschlich „1". Dieser Fehler hat in der Entwicklung (Phase 8) viel Zeit gekostet und ist hier bewusst dokumentiert.

## 5. Schnittstellen‑Überblick (welche Funktion spricht was an)

```mermaid
flowchart LR
  subgraph common[_common.ps1]
    s[Submit-DocumentRequest] --> orA[POST /api/document-requests]
    g[Get-RequestStatus / Wait-Outcome] --> orB[GET /api/document-requests/id]
    i[Get-IncidentCount] --> orC[GET /engine-rest/incident]
    h[Wait-Health] --> hh[GET actuator/health]
  end
  orA & orB & orC --> ORCH[(Orchestrator 8080)]
  hh --> ORCH
```

## 6. Querverweise
- Nutzer dieser Bibliothek: alle Skripte, insbesondere die [Szenarien](run-smoke.md).
- Erzeugt Aufträge im Kernprozess: [`document-fulfillment`](../bpmn/document-fulfillment.md).
