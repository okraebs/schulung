# Skript · `reset-demo.ps1` — Demo zurücksetzen

> **Datei:** `scripts/reset-demo.ps1`
> **Zweck:** stoppt die Demo und löscht **nur projektlokale** Laufzeitdaten (`var\db`, `var\documents`, `var\reports`).
> **Voraussetzung:** keine; ruft selbst [`stop-demo`](stop-demo.md) auf.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | `-Force` (überspringt die Rückfrage) |
| **Aufruf** | `.\scripts\reset-demo.ps1` oder `.\scripts\reset-demo.ps1 -Force` |
| **Löscht** | Inhalte von `var\db`, `var\documents`, `var\reports` |
| **Löscht NICHT** | Code, Jars, Logs außerhalb der drei Ordner, irgendetwas außerhalb von `var\` |

## 2. Was es tut

1. ruft `stop-demo.ps1` (Dienste beenden),
2. **ohne `-Force`:** fragt „Projektlokale Demo‑Daten … wirklich loeschen? (j/N)" — nur `j` fährt fort,
3. leert die drei Unterordner (`db`, `documents`, `reports`) rekursiv,
4. meldet je Ordner „Geleert: …" und am Ende „Reset abgeschlossen."

> 🔒 **Sicherheits‑Designs:** Das Skript arbeitet **ausschließlich** unterhalb von `var\` und nur in den drei genannten Unterordnern (Kommentar im Code: „Niemals ausserhalb von var."). Die H2‑Datenbank, erzeugte PDFs und Berichte werden zurückgesetzt — die nächste Demo startet „jungfräulich".

## 3. Wann nutzen?
- Vor einer **frischen** Vorführung (keine alten Aufträge/PDFs).
- Wenn die H2‑Datei‑DB einen „sauberen Tisch" bekommen soll.
- **Nicht** nötig zwischen einzelnen `run-*`-Szenarien (die erzeugen je neue IDs).

## 4. Nachverfolgen / Prüfen
```powershell
Get-ChildItem var\db, var\documents, var\reports -Recurse   # danach leer
```

## 5. Querverweise
- Ruft auf: [`stop-demo`](stop-demo.md) · Danach neu starten: [`start-demo`](start-demo.md)
- Was in `var\` liegt: [`_common`](_common.md)
