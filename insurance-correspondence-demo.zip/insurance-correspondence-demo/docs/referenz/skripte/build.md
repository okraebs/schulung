# Skript · `build.ps1` — Bauen & Testen

> **Datei:** `scripts/build.ps1`
> **Zweck:** vollständiger Maven‑Verify über den Wrapper. Erzeugt die ausführbaren `.jar`-Dateien aller Module.
> **Voraussetzung:** Java 17 + (beim **ersten** Lauf) Internet für den Abhängigkeits‑Download.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Parameter** | keine |
| **Aufruf** | `.\scripts\build.ps1` |
| **Kernbefehl** | `.\mvnw.cmd -B clean verify` |
| **Dauer** | erster Lauf einige Minuten (Download), danach deutlich schneller |
| **Erfolg** | „Build erfolgreich." + Exit 0; sonst Abbruch mit Exit‑Fehler |

## 2. Was es tut

```powershell
. "$PSScriptRoot\_common.ps1"
Push-Location $Root
& "$Root\mvnw.cmd" -B clean verify
if ($LASTEXITCODE -ne 0) { throw "Build fehlgeschlagen (Exit $LASTEXITCODE)" }
```
1. Wechselt in die Projektwurzel (`Push-Location $Root`).
2. Ruft den **Maven Wrapper** (`mvnw.cmd`) mit `-B` (batch/non‑interactive) und den Zielen **`clean verify`** auf.
3. Prüft `$LASTEXITCODE` und meldet Erfolg/Fehler; `finally` stellt das Verzeichnis zurück (`Pop-Location`).

## 3. Was `clean verify` alles auslöst (laut `pom.xml`)

| Phase/Plugin | Wirkung |
|---|---|
| **Enforcer** | erzwingt **Java [17,18)** und **Maven [3.9,4.0)** — bricht bei falscher Version ab |
| **clean** | löscht alte `target/`-Verzeichnisse |
| **compile** | kompiliert mit `-parameters` (nötig für Jackson‑Records/Spring‑Binding) |
| **Spotless** | prüft Formatierung (Palantir Java Format) — Abweichung = Build‑Fehler |
| **Surefire** | Unit‑Tests (`*Test`/`*Tests`) |
| **Failsafe** | Integrationstests (`*IT`) inkl. `integration-test`+`verify` |
| **JaCoCo** | Coverage‑Report |
| **spring-boot:repackage** | erzeugt die ausführbaren „fat jars" |

> 🌐 **Erster Lauf braucht Internet:** Maven lädt alle Abhängigkeiten (Camunda 7.24, Spring Boot 3.5.5, OpenPDF …) aus Maven Central in `C:\Users\<name>\.m2`. Danach läuft der Build offline. Ohne Internet beim ersten Mal: lokales `.m2`-Repository mitkopieren.

## 4. Nachverfolgen
- **Konsole:** Maven‑Reactor‑Ausgabe (Modul für Modul `BUILD SUCCESS`).
- **Ergebnis:** je Modul `…/target/<modul>.jar`. Prüfbar mit `Test-Path orchestrator-app\target\orchestrator-app.jar`.
- **Reports:** Test-/Coverage‑Ausgaben unter den jeweiligen `target/`-Ordnern.

## 5. Wann nötig?
**Einmalig** beim ersten Mal und **nach Code‑Änderungen**. Für reines Starten einer bereits gebauten Demo **nicht** nötig.

## 6. Querverweise
- Davor: [`setup-check`](setup-check.md) · Danach: [`start-demo`](start-demo.md)
