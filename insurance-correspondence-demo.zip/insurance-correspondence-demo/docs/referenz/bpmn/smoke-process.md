# BPMN · `smoke-process.bpmn` — der Deployment‑Smoke

> **Datei:** `orchestrator-app/src/main/resources/processes/smoke-process.bpmn`
> **Process‑Key:** `smoke_process` · **Name:** „Smoke‑Demo"
> **Zweck:** ein **bewusst minimaler** Prozess, der nur beweist, dass das Deployment funktioniert.

---

## ⚠️ Wichtig: nicht mit `run-smoke.ps1` verwechseln!

Trotz des ähnlichen Namens haben diese beiden **nichts** miteinander zu tun:

| | `smoke_process` (diese BPMN) | `run-smoke.ps1` (Skript) |
|---|---|---|
| Was | trivialer Prozess Start → User Task → Ende | End‑to‑End‑Happy‑Path |
| Startet welchen Prozess? | sich selbst (manuell/Tasklist) | **`document_fulfillment`** |
| Aussage | „Engine deployt & führt einen Prozess aus" | „die komplette Fachkette inkl. PDF funktioniert" |

Wer den **fachlichen** Smoke‑Test sucht, ist bei [`run-smoke.ps1`](../skripte/run-smoke.md) und [`document-fulfillment`](document-fulfillment.md) richtig.

---

## 1. Auf einen Blick

| Eigenschaft | Wert | Bedeutung |
|---|---|---|
| `process id` | `smoke_process` | technischer Schlüssel. |
| `isExecutable` | `true` | ausführbar. |
| `camunda:historyTimeToLive` | `P30D` | History‑Cleanup nach 30 Tagen (Pflichtfeld, auch hier gesetzt). |
| Start | **None Start Event** | kein Auslöser/Trigger — manuell über Cockpit/REST/Tasklist startbar. |

## 2. Das Prozessbild

```mermaid
flowchart LR
  s([▶ Start]) --> r[/Smoke-Test prüfen<br/>User Task: document-ops/]
  r --> e([● Ende])
```

## 3. Elementreferenz

| Element | Typ | Gesetzte Eigenschaften | Was & warum |
|---|---|---|---|
| `start` | None Start Event | — | Einfachster Start, ohne Message/Timer. |
| `review` | **User Task** | `camunda:candidateGroups="document-ops"` | Eine einzige menschliche Aufgabe „Smoke‑Test pruefen", sichtbar für die Gruppe `document-ops` (`ops`/`ops`). Beweist, dass Tasklist‑Formulare und Gruppen‑Zuordnung greifen. |
| `end` | End Event | — | Abschluss. |

> 🔌 **Einzige Schnittstelle:** `candidateGroups="document-ops"` — dieselbe Gruppe wie in der „echten" User Task des Kernprozesses. Damit lässt sich auch die **Berechtigung** (sieht `ops` die Aufgabe? sieht `demo` sie nicht?) schnell verifizieren.

## 4. Wozu ist das gut?

- **Rauchtest** nach dem Deployment: Lässt sich überhaupt eine Instanz starten und eine Aufgabe in der Tasklist beanspruchen?
- **Schulung:** der kleinstmögliche vollständige Prozess (Start–Task–Ende) als Einstiegsbeispiel im Modeler.
- **Isolierung:** Wenn der große Prozess klemmt, zeigt dieser triviale Prozess, ob das Problem an der Engine/am Deployment liegt oder am Fachmodell.

## 5. Wie ausführen / nachverfolgen?
- **Cockpit/Tasklist:** `http://127.0.0.1:8080/camunda` (`demo`/`demo` bzw. `ops`/`ops`).
- **REST‑Start:** `POST /engine-rest/process-definition/key/smoke_process/start`.
- Danach erscheint die Aufgabe „Smoke‑Test pruefen" in der Tasklist der Gruppe `document-ops`.

## 6. Querverweise
- Der *fachliche* Smoke‑Test: [`run-smoke`](../skripte/run-smoke.md)
- Der Kernprozess: [`document-fulfillment`](document-fulfillment.md)
