# BPMN · `document-batch-planner.bpmn` — der Backpressure‑Batch

> **Datei:** `orchestrator-app/src/main/resources/processes/document-batch-planner.bpmn`
> **Process‑Key:** `document_batch_planner` · **Name:** „Batch‑Planer"
> **Eine Instanz = ein Batchlauf** (z. B. eine Beitragsanpassung über viele Verträge).

Der Batch‑Planer löst das Skalierungsproblem **elegant**: Statt einer riesigen Multi‑Instance‑Schleife über zehntausende Elemente (die alles als Prozessvariable mitschleppen würde) veröffentlicht er die Aufträge **seitenweise** und **gedrosselt** — und jeder einzelne Auftrag wird zu einer **eigenständigen** `document_fulfillment`‑Instanz. Das ist das Lehrstück „Backpressure statt Brute‑Force".

---

## 1. Auf einen Blick

| Eigenschaft | Wert | Bedeutung |
|---|---|---|
| `process id` | `document_batch_planner` | über `ProcessConstants.PROCESS_BATCH_PLANNER` referenziert. |
| `isExecutable` | `true` | ausführbar. |
| `camunda:historyTimeToLive` | `P30D` | History‑Cleanup nach 30 Tagen. |
| Start | **Timer Start Event** (`0 0 3 * * ?`) **oder** REST | Geplant täglich 03:00 Uhr; zusätzlich manuell über `POST /api/demo/batches`. |
| Kernidee | seitenweise Veröffentlichung mit Drossel | `maxInFlight` deckelt die gleichzeitig laufenden Aufträge. |
| Veröffentlichung | je Auftrag eine **eigene** `document_fulfillment`‑Instanz | über den **idempotenten** Startservice `POST /api/document-requests`. |

---

## 2. Das Prozessbild

```mermaid
flowchart TD
  ts([▶ Geplanter Lauf<br/>Timer 0 0 3 * * ? · oder REST]) --> plan[Batch planen<br/>External: plan-batch]
  plan --> check[Backpressure prüfen<br/>JavaDelegate · asyncBefore]
  check --> gwbp{unter maxInFlight?}
  gwbp -->|ja · belowLimit| publish[Seite veröffentlichen<br/>External: publish-batch-page]
  gwbp -->|nein · warten| wait[/kurz warten<br/>Timer PT3S/]
  wait --> check
  publish --> gwmore{weitere Seiten?}
  gwmore -->|ja · publishedCount &lt; totalCount| check
  gwmore -->|fertig| endb([● Batch veröffentlicht])
```

---

## 3. Elementreferenz — jedes Element, jede Eigenschaft

| Element | Typ | Gesetzte Eigenschaften | Was & warum |
|---|---|---|---|
| `timer_start` | **Timer Start Event** | `timeCycle = 0 0 3 * * ?` | Cron‑Ausdruck (Sek Min Std Tag Monat Wochentag): **täglich 03:00:00 Uhr**. Modelliert den geplanten Nachtlauf. Für Demos wird stattdessen der **REST‑Start** genutzt (s. u.), damit man nicht bis 3 Uhr warten muss. |
| `planBatch` | Service Task (External) | `camunda:type="external"` · `camunda:topic="plan-batch"` | Worker‑Handler `PlanBatchHandler` erzeugt einen **reproduzierbaren Plan** und setzt nur **kleine Steuerzahlen** als Variablen: `totalCount`, `pageSize`, `maxInFlight`, `targetRate`, `publishedCount=0`. **Niemals** wird die ganze Auftragsliste als Variable gespeichert. |
| `checkBackpressure` | Service Task (JavaDelegate) | `camunda:asyncBefore="true"` · `camunda:delegateExpression="${backpressureCheckDelegate}"` | Bean `backpressureCheckDelegate` vergleicht die Zahl der aktuell laufenden Aufträge dieses Batches gegen `maxInFlight` und setzt die boolesche Variable **`belowLimit`**. **Drei eingehende Flows**: nach dem Planen, nach dem Warten, nach „weitere Seiten". |
| `gw_bp` | Exclusive Gateway | `default="f_bp_wait"` | „Unter maxInFlight?" — verzweigt nach `belowLimit`. |
| `wait_backpressure` | **Intermediate Catch (Timer)** | `timeDuration = PT3S` | Wartet **3 Sekunden** und prüft erneut. Das ist die **Drossel**: ist das System voll, hält der Planer kurz inne, statt weiter Last zu erzeugen. |
| `publishPage` | Service Task (External) | `camunda:type="external"` · `camunda:topic="publish-batch-page"` | `PublishBatchPageHandler` veröffentlicht **genau eine** Seite (`pageSize` Aufträge ab Offset `publishedCount`) und erhöht `publishedCount`. Jeder Auftrag wird per `POST /api/document-requests` gestartet. |
| `gw_more` | Exclusive Gateway | `default="f_more_end"` | „Weitere Seiten?" — verzweigt nach `publishedCount < totalCount`. |
| `end_batch` | End Event | — | Alle Seiten veröffentlicht. |

> ⏱️ **Warum `asyncBefore` auf `checkBackpressure`?** Die Backpressure‑Schleife (`check → wait → check → …`) könnte sonst in **einer** Engine‑Transaktion „heißlaufen". Mit `asyncBefore` wird vor jeder Prüfung committet und der Job‑Executor übernimmt — die Schleife wird zu sauberen, einzeln wiederaufsetzbaren Häppchen, und der Timer `PT3S` wirkt als echte Pause.

---

## 4. Gateways & Verzweigungen

| Gateway | `default` | Flow | Bedingung | Ziel |
|---|---|---|---|---|
| `gw_bp` „unter maxInFlight?" | `f_bp_wait` | `f_bp_publish` | `${belowLimit}` | `publishPage` |
| | | `f_bp_wait` *(default)* | — (voll) | `wait_backpressure` |
| `gw_more` „weitere Seiten?" | `f_more_end` | `f_more_check` | `${publishedCount < totalCount}` | `checkBackpressure` |
| | | `f_more_end` *(default)* | — (fertig) | `end_batch` |

**Zwei Schleifen:**
- **Drossel‑Schleife:** `gw_bp →(nein)→ wait_backpressure →(PT3S)→ checkBackpressure` — warten, bis wieder Kapazität frei ist.
- **Seiten‑Schleife:** `gw_more →(ja)→ checkBackpressure` — nächste Seite, aber erneut erst nach Backpressure‑Prüfung.

---

## 5. Schnittstellen im Detail

### 5.1 Start: Timer **oder** REST
- **Timer** `0 0 3 * * ?` startet automatisch nachts.
- **REST** `POST /api/demo/batches` (`BatchController`) startet denselben Prozess sofort über `startProcessInstanceByKey("document_batch_planner", batchId, variables)`.
  Request‑Felder (alle optional, mit Defaults): `count` (20), `pageSize` (25), `targetRate` (3), `maxInFlight` (100), `seed` (42), `failureProfile` (HAPPY). Antwort **202 Accepted** mit `{ batchId, count }`.

### 5.2 Veröffentlichung: der idempotente Brückenkopf
`publish-batch-page` ruft **nicht** direkt die Engine, sondern den **idempotenten Startservice** `POST /api/document-requests`. Die `documentJobId`s sind **deterministisch** aus `batchId` + Index gebildet (z. B. `batch-ab12cd34-0`, `-1`, …). Dadurch ist ein **erneuter Lauf mit derselben `batchId` idempotent**: bereits gestartete Aufträge werden serverseitig als Dublette erkannt (HTTP 200 statt 201), es entstehen **keine** Doppelinstanzen.

> 🔌 **Warum unabhängige Instanzen statt Multi‑Instance?** Eine Multi‑Instance‑Subprocess‑Schleife über 30.000 Elemente hielte die gesamte Collection als Prozessvariable und einen riesigen Token‑Baum in **einer** Instanz — schlecht für History, Speicher und Wiederanlauf. Hier ist jeder Auftrag **autonom**: eigene Instanz, eigene History, eigener Wait‑State, einzeln im Cockpit reparierbar. Der Planer steuert nur die **Rate**.

---

## 6. Wie verfolge ich einen Batch nach?

| Werkzeug | Was du siehst | Zugang |
|---|---|---|
| **Batch‑Status‑REST** | Konsistenzbilanz des Batches | `GET /api/demo/batches/<batchId>` |
| **Cockpit** | die *eine* Planer‑Instanz **und** die *vielen* `document_fulfillment`‑Instanzen | `http://127.0.0.1:8080/camunda` |
| **Skript** | bequemer End‑to‑End‑Lauf inkl. Bilanz | [`run-load.ps1`](../skripte/run-load.md) |

Die **Batch‑Bilanz** (`GET /api/demo/batches/<id>`) aggregiert über alle `document_fulfillment`‑Instanzen mit passender `batchId`:

| Feld | Bedeutung |
|---|---|
| `planned` | Soll (`totalCount` des Planers) |
| `started` | tatsächlich gestartete Aufträge |
| `active` | noch laufende |
| `manual` | in der User Task `manualReview` wartende |
| `incident` | mit technischem Incident |
| `fullyDispatched` / `degradedDispatched` / `cancelled` | Endzustände (nach `outcome`) |

> ✅ **Konsistenz‑Check** (macht `run-load.ps1`): `started == fully + degraded + cancelled + active + manual`. Geht die Rechnung auf, ist kein Auftrag „verloren" gegangen.

---

## 7. Querverweise
- Erzeugt Instanzen von: [`document-fulfillment`](document-fulfillment.md)
- Treibendes Skript: [`run-load`](../skripte/run-load.md)
- Worker‑Handler: `PlanBatchHandler` (`plan-batch`), `PublishBatchPageHandler` (`publish-batch-page`)
