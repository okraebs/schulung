# BPMN · `document-fulfillment.bpmn` — der Kernprozess

> **Datei:** `orchestrator-app/src/main/resources/processes/document-fulfillment.bpmn`
> **Process‑Key:** `document_fulfillment` · **Name:** „Dokumentauftrag erfuellen"
> **Eine Instanz = genau ein Dokumentauftrag.** Der `documentJobId` ist gleichzeitig **Business Key** und **Idempotenzschlüssel**.

Dieser Prozess orchestriert den gesamten Lebensweg eines Korrespondenzdokuments: Daten beschaffen → fachlich bewerten (DMN) → PDF erzeugen → technisch übergeben → auf die asynchrone Annahme warten → abgleichen → abschließen. Er ist das Zentrum der Demo; alle Skripte außer dem Batch‑/Smoke‑Sonderfall starten **diesen** Prozess.

---

## 1. Auf einen Blick

| Eigenschaft | Wert | Bedeutung |
|---|---|---|
| `process id` | `document_fulfillment` | Technischer Schlüssel, über `ProcessConstants.PROCESS_DOCUMENT_FULFILLMENT` referenziert. |
| `isExecutable` | `true` | Die Engine darf den Prozess ausführen (nicht nur Doku). |
| `camunda:historyTimeToLive` | `P30D` | Historische Instanzen werden nach **30 Tagen** durch den History‑Cleanup entfernt. Pflichtangabe in Camunda 7.24; verhindert unbegrenztes Wachstum der History‑Tabellen. |
| Start | **Message Start Event** `DocumentRequestReceived` | Einzelereignis **und** Batch nutzen denselben idempotenten Startweg. |
| Wait States | **1× Receive Task** + Timer, **1× User Task** | Langlaufend: überlebt Neustarts (Nachweis: `run-restart-demo.ps1`). |
| Beteiligte Module | Orchestrator (Engine, Delegates, DMN), Worker (External Tasks), Simulator (Quell-/Output‑System) | siehe Spalte „Läuft in" der Elementtabelle. |

**Zwei Nachrichten (`<bpmn:message>`):**

| Message‑ID | `name` (Korrelationsname) | Verwendet von |
|---|---|---|
| `msg_DocumentRequestReceived` | `DocumentRequestReceived` | Start Event (Prozessstart) |
| `msg_DeliveryResultReceived` | `DeliveryResultReceived` | Receive Task (Fortsetzung nach Zustellbestätigung) |

> 💡 **Warum Message und nicht „None Start Event"?** Beim Message Start kann die Engine über `startProcessInstanceByMessage(...)` **idempotent** und einheitlich starten — egal ob die Anfrage von einem einzelnen Event (`run-smoke`) oder aus dem Batch‑Planer (`publish-batch-page`) kommt. Der `name`‑Wert (nicht die ID!) ist der fachliche Korrelationsschlüssel, der im Java‑Code als `ProcessConstants.MSG_DOCUMENT_REQUEST_RECEIVED` steht — **eine** Definitionsstelle, keine Tippfehler‑Divergenz.

---

## 2. Das Prozessbild

```mermaid
flowchart TD
  start([▶ Dokumentanfrage empfangen<br/>Message: DocumentRequestReceived]) --> normalize[Anfrage normalisieren<br/>JavaDelegate]
  normalize --> loadCustomer[Kundendaten beschaffen<br/>External: load-customer-data]
  loadCustomer --> loadContract[Vertragsdaten beschaffen<br/>External: load-contract-data]
  loadContract --> loadTariff[Tarifdaten beschaffen<br/>External: load-tariff-data]
  loadTariff --> evalC[Datenvollständigkeit bewerten<br/>DMN data-completeness · asyncBefore]
  evalC --> gwC{Vollständigkeit?}
  gwC -->|MANUAL_REQUIRED| manual
  gwC -->|FULL / DEGRADED_ALLOWED| evalV[Dokumentvariante<br/>DMN document-variant]
  evalV --> evalP[Auslieferungspolitik<br/>DMN delivery-policy]
  evalP --> render[Dokument erzeugen<br/>External: render-document]
  render --> dispatch[Dokument übergeben<br/>External: dispatch-document]
  dispatch --> receive[/Auf technische Annahme warten<br/>Receive: DeliveryResultReceived/]
  receive --> gwD{Annahme?}
  receive -. Timer PT15S .-> reconcile[Providerstatus abgleichen<br/>External: reconcile-delivery]
  gwD -->|ACCEPTED| finalize[Ergebnis festlegen<br/>JavaDelegate]
  gwD -->|abgelehnt / unklar| manual
  reconcile --> gwR{Reconciliation?}
  gwR -->|ACCEPTED| finalize
  gwR -->|PENDING & < max| incr[Statuszähler erhöhen] --> receive
  gwR -->|endgültig unklar| manual
  manual[/Manuell klären<br/>User Task: document-ops/] --> gwM{Entscheidung?}
  gwM -->|RETRY_ENRICHMENT| loadCustomer
  gwM -->|DELIVER_REDUCED| markDeg[Reduziert markieren] --> evalV
  gwM -->|CANCEL_REQUEST| cancel[Abbrechen] --> endC([● Nach Prüfung abgebrochen])
  finalize --> endOk([● Auftrag abgeschlossen])
```

**Der „Happy Path" (Profil `HAPPY`) — geradeaus, ohne jede Abzweigung:**
`start → normalizeRequest → loadCustomer → loadContract → loadTariff → evalCompleteness (FULL) → evalVariant → evalPolicy → renderDocument → dispatchDocument → receiveResult → gw_delivery (ACCEPTED) → finalizeOutcome → end` ⇒ Outcome **`FULLY_DISPATCHED`**.

---

## 3. Elementreferenz — jedes Element, jede Eigenschaft

Legende der Spalte „Läuft in": 🟦 Orchestrator (Engine/Delegate/DMN) · 🟨 Worker (External Task) · 🟩 Simulator (über Worker‑HTTP).

### 3.1 Start & lokale Vorbereitung

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `start` | Message Start Event | `messageRef=msg_DocumentRequestReceived` | Startet die Instanz, sobald die Engine die Nachricht `DocumentRequestReceived` mit einem Business Key korreliert. Variablen aus dem REST‑Body werden als Prozessvariablen gesetzt. | 🟦 |
| `normalizeRequest` | Service Task (JavaDelegate) | `camunda:delegateExpression="${normalizeRequestDelegate}"` | Bean `normalizeRequestDelegate`. Setzt **idempotent** Defaults: `statusCheckCount=0`, `degraded=false` (nur wenn noch null). Bewusst **ohne** I/O — kurz, lokal, deterministisch, damit der Startpfad nicht an langsamer Arbeit hängt. | 🟦 |

> 🔌 **Schnittstelle „delegateExpression"**: `${normalizeRequestDelegate}` ist ein **Spring‑Bean‑Name**. Die Engine sucht zur Laufzeit eine Bean dieses Namens (`@Component("normalizeRequestDelegate")`), die `JavaDelegate.execute(...)` implementiert. Im Gegensatz zu External Tasks läuft dieser Code **in‑process im Orchestrator**, synchron in der Engine‑Transaktion.

### 3.2 Datenbeschaffung (drei External Tasks)

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `loadCustomer` | Service Task | `camunda:type="external"` · `camunda:topic="load-customer-data"` | Worker holt Kundendaten vom Simulator (`GET /sim/customers/{id}`). Schreibt nur **kleine Skalare** zurück (`customerDataStatus`, `language`, `customerFederalState`, `deliveryChannel` …) — **keine** personenbezogenen Inhalte als Prozessvariablen. **Zwei eingehende Flows**: vom Normalisieren **und** vom Retry‑Pfad (`f_retry`) der manuellen Klärung. | 🟨→🟩 |
| `loadContract` | Service Task | `camunda:type="external"` · `camunda:topic="load-contract-data"` | `GET /sim/contracts/{id}`. Schreibt `contractDataStatus` und `product` (Eingabe für Tarif + DMN). | 🟨→🟩 |
| `loadTariff` | Service Task | `camunda:type="external"` · `camunda:topic="load-tariff-data"` | `GET /sim/tariffs/{product}`. Schreibt `tariffDataStatus`. | 🟨→🟩 |

> 🔌 **Schnittstelle „External Task / topic"** — das wichtigste Integrationsmuster der Demo:
> `camunda:type="external"` bedeutet: Die Engine **führt hier nichts selbst aus**, sondern legt eine Aufgabe in die „External‑Task‑Liste", versehen mit dem `topic`. Ein externer Prozess (der **Worker**, Port 8081) **pollt** per REST (`fetchAndLock`) Aufgaben seines Topics, arbeitet sie ab und meldet `complete` (mit Ergebnis­variablen) oder `handleFailure`/`handleBpmnError` zurück.
> **Warum so?** Entkopplung: I/O‑lastige Arbeit (HTTP zu Quellsystemen, PDF‑Erzeugung) belastet die Engine nicht, ist unabhängig skalierbar/neustartbar, und ist im Cockpit als eigene Aufgabe sichtbar. Die **exakte Zeichenkette** des Topics ist der Vertrag zwischen BPMN und Worker — sie steht beidseitig in `ProcessConstants` (z. B. `TOPIC_LOAD_CUSTOMER = "load-customer-data"`), damit BPMN‑Attribut und `@ExternalTaskSubscription(topicName=…)` garantiert übereinstimmen.

**Topic → Worker‑Handler (der „Steckverbinder"):**

| `camunda:topic` | Worker‑Handler‑Klasse | Liest Variablen | Schreibt zurück |
|---|---|---|---|
| `load-customer-data` | `LoadCustomerDataHandler` | `customerId`, `failureProfile`, `correctedEmail?`, `correctedPostalAddress?` | `customerDataStatus`, `language`, `customerFederalState`, `deliveryChannel`, … |
| `load-contract-data` | `LoadContractDataHandler` | `contractId`, `failureProfile` | `contractDataStatus`, `product` |
| `load-tariff-data` | `LoadTariffDataHandler` | `product`, `failureProfile` | `tariffDataStatus` |
| `render-document` | `RenderDocumentHandler` | `documentJobId`, `failureProfile`, `documentType`, `templateId?`, `language?`, `degraded` … | `documentUri`, `documentSha256`, `documentSize`, `documentContentType` |
| `dispatch-document` | `DispatchDocumentHandler` | `documentJobId`, `customerId`, `documentUri`, `deliveryChannel?`, `deliveryPriority?` | `deliveryRequestId` |
| `reconcile-delivery` | `ReconcileDeliveryHandler` | `deliveryRequestId` | `deliveryResultStatus`, `providerReference` |

### 3.3 Fachliche Bewertung (drei Business Rule Tasks → DMN)

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `evalCompleteness` | Business Rule Task | `camunda:asyncBefore="true"` · `camunda:decisionRef="data-completeness"` · `camunda:mapDecisionResult="singleResult"` · `camunda:resultVariable="completenessResult"` · ExecutionListener `end` → `MapResultFlattenerListener` (`source=completenessResult`) | Wertet **DMN `data-completeness`** aus → `completenessClass`, `degraded`, `degradationAllowed`, `missingRequiredFields`, `degradationReasons`. | 🟦 |
| `evalVariant` | Business Rule Task | `camunda:decisionRef="document-variant"` · `mapDecisionResult="singleResult"` · `resultVariable="variantResult"` · Listener `source=variantResult` | **DMN `document-variant`** → `templateId`, `legalTextKey`, `attachmentKeys`. **Zwei eingehende Flows**: regulär **und** vom „Reduziert ausliefern"-Pfad (`f_reduced_variant`). | 🟦 |
| `evalPolicy` | Business Rule Task | `camunda:decisionRef="delivery-policy"` · `mapDecisionResult="singleResult"` · `resultVariable="policyResult"` · Listener `source=policyResult` | **DMN `delivery-policy`** → `deliveryChannel`, `requiresTechnicalAck`, `acknowledgementTimeout`, `maxStatusChecks`, `deliveryPriority`. | 🟦 |

> 🔌 **Schnittstelle „decisionRef + mapDecisionResult + resultVariable + Listener"** — so hängt eine Entscheidungstabelle am Prozess:
> 1. `camunda:decisionRef="data-completeness"` referenziert die **`decision id`** in der DMN‑Datei (nicht den Dateinamen!). Die Engine wertet diese Entscheidung mit den aktuellen Prozessvariablen als Input aus.
> 2. `mapDecisionResult="singleResult"` heißt: Es wird **genau eine** Ergebniszeile erwartet (passt zu Hit Policy **FIRST** der Tabelle) und als **Map** (`{Spaltenname → Wert}`) geliefert.
> 3. `resultVariable="completenessResult"` legt diese Map zunächst unter dem Namen `completenessResult` ab.
> 4. Der **ExecutionListener** `MapResultFlattenerListener` (Event `end`) liest über das injizierte Feld `source` den Namen `completenessResult`, **flacht die Map auf** — schreibt also jeden Schlüssel (`completenessClass`, `degraded`, …) als **eigene** Prozessvariable auf oberster Ebene — und **entfernt** danach die temporäre `completenessResult`‑Variable.
> **Warum dieser Umweg?** So bleiben die DMN‑Ausgaben als saubere, einzeln adressierbare Prozessvariablen verfügbar (Gateways und Folge‑Tasks lesen z. B. direkt `${completenessClass}`), ohne dass im Modell jede Spalte einzeln verdrahtet werden muss.

> ⏱️ **Warum `asyncBefore="true"` ausgerechnet auf `evalCompleteness`?** Die `asyncBefore`‑Grenze setzt einen **Transaktions‑Commit‑Punkt** *vor* der Regelbewertung. Die teure, erfolgreich abgeschlossene Datenanreicherung (drei External Tasks) wird damit **dauerhaft festgeschrieben**, **bevor** die Regelauswertung läuft. Schlägt die Bewertung fehl oder wird wiederholt, muss die Anreicherung nicht erneut passieren. Gleichzeitig ist es der saubere Wiederaufsetzpunkt für den asynchronen Job‑Executor.

### 3.4 Herstellung & Übergabe

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `renderDocument` | Service Task | `camunda:type="external"` · `camunda:topic="render-document"` | Erzeugt ein **echtes PDF** (OpenPDF) und legt es unter `var/documents/<id>/` ab. In die Prozessvariablen kommen nur **Referenz, Hash, Größe, Content‑Type** — nicht das Dokument selbst. **Hier** wird `PERMANENT_RENDER_FAILURE` zum Incident (siehe §6). | 🟨 |
| `dispatchDocument` | Service Task | `camunda:type="external"` · `camunda:topic="dispatch-document"` | Schreibt **Delivery Request + Outbox‑Event** in **einer lokalen Transaktion** (idempotent je `documentJobId`) und schließt den External Task **erst nach Commit** ab. Der eigentliche Versand an den Simulator erfolgt asynchron durch den **Outbox‑Publisher** (`@Scheduled`, alle 2 s). | 🟨 |

> 🧩 **Transaktionskonzept (warum Outbox?):** Der Worker kann nicht „Datenbank schreiben **und** HTTP versenden" in einer verteilten ACID‑Transaktion. Stattdessen: in der lokalen TX nur **Absicht** persistieren (Outbox‑Zeile `NEW`), External Task abschließen; ein separater Publisher liest `NEW`‑Zeilen und sendet sie an den Simulator (`POST /sim/output/delivery-requests`). Schlägt der Versand fehl, bleibt die Zeile `NEW` und wird beim nächsten Tick erneut versucht. Der Simulator **dedupliziert** über `documentJobId`, daher ist Mehrfachversand harmlos.

### 3.5 Warten auf die technische Annahme (der Wait‑State)

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `receiveResult` | **Receive Task** | `messageRef=msg_DeliveryResultReceived` | **Hält** die Instanz an, bis die Nachricht `DeliveryResultReceived` korreliert wird. **Zwei eingehende Flows**: nach Dispatch **und** aus der Retry‑Schleife (`f_increment_receive`). Dieser Wait‑State liegt persistent in der DB → überlebt einen Orchestrator‑Neustart. | 🟦 |
| `timer_ack` | **Interrupting Timer Boundary Event** | `attachedToRef="receiveResult"` · `cancelActivity="true"` · `timeDuration=${acknowledgementTimeout != null ? acknowledgementTimeout : "PT15S"}` | Bricht das Warten ab, wenn binnen Frist **keine** Bestätigung kcommt, und leitet zur **Reconciliation** (aktives Nachfragen). `cancelActivity=true` → unterbrechend (die Receive Task wird beendet). | 🟦 |

> 🔌 **Schnittstelle „Receive Task + Message Correlation"** — so kommt die Außenwelt zurück in den Prozess:
> Der Simulator sendet nach der Annahme einen **Callback** an `POST /api/delivery-results`. Der Orchestrator legt ihn zuerst in die **Inbox** (`delivery_callback_inbox`, Dedup über `callbackEventId`) und korreliert dann via `MessageCorrelator`:
> ```java
> runtimeService.createMessageCorrelation("DeliveryResultReceived")
>     .processInstanceBusinessKey(documentJobId)        // ⇐ findet GENAU diese Instanz
>     .setVariable("deliveryResultStatus", …)           // ⇐ füllt die Gateway-Variable
>     .setVariable("providerReference", …)
>     .correlate();
> ```
> Die **Inbox + ein Scheduler** (`InboxCorrelationScheduler`, alle 3 s) sorgen dafür, dass ein Callback, der **zu früh** (vor Erreichen der Receive Task) oder **während eines Orchestrator‑Neustarts** eintrifft, **gepuffert** und später zugestellt wird. Genau das beweist `run-restart-demo.ps1`.

> ⏱️ **Warum der Timer‑Ausdruck `${acknowledgementTimeout != null ? acknowledgementTimeout : "PT15S"}`?** Die Frist ist **datengetrieben**: die DMN `delivery-policy` liefert `acknowledgementTimeout` (hier überall `PT15S`). Falls die Variable fehlt, greift der **Fallback `PT15S`** direkt im Modell — der Prozess bleibt robust, auch wenn die Policy einmal nichts liefert. ISO‑8601‑Dauer: `PT15S` = 15 Sekunden (Demo‑freundlich kurz).

### 3.6 Abgleich (Reconciliation) & Schleife

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `reconcileDelivery` | Service Task | `camunda:type="external"` · `camunda:topic="reconcile-delivery"` | Fragt aktiv den Providerstatus ab (`GET /sim/output/delivery-requests/{id}/status`) → setzt `deliveryResultStatus` (ACCEPTED/PENDING/REJECTED/UNKNOWN). Reiner Lesezugriff; bei Fehler `UNKNOWN`. | 🟨→🟩 |
| `incrementStatusCheck` | Service Task (JavaDelegate) | `camunda:delegateExpression="${incrementStatusCheckDelegate}"` | Erhöht `statusCheckCount` um 1 und führt **zurück zur Receive Task** — kontrolliertes erneutes Warten statt Endlosabfrage. | 🟦 |

### 3.7 Manuelle Klärung (User Task)

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `manualReview` | **User Task** | `camunda:candidateGroups="document-ops"` · `name="Dokumentauftrag manuell klaeren: ${documentJobId}"` · `formData` (10 Felder) · TaskListener `create` **und** `complete` → `ManualReviewTaskListener` | Menschliche Klärung. **Drei eingehende Flows**: Pflichtdatenmangel (`f_gw_manual`), abgelehnte/unklare Annahme (`f_delivery_manual`), endgültig unklare Reconciliation (`f_recon_manual`). | 🟦 (Mensch) |

> 🔌 **Schnittstelle „candidateGroups + Formular + TaskListener":**
> - `candidateGroups="document-ops"` (Konstante `GROUP_DOCUMENT_OPS`): Nur Mitglieder der Gruppe `document-ops` sehen/beanspruchen die Aufgabe — in der Demo der Benutzer `ops`/`ops`.
> - `name` enthält den **Ausdruck `${documentJobId}`** → die Aufgabe trägt den Auftrag im Titel (in der Tasklist sofort erkennbar).
> - Das **`formData`** erzeugt das generierte Tasklist‑Formular. Das Schlüsselfeld ist das Enum `manualResolution` mit drei Werten — sie steuern direkt das nachfolgende Gateway:
>
> | `manualResolution` | Label | Folge |
> |---|---|---|
> | `RETRY_ENRICHMENT` | „Erneut anreichern" | zurück zu `loadCustomer` (mit `correctedEmail`/`correctedPostalAddress`) |
> | `DELIVER_REDUCED` | „Reduziert ausliefern" | nur erlaubt bei `degradationAllowed=true` |
> | `CANCEL_REQUEST` | „Auftrag abbrechen" | Outcome `CANCELLED_AFTER_MANUAL_REVIEW` |
>
> - **TaskListener `create`**: setzt `manualReason` automatisch (`MISSING_MANDATORY_DATA`, falls `missingRequiredFields` gesetzt, sonst `DELIVERY_ISSUE`).
> - **TaskListener `complete`**: **validiert** die Entscheidung — eine ungültige `manualResolution` oder ein `DELIVER_REDUCED` **ohne** erlaubte Degradation wirft eine `ProcessEngineException` und **rollt das Abschließen zurück** (die Aufgabe bleibt offen). So kann ein Bearbeiter keine unzulässige Reduktion freigeben.

### 3.8 Abschluss‑Tasks & Ende

| Element | Typ | Gesetzte Eigenschaften | Was & warum | Läuft in |
|---|---|---|---|---|
| `markDegraded` | Service Task (JavaDelegate) | `${markDegradedDelegate}` | Setzt `degraded=true`, ergänzt `degradationReasons` um `"manuelleFreigabeReduziert"`, führt zurück zu `evalVariant` (neue Variante unter Degradation). | 🟦 |
| `cancelOutcome` | Service Task (JavaDelegate) | `${cancelOutcomeDelegate}` | Setzt `outcome="CANCELLED_AFTER_MANUAL_REVIEW"`, Zähler `documents.dispatched{outcome=…}` +1. | 🟦 |
| `finalizeOutcome` | Service Task (JavaDelegate) | `${finalizeOutcomeDelegate}` | Setzt `outcome = degraded ? "DEGRADED_DISPATCHED" : "FULLY_DISPATCHED"`. **Zwei eingehende Flows**: aus `gw_delivery` (ACCEPTED) und `gw_reconcile` (ACCEPTED). | 🟦 |
| `end` | End Event | — | Erfolgreicher Abschluss. |
| `end_cancelled` | End Event | — | Abschluss nach Abbruch. |

> 🎯 **Die drei möglichen Endzustände (`outcome`)** — die einzigen Werte des Enums `Outcome`:
> `FULLY_DISPATCHED` · `DEGRADED_DISPATCHED` · `CANCELLED_AFTER_MANUAL_REVIEW`.
> Bewusst **kein** `MANUAL_REVIEW`/`TECHNICAL_INCIDENT` — das sind *aktive Wartezustände*, keine Endzustände.

---

## 4. Gateways & Verzweigungen — die vollständige Kreuztabelle

Alle vier Exklusiv‑Gateways haben einen **Default‑Flow** (greift, wenn keine Bedingung zutrifft) — das verhindert „steckengebliebene" Token.

| Gateway | `default` | Ausgehender Flow | Bedingung (`conditionExpression`) | Ziel |
|---|---|---|---|---|
| `gw_completeness` „Vollständigkeit?" | `f_gw_variant` | `f_gw_manual` | `${completenessClass == "MANUAL_REQUIRED"}` | `manualReview` |
| | | `f_gw_variant` *(default)* | — | `evalVariant` |
| `gw_delivery` „Annahme?" | `f_delivery_manual` | `f_delivery_accept` | `${deliveryResultStatus == "ACCEPTED"}` | `finalizeOutcome` |
| | | `f_delivery_manual` *(default)* | — (abgelehnt/unklar) | `manualReview` |
| `gw_reconcile` „Reconciliation?" | `f_recon_manual` | `f_recon_accept` | `${deliveryResultStatus == "ACCEPTED"}` | `finalizeOutcome` |
| | | `f_recon_retry` | `${deliveryResultStatus == "PENDING" && statusCheckCount < maxStatusChecks}` | `incrementStatusCheck` |
| | | `f_recon_manual` *(default)* | — (endgültig unklar) | `manualReview` |
| `gw_manual` „Entscheidung?" | `f_reduced` | `f_cancel` | `${manualResolution == "CANCEL_REQUEST"}` | `cancelOutcome` |
| | | `f_retry` | `${manualResolution == "RETRY_ENRICHMENT"}` | `loadCustomer` |
| | | `f_reduced` *(default)* | — (`DELIVER_REDUCED`) | `markDegraded` |

> 🧭 **Lesehilfe Default‑Flow:** Ein als `default` markierter Flow hat **keine** Bedingung und wird nur genommen, wenn **alle** anderen Bedingungen falsch sind. Beispiel `gw_manual`: `DELIVER_REDUCED` hat absichtlich keine eigene Bedingung — es ist der Default. Die *eigentliche* Zulässigkeitsprüfung von `DELIVER_REDUCED` macht der `ManualReviewTaskListener` beim Abschließen, nicht das Gateway.

**Die zwei Rückwärtskanten (Schleifen):**
- `f_retry`: `gw_manual → loadCustomer` — kompletter Neudurchlauf der Anreicherung nach Korrektur.
- `f_recon_retry → incrementStatusCheck → f_increment_receive → receiveResult` — begrenztes erneutes Warten, gedeckelt durch `statusCheckCount < maxStatusChecks`.

---

## 5. Prozessvariablen — woher, wohin

| Variable | Gesetzt von | Gelesen von |
|---|---|---|
| `documentJobId`, `customerId`, `contractId`, `documentType`, `failureProfile`, `requestedAt`, `sourceEventId`, `requestSource`, `batchId?` | REST‑Start (`DocumentRequestService`) | nahezu alle Tasks; `documentJobId` = Business Key |
| `statusCheckCount`, `degraded` | `normalizeRequest` (Defaults) | `gw_reconcile`, `finalizeOutcome`, `incrementStatusCheck` |
| `customerDataStatus`, `language`, `deliveryChannel`, `customerFederalState` | `loadCustomer` | DMN `data-completeness`/`document-variant`/`delivery-policy` |
| `contractDataStatus`, `product` | `loadContract` | `loadTariff`, DMN |
| `tariffDataStatus` | `loadTariff` | DMN `data-completeness` |
| `completenessClass`, `degraded`, `degradationAllowed`, `missingRequiredFields`, `degradationReasons` | DMN `data-completeness` (via Flattener) | `gw_completeness`, User Task, `markDegraded` |
| `templateId`, `legalTextKey`, `attachmentKeys` | DMN `document-variant` | `renderDocument` |
| `deliveryChannel`, `requiresTechnicalAck`, `acknowledgementTimeout`, `maxStatusChecks`, `deliveryPriority` | DMN `delivery-policy` | `timer_ack`, `dispatchDocument`, `gw_reconcile` |
| `documentUri`, `documentSha256`, `documentSize`, `documentContentType` | `renderDocument` | `dispatchDocument` |
| `deliveryRequestId` | `dispatchDocument` | `reconcileDelivery`, Callback‑Korrelation |
| `deliveryResultStatus`, `providerReference` | Callback‑Korrelation **oder** `reconcileDelivery` | `gw_delivery`, `gw_reconcile` |
| `manualResolution`, `manualReason`, `manualComment`, `correctedEmail`, `correctedPostalAddress` | User Task (Formular) | `gw_manual`, `loadCustomer` (Retry) |
| `outcome` | `finalizeOutcome` / `cancelOutcome` | Status‑REST, Batch‑Aggregation |

---

## 6. Fehlerbehandlung im Modell

Das Modell unterscheidet bewusst **fachliche** und **technische** Abweichungen:

- **Fachlich** (Pflichtdaten fehlen, Annahme abgelehnt, Timeout unklar) → läuft über **DMN/Gateways** in die **User Task**. Kein BPMN‑Fehler, sondern modellierter Pfad.
- **Technisch vorübergehend** (`TRANSIENT_SOURCE_FAILURE`: Quellsystem 503) → **External‑Task‑Retries** im Worker; der Auftrag heilt von selbst.
- **Technisch dauerhaft** (`PERMANENT_RENDER_FAILURE`) → der `RenderDocumentHandler` wirft deterministisch, dekrementiert die Retries und ruft `handleFailure(... retries=0 ...)` → die Engine erzeugt einen **Incident** an `renderDocument`. Behebung im Cockpit (Variable `failureProfile=HAPPY`, Retries hochsetzen) — genau das zeigt `run-incident-demo.ps1`.

> ℹ️ Hinweis: Es existiert die Konstante `ERROR_PERMANENT_RENDER_FAILURE`, der Render‑Fehler wird in dieser Implementierung aber als **technischer Incident** (Retries→0) realisiert, **nicht** als BPMN‑Error‑Boundary. Das ist Absicht: Incidents sind im Cockpit die natürliche „Reparaturstelle" für technische Störungen.

---

## 7. Wie verfolge ich diesen Prozess nach?

| Werkzeug | Was du siehst | Zugang |
|---|---|---|
| **Cockpit** | Laufende/abgeschlossene Instanz, aktuell „leuchtendes" Element, Variablen, Incidents, Token‑Position | `http://127.0.0.1:8080/camunda` → `demo`/`demo` |
| **Tasklist** | Offene User Task `manualReview` (nur Gruppe `document-ops`) | dito → `ops`/`ops` |
| **Status‑REST** | `status`, `activeActivity`, `outcome` der Instanz | `GET /api/document-requests/<documentJobId>` |
| **Engine‑REST** | External Tasks, Incidents, Tasks roh | `GET /engine-rest/external-task?...`, `/incident?...` |
| **Worker‑Logs** | `fetchAndLock`/`complete`, MDC mit `documentJobId` | `var/logs/worker.out.log` |
| **Dateisystem** | erzeugtes PDF | `var/documents/<documentJobId>/document.pdf` |

> 🔎 **Tipp:** Im Cockpit zeigt der Reiter *„Called Decision Instances"* zu den Business Rule Tasks, welche DMN‑Regel gefeuert hat — ideal, um zu sehen, **warum** ein Auftrag z. B. in `MANUAL_REQUIRED` lief.

---

## 8. Querverweise
- DMN: [`data-completeness`](../dmn/data-completeness.md) · [`document-variant`](../dmn/document-variant.md) · [`delivery-policy`](../dmn/delivery-policy.md)
- Skripte, die diesen Prozess starten: [`run-smoke`](../skripte/run-smoke.md) (HAPPY), [`run-manual-review-demo`](../skripte/run-manual-review-demo.md) (User‑Task‑Pfad), [`run-incident-demo`](../skripte/run-incident-demo.md) (Incident an `renderDocument`), [`run-restart-demo`](../skripte/run-restart-demo.md) (Wait‑State), [`run-load`](../skripte/run-load.md) (über den Batch‑Planer)
- Verwandter Prozess: [`document-batch-planner`](document-batch-planner.md) erzeugt je Auftrag **eine** Instanz dieses Prozesses.
