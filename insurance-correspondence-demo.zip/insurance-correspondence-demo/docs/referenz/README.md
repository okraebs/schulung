# 📚 Referenz‑Handbuch — BPMN · DMN · Skripte

Willkommen! Dieses Handbuch beschreibt **jedes** ausführbare Artefakt der Demo `insurance-correspondence-demo` in einem eigenen, didaktisch aufbereiteten Dokument: die **3 BPMN‑Prozesse**, die **3 DMN‑Entscheidungstabellen** und die **11 PowerShell‑Skripte**. Ziel ist, dass man jede gesetzte Eigenschaft, jede Schnittstelle und jeden Ablauf **versteht** — nicht nur sieht.

> Für die fachliche Gesamtschau siehe `../process-model.md` und `../trainer-guide.md`. Dieses Handbuch geht **tiefer ins Detail je Artefakt**.

---

## 1. Das große Bild

```mermaid
flowchart LR
  SC[PowerShell-Skripte] -->|REST| O
  subgraph O[Orchestrator · 8080]
    BPMN[BPMN-Prozesse<br/>document-fulfillment · batch-planner · smoke]
    DMN[DMN-Tabellen<br/>data-completeness · document-variant · delivery-policy]
  end
  O <-->|External Task<br/>fetch & complete| W[Worker · 8081]
  W -->|HTTP| S[Simulator · 8082<br/>Quell- + Output-System]
  S -->|Callback POST /api/delivery-results| O
```

- **Orchestrator (8080):** Engine, führt **BPMN** aus und wertet **DMN** aus.
- **Worker (8081):** zieht **External Tasks** (Topics) und erledigt I/O.
- **Simulator (8082):** liefert synthetische Quelldaten und spielt das Output‑Management (inkl. asynchroner Callbacks).
- **Skripte:** steuern alles über REST und PowerShell.

---

## 2. Inhalt — alle Dokumente

### 🟦 BPMN‑Prozesse (`bpmn/`)
| Dokument | Prozess | Kurz |
|---|---|---|
| [document-fulfillment](bpmn/document-fulfillment.md) | `document_fulfillment` | **der Kernprozess** — ein Dokumentauftrag von A–Z |
| [document-batch-planner](bpmn/document-batch-planner.md) | `document_batch_planner` | Backpressure‑Batch, erzeugt viele Kern‑Instanzen |
| [smoke-process](bpmn/smoke-process.md) | `smoke_process` | trivialer Deployment‑Smoke (≠ `run-smoke.ps1`!) |

### 🟪 DMN‑Entscheidungstabellen (`dmn/`)
| Dokument | Decision | Liefert |
|---|---|---|
| [data-completeness](dmn/data-completeness.md) | `data-completeness` | `completenessClass` + Degradationsflags |
| [document-variant](dmn/document-variant.md) | `document-variant` | `templateId`, `legalTextKey`, `attachmentKeys` |
| [delivery-policy](dmn/delivery-policy.md) | `delivery-policy` | Kanal, **Frist**, **max. Statusabfragen**, Priorität |

### ⚙️ Skripte (`skripte/`)
**Infrastruktur:**
| Dokument | Zweck |
|---|---|
| [_common](skripte/_common.md) | gemeinsame Bibliothek (Pfade, URLs, REST‑Helfer) |
| [setup-check](skripte/setup-check.md) | Tooling/Ports prüfen |
| [build](skripte/build.md) | bauen & testen (`mvnw clean verify`) |
| [start-demo](skripte/start-demo.md) | die drei Dienste starten |
| [stop-demo](skripte/stop-demo.md) | sauber stoppen (PID‑gesteuert) |
| [reset-demo](skripte/reset-demo.md) | projektlokale Daten zurücksetzen |

**Szenarien (jeweils ein BPMN‑Pfad):**
| Dokument | Profil | zeigt |
|---|---|---|
| [run-smoke](skripte/run-smoke.md) | `HAPPY` | Happy Path bis PDF |
| [run-manual-review-demo](skripte/run-manual-review-demo.md) | `MANDATORY_DATA_MISSING` | User Task / menschliche Klärung |
| [run-incident-demo](skripte/run-incident-demo.md) | `PERMANENT_RENDER_FAILURE` | technischer Incident + Recovery |
| [run-restart-demo](skripte/run-restart-demo.md) | `DELIVERY_TIMEOUT` | Wait‑State überlebt Neustart |
| [run-load](skripte/run-load.md) | `HAPPY` (param.) | Batch + Backpressure + Last |

---

## 3. Legende — Symbole in diesem Handbuch

| Symbol | Bedeutung |
|---|---|
| 🔌 | **Schnittstelle** (Message, External‑Task‑Topic, `decisionRef`, Timer, REST, Korrelation) |
| 🟦 / 🟨 / 🟩 | läuft im **Orchestrator** / **Worker** / **Simulator** |
| ⏱️ | Timing, `asyncBefore`, Fristen, asynchrone Fortsetzung |
| 🧭 | Hit‑Policy / Regelreihenfolge (FIRST) |
| 💡 / 🧠 / 🧩 | Hinweis / Lehrpunkt |
| ⚠️ / 🐛 | Stolperstein / Gotcha |
| 🔒 | Sicherheits-/Robustheits‑Designentscheidung |

---

## 4. Lesepfade (je nach Ziel)

- **„Ich will die Demo nur vorführen."** → [setup-check](skripte/setup-check.md) → [build](skripte/build.md) → [start-demo](skripte/start-demo.md) → die `run-*`-Szenarien → [stop-demo](skripte/stop-demo.md).
- **„Ich will den Prozess verstehen."** → [document-fulfillment](bpmn/document-fulfillment.md) → die drei DMN → [run-smoke](skripte/run-smoke.md).
- **„Ich will Camunda‑Konzepte lehren."** → External Tasks & Topics (in [document-fulfillment](bpmn/document-fulfillment.md) §3.2) → DMN/FIRST ([delivery-policy](dmn/delivery-policy.md) §5) → Wait‑State & Korrelation ([run-restart-demo](skripte/run-restart-demo.md)) → Incident ([run-incident-demo](skripte/run-incident-demo.md)).
- **„Ich richte das auf einem neuen PC ein."** → [setup-check](skripte/setup-check.md) → [build](skripte/build.md) → [start-demo](skripte/start-demo.md).

---

## 5. Querverweis‑Matrix — Skript → Prozess → Pfad → Outcome

| Szenario | Profil | startet | DMN‑Schlüsseltreffer | erzwungener Pfad | Outcome |
|---|---|---|---|---|---|
| [run-smoke](skripte/run-smoke.md) | `HAPPY` | `document_fulfillment` | FULL · CCC_DE · EMAIL | gerader Hauptpfad | `FULLY_DISPATCHED` |
| [run-manual-review-demo](skripte/run-manual-review-demo.md) | `MANDATORY_DATA_MISSING` | `document_fulfillment` | completeness **Regel 1** → `MANUAL_REQUIRED` | → User Task `manualReview` | wartet → `FULLY` (RETRY) / `CANCELLED_AFTER_MANUAL_REVIEW` (CANCEL) |
| [run-incident-demo](skripte/run-incident-demo.md) | `PERMANENT_RENDER_FAILURE` | `document_fulfillment` | — (bis `renderDocument`) | **Incident** an `renderDocument` | Incident → `FULLY_DISPATCHED` (mit `-AutoFix`) |
| [run-restart-demo](skripte/run-restart-demo.md) | `DELIVERY_TIMEOUT` | `document_fulfillment` | policy `PT15S` | hält an `receiveResult`, Callback → fort | `FULLY_DISPATCHED` |
| [run-load](skripte/run-load.md) | `HAPPY` (param.) | `document_batch_planner` → N× Kern | variant **PA_***, policy **Regel 3** | Batch + Backpressure | N× `FULLY_DISPATCHED` |

---

## 6. Referenz — `FailureProfile` (die Daten-/Fehlersteuerung)

Alle Daten sind **synthetisch** und **deterministisch**; das `failureProfile` steuert reproduzierbar, was passiert. Vollständige Liste (aus `FailureProfile.java`):

| Profil | Wirkung im Simulator/Worker | genutzt von |
|---|---|---|
| `HAPPY` | alles vorhanden, Annahme‑Callback nach ~2 s | run-smoke, run-load |
| `OPTIONAL_DATA_MISSING` | nur **optionale** Felder fehlen (Berater/Marketing bzw. Tarifgrund) → `DEGRADED_ALLOWED` | DMN‑Lehre |
| `MANDATORY_DATA_MISSING` | Kunde: **`email` + `postalAddress`** fehlen → `MANUAL_REQUIRED` | run-manual-review-demo |
| `TRANSIENT_SOURCE_FAILURE` | Kunden‑Endpoint liefert **2×** HTTP 503, dann OK → External‑Task‑Retries | Retry‑Lehre |
| `PERMANENT_RENDER_FAILURE` | **Worker** wirft beim Render → Retries→0 → **Incident** | run-incident-demo |
| `DELIVERY_DELAYED` | Annahme‑Callback erst nach **20 s** (Timer/Reconciliation greift) | Timer‑Lehre |
| `DELIVERY_REJECTED` | Provider lehnt ab → Status `REJECTED` → User Task | — |
| `DELIVERY_TIMEOUT` | **kein** Callback; Status bleibt `PENDING` | run-restart-demo |
| `DUPLICATE_CALLBACK` | derselbe `callbackEventId` **2×** → Inbox‑Dedup | Idempotenz‑Lehre |
| `CALLBACK_WHILE_ORCHESTRATOR_DOWN` | Callback‑Retry (bis **8×**, alle 3 s), während Orchestrator unten | Inbox‑Lehre |

> Die Quelldaten erzeugt `SyntheticDataFactory` deterministisch aus der ID (z. B. Sprache, Bundesland, Kanal). Die IDs `C-1001`/`V-2001` sind nur **Schlüssel**, die die Skripte mitschicken.

---

## 7. External‑Task‑Topics → Worker‑Handler (der Vertrag BPMN ↔ Worker)

| Topic (`camunda:topic`) | Handler | Schreibt zurück |
|---|---|---|
| `load-customer-data` | `LoadCustomerDataHandler` | `customerDataStatus`, `language`, `deliveryChannel`, … |
| `load-contract-data` | `LoadContractDataHandler` | `contractDataStatus`, `product` |
| `load-tariff-data` | `LoadTariffDataHandler` | `tariffDataStatus` |
| `render-document` | `RenderDocumentHandler` | `documentUri`, `documentSha256`, `documentSize`, `documentContentType` |
| `dispatch-document` | `DispatchDocumentHandler` | `deliveryRequestId` |
| `reconcile-delivery` | `ReconcileDeliveryHandler` | `deliveryResultStatus`, `providerReference` |
| `plan-batch` | `PlanBatchHandler` | `totalCount`, `pageSize`, `maxInFlight`, `publishedCount` |
| `publish-batch-page` | `PublishBatchPageHandler` | `publishedCount` |

> Beide Seiten beziehen die Zeichenketten aus `ProcessConstants` — eine Definitionsstelle, keine Tippfehler.

---

## 8. Verwandte Projektdokumentation
- `../process-model.md` — Prozessmodell (Kurzfassung) · `../architecture.md` — Architektur
- `../trainer-guide.md` — Trainerleitfaden · `../exercises.md` — Übungen
- `../error-handling.md`, `../transaction-boundaries.md`, `../idempotency-outbox-reconciliation.md`
- `../../README.md` — Projekt‑Einstieg · `../../IMPLEMENTATION_STATUS.md` — Umsetzungsstand
