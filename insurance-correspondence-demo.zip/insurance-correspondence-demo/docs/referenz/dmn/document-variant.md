# DMN · `document-variant.dmn` — Dokumentvariante bestimmen

> **Datei:** `orchestrator-app/src/main/resources/dmn/document-variant.dmn`
> **Decision‑ID:** `document-variant` · **Name:** „Dokumentvariante bestimmen"
> **Hit Policy:** `FIRST` · **`historyTimeToLive`:** `P30D`
> **Aufgerufen von:** Business Rule Task `evalVariant` in [`document-fulfillment`](../bpmn/document-fulfillment.md).

Diese Tabelle wählt — abhängig von **Dokumentart** und **Sprache** — das richtige **Template**, den **Rechtstext** und etwaige **Anlagen**. Sie ist die Brücke zwischen „welcher Geschäftsvorfall" und „wie sieht das PDF konkret aus".

---

## 1. Auf einen Blick

| | |
|---|---|
| **Frage** | „Welche Vorlage + Rechtstext + Anlagen für diese Dokumentart & Sprache?" |
| **2 Eingaben** | `documentType`, `language` |
| **3 Ausgaben** | `templateId`, `legalTextKey`, `attachmentKeys` |
| **Hit Policy** | `FIRST` mit Default‑Auffangregel |

## 2. Eingaben

| Input‑Label | Ausdruck | Typ | Herkunft | Beispiele |
|---|---|---|---|---|
| Dokumentart | `documentType` | string | REST‑Start (`documentType`) | `CONTRACT_CHANGE_CONFIRMATION`, `PREMIUM_ADJUSTMENT` |
| Sprache | `language` | string | `LoadCustomerDataHandler` (`preferredLanguage`, Default `de`) | `de`, `en` |

## 3. Ausgaben

| Output‑Label | Name (→ Variable) | Typ | Verwendet von |
|---|---|---|---|
| Template | `templateId` | string | `RenderDocumentHandler` (PDF‑Vorlage) |
| Rechtstext | `legalTextKey` | string | `RenderDocumentHandler` |
| Anlagen | `attachmentKeys` | string | `RenderDocumentHandler` |

---

## 4. Die Entscheidungstabelle (vollständig)

| # | Regel | `documentType` | `language` | → `templateId` | `legalTextKey` | `attachmentKeys` |
|---|---|---|---|---|---|---|
| 1 | `v_ccc_de` | `CONTRACT_CHANGE_CONFIRMATION` | `de` | `CCC_DE` | `legal_ccc` | `""` |
| 2 | `v_ccc_en` | `CONTRACT_CHANGE_CONFIRMATION` | `en` | `CCC_EN` | `legal_ccc` | `""` |
| 3 | `v_pa_de` | `PREMIUM_ADJUSTMENT` | `de` | `PA_DE` | `legal_pa` | `tariff_sheet` |
| 4 | `v_pa_en` | `PREMIUM_ADJUSTMENT` | `en` | `PA_EN` | `legal_pa` | `tariff_sheet` |
| 5 | `v_default` | — | — | `GENERIC` | `legal_default` | `""` |

---

## 5. Regel‑für‑Regel — die Begründung

- **1–2 (Vertragsänderungs­bestätigung):** Sprachvarianten desselben Templates (`CCC_DE`/`CCC_EN`), gemeinsamer Rechtstext `legal_ccc`, **keine** Anlage.
- **3–4 (Beitragsanpassung):** eigenes Template (`PA_DE`/`PA_EN`), Rechtstext `legal_pa`, und **zusätzlich** die Anlage `tariff_sheet` (das Tarifblatt) — fachlich nötig, weil sich Beiträge ändern.
- **5 (`GENERIC`, Default):** Auffangregel für unbekannte Kombinationen. Es bleibt nie etwas „unbestimmt": jede Eingabe erhält ein gültiges Template (`GENERIC` + `legal_default`).

> 🧭 **FIRST + Default:** Die spezifischen Regeln 1–4 stehen vor der leeren Default‑Regel 5. Käme eine unbekannte Dokumentart oder Sprache (z. B. `fr`), greift Regel 5 — robustes, deterministisches Verhalten ohne „kein Treffer"-Fehler.

---

## 6. Schnittstelle zum Prozess

1. `evalVariant` ruft `camunda:decisionRef="document-variant"` mit `documentType` und `language` auf.
2. `singleResult` → `resultVariable="variantResult"`; der `MapResultFlattenerListener` flacht zu `templateId`, `legalTextKey`, `attachmentKeys` auf.
3. `renderDocument` (Worker) nutzt diese Variablen, um das PDF zu erzeugen.
4. **Zweiter Eingang:** `evalVariant` wird auch nach `markDegraded` (Pfad „Reduziert ausliefern") erneut durchlaufen — die Variante wird dann **unter Degradation** neu bestimmt.

> 💡 **Didaktischer Hinweis:** Diese DMN trifft **keine** kanal-/fristbezogenen Entscheidungen — das macht bewusst die nachgelagerte [`delivery-policy`](delivery-policy.md). Saubere Trennung: *Was* wird erzeugt (variant) vs. *Wie* wird zugestellt (policy).

---

## 7. Durchgerechnete Beispiele

| `documentType` | `language` | Regel | `templateId` | `attachmentKeys` |
|---|---|---|---|---|
| `CONTRACT_CHANGE_CONFIRMATION` | `de` | 1 | `CCC_DE` | — |
| `PREMIUM_ADJUSTMENT` | `de` | 3 | `PA_DE` | `tariff_sheet` |
| `PREMIUM_ADJUSTMENT` | `en` | 4 | `PA_EN` | `tariff_sheet` |
| `WELCOME_LETTER` | `de` | 5 | `GENERIC` | — |

> Hinweis: `run-smoke.ps1` sendet `CONTRACT_CHANGE_CONFIRMATION` + (Default‑Sprache `de`) → **Regel 1** → `CCC_DE`. Der Batch (`run-load`) nutzt `PREMIUM_ADJUSTMENT` → **Regel 3/4**.

## 8. Wie testen / nachverfolgen?
- **Cockpit:** *„Called Decision Instances"* an `evalVariant`.
- **Modeler:** DMN‑Simulation mit verschiedenen `documentType`/`language`.

## 9. Querverweise
- BPMN: [`document-fulfillment`](../bpmn/document-fulfillment.md) (Task `evalVariant`)
- Nachbar‑DMN: [`data-completeness`](data-completeness.md) (davor), [`delivery-policy`](delivery-policy.md) (danach)
