# DMN · `delivery-policy.dmn` — Auslieferungspolitik bestimmen

> **Datei:** `orchestrator-app/src/main/resources/dmn/delivery-policy.dmn`
> **Decision‑ID:** `delivery-policy` · **Name:** „Auslieferungspolitik bestimmen"
> **Hit Policy:** `FIRST` · **`historyTimeToLive`:** `P30D`
> **Aufgerufen von:** Business Rule Task `evalPolicy` in [`document-fulfillment`](../bpmn/document-fulfillment.md).

Diese Tabelle legt das **Wie der Zustellung** fest: Kanal, ob eine technische Bestätigung nötig ist, **wie lange** darauf gewartet wird (Timer‑Frist!), wie oft nachgefragt wird und mit welcher Priorität. Ihre Ausgaben steuern direkt das **Timer Boundary Event** und die **Reconciliation‑Schleife** im Prozess.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Frage** | „Über welchen Kanal, mit welcher Frist/Wiederholung und Priorität wird zugestellt?" |
| **2 Eingaben** | `deliveryChannel` (Präferenz), `documentType` |
| **5 Ausgaben** | Kanal, Ack‑Pflicht, Frist, max. Statusabfragen, Priorität |
| **Hit Policy** | `FIRST` — hier mit einer **lehrreichen Reihenfolge‑Feinheit** (s. §5) |

## 2. Eingaben

| Input‑Label | Ausdruck | Typ | Herkunft |
|---|---|---|---|
| Kanalpräferenz | `deliveryChannel` | string | `LoadCustomerDataHandler` (Kundenpräferenz: `EMAIL`/`CUSTOMER_PORTAL`/`PRINT`) |
| Dokumentart | `documentType` | string | REST‑Start |

> 🔁 **Besonderheit:** Eingabe **und** Ausgabe heißen beide `deliveryChannel`. Die Policy **bestätigt oder überschreibt** also die Kundenpräferenz. Da der Flattener die Ausgabe zuletzt schreibt, gilt nachgelagert der **von der Policy gesetzte** Kanal.

## 3. Ausgaben

| Output‑Label | Name (→ Variable) | Typ | Verwendet von |
|---|---|---|---|
| Kanal | `deliveryChannel` | string | `DispatchDocumentHandler` (Empfängerwahl) |
| techn. Bestätigung nötig | `requiresTechnicalAck` | boolean | (fachliche Steuerung) |
| Bestätigungsfrist | `acknowledgementTimeout` | string (ISO‑8601) | **Timer Boundary `timer_ack`** an der Receive Task |
| max. Statusabfragen | `maxStatusChecks` | integer | **Gateway `gw_reconcile`** (Schleifenobergrenze) |
| Priorität | `deliveryPriority` | string | `DispatchDocumentHandler` |

---

## 4. Die Entscheidungstabelle (vollständig)

| # | Regel | `deliveryChannel` (Eingabe) | `documentType` | → `deliveryChannel` | `requiresTechnicalAck` | `acknowledgementTimeout` | `maxStatusChecks` | `deliveryPriority` |
|---|---|---|---|---|---|---|---|---|
| 1 | `p_print` | `PRINT` | — | `PRINT` | true | `PT15S` | 3 | `NORMAL` |
| 2 | `p_portal` | `CUSTOMER_PORTAL` | — | `CUSTOMER_PORTAL` | true | `PT15S` | 3 | `NORMAL` |
| 3 | `p_premium` | — | `PREMIUM_ADJUSTMENT` | `EMAIL` | true | `PT15S` | 5 | `HIGH` |
| 4 | `p_default` | — | — | `EMAIL` | true | `PT15S` | 3 | `NORMAL` |

---

## 5. Regel‑für‑Regel — und die FIRST‑Feinheit

- **1 `PRINT` / 2 `CUSTOMER_PORTAL`:** Wenn der Kunde Druck oder Portal bevorzugt, **bleibt** es dabei (Kanal bestätigt), Standardfrist/‑wiederholung.
- **3 `PREMIUM_ADJUSTMENT`:** Beitragsanpassungen gehen per **`EMAIL`**, mit **höherer** Wiederholung (`maxStatusChecks=5`) und **Priorität `HIGH`** — wichtige, zeitkritische Korrespondenz.
- **4 Default:** alles andere → `EMAIL`, `NORMAL`, 3 Versuche.

> 🧭 **Warum die Reihenfolge hier besonders lehrreich ist (FIRST!):** Regel 3 matcht auf `documentType=PREMIUM_ADJUSTMENT` bei **beliebigem** Kanal — aber sie steht **nach** den Kanalregeln 1/2. Konsequenz:
>
> | Kanalpräferenz | Dokumentart | gefeuerte Regel | Ergebnis‑Kanal | maxChecks | Prio |
> |---|---|---|---|---|---|
> | `PRINT` | `PREMIUM_ADJUSTMENT` | **1** (FIRST!) | `PRINT` | 3 | NORMAL |
> | `EMAIL` | `PREMIUM_ADJUSTMENT` | **3** | `EMAIL` | 5 | HIGH |
> | `CUSTOMER_PORTAL` | `CONTRACT_CHANGE_CONFIRMATION` | **2** | `CUSTOMER_PORTAL` | 3 | NORMAL |
> | `EMAIL` | `CONTRACT_CHANGE_CONFIRMATION` | **4** | `EMAIL` | 3 | NORMAL |
>
> Eine Beitragsanpassung an einen **Druck**‑Kunden bleibt also `PRINT` (Regel 1 gewinnt), **nicht** `EMAIL`. Genau solche Effekte machen FIRST‑Tabellen mächtig — und verlangen, die Regelreihenfolge bewusst zu wählen.

---

## 6. Schnittstelle zum Prozess — die DMN steuert zwei BPMN‑Elemente direkt

1. **Timer‑Frist:** `acknowledgementTimeout` (hier überall `PT15S`) wird vom Timer Boundary Event `timer_ack` ausgewertet: `${acknowledgementTimeout != null ? acknowledgementTimeout : "PT15S"}`. Die Tabelle bestimmt also **direkt, wie lange** der Prozess auf die technische Annahme wartet, bevor er zur Reconciliation abbricht.
2. **Schleifen‑Deckel:** `maxStatusChecks` wird im Gateway `gw_reconcile` ausgewertet: `${deliveryResultStatus == "PENDING" && statusCheckCount < maxStatusChecks}`. Die Tabelle bestimmt also **wie oft** maximal nachgefragt wird, bevor an die User Task eskaliert wird.
3. **Versand:** `deliveryChannel` und `deliveryPriority` fließen in `dispatchDocument`.

> 💡 So zeigt diese DMN besonders schön, dass eine Entscheidungstabelle nicht nur „Daten setzt", sondern **unmittelbar das Laufzeitverhalten** (Fristen, Wiederholungen) eines BPMN‑Prozesses parametrisiert — ohne das Modell anzufassen.

---

## 7. Wie testen / nachverfolgen?
- **Cockpit:** *„Called Decision Instances"* an `evalPolicy`; an der Receive Task siehst du die wirksame Timer‑Frist.
- **Effekt erleben:** [`run-restart-demo.ps1`](../skripte/run-restart-demo.md) (Profil `DELIVERY_TIMEOUT`) lässt den Timer/Reconciliation‑Pfad sichtbar greifen.

## 8. Querverweise
- BPMN: [`document-fulfillment`](../bpmn/document-fulfillment.md) (Task `evalPolicy`, Timer `timer_ack`, Gateway `gw_reconcile`)
- Nachbar‑DMN: [`document-variant`](document-variant.md) (davor)
