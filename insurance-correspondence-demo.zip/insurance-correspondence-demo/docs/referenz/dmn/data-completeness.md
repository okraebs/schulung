# DMN · `data-completeness.dmn` — Datenvollständigkeit bewerten

> **Datei:** `orchestrator-app/src/main/resources/dmn/data-completeness.dmn`
> **Decision‑ID:** `data-completeness` · **Name:** „Datenvollstaendigkeit bewerten"
> **Hit Policy:** `FIRST` · **`historyTimeToLive`:** `P30D`
> **Aufgerufen von:** Business Rule Task `evalCompleteness` in [`document-fulfillment`](../bpmn/document-fulfillment.md).

Diese Tabelle ist die **erste fachliche Weiche** des Prozesses: Sie verdichtet die drei Datenstatus (Kunde, Vertrag, Tarif) zu **einer** Vollständigkeitsklasse und entscheidet damit, ob ein Auftrag automatisch weiterläuft, **degradiert** ausgeliefert werden darf oder zur **menschlichen Klärung** muss.

---

## 1. Auf einen Blick

| | |
|---|---|
| **Frage** | „Sind die beschafften Daten vollständig genug — und wenn nicht, wie schlimm?" |
| **3 Eingaben** | Datenstatus aus den drei Load‑Handlern |
| **5 Ausgaben** | Klasse + Degradationsflags + Begründungstexte |
| **Hit Policy** | `FIRST` → die **erste** passende Regel (von oben) gewinnt, Reihenfolge ist bedeutungstragend |

---

## 2. Eingaben

| Input‑Label | Ausdruck (Prozessvariable) | Typ | Herkunft | Mögliche Werte |
|---|---|---|---|---|
| Kundendaten‑Status | `customerDataStatus` | string | `LoadCustomerDataHandler` | `OK` · `OPTIONAL_MISSING` · `MANDATORY_MISSING` |
| Vertragsdaten‑Status | `contractDataStatus` | string | `LoadContractDataHandler` | `OK` · `MANDATORY_MISSING` |
| Tarifdaten‑Status | `tariffDataStatus` | string | `LoadTariffDataHandler` | `OK` · `OPTIONAL_MISSING` · `MANDATORY_MISSING` |

> 🔌 **Schnittstelle zu den Worker‑Handlern:** Jeder Load‑Handler leitet aus den (synthetischen) Quelldaten einen `DataStatus` ab und schreibt ihn als Prozessvariable. `MANDATORY_MISSING` = ein **Pflichtfeld** fehlt; `OPTIONAL_MISSING` = nur **Kür**‑Felder fehlen; `OK` = alles da. Beachte: Der **Vertrags**‑Handler kennt **kein** `OPTIONAL_MISSING` (nur OK/MANDATORY) — deshalb gibt es in der Tabelle auch keine „contract optional"-Regel.

## 3. Ausgaben

| Output‑Label | Name (→ Prozessvariable) | Typ | Verwendet von |
|---|---|---|---|
| Vollständigkeitsklasse | `completenessClass` | string | Gateway `gw_completeness` |
| degradiert | `degraded` | boolean | `finalizeOutcome` (→ FULLY vs DEGRADED) |
| Degradation erlaubt | `degradationAllowed` | boolean | `ManualReviewTaskListener` (Zulässigkeit von DELIVER_REDUCED) |
| fehlende Pflichtfelder | `missingRequiredFields` | string | User‑Task‑Formular, `manualReason` |
| Degradationsgründe | `degradationReasons` | string | User‑Task‑Formular |

---

## 4. Die Entscheidungstabelle (vollständig)

Hit Policy **FIRST** — von oben nach unten, die erste Übereinstimmung feuert. Leere Zelle = „beliebig" (—).

| # | Regel | `customerDataStatus` | `contractDataStatus` | `tariffDataStatus` | → `completenessClass` | `degraded` | `degradationAllowed` | `missingRequiredFields` | `degradationReasons` |
|---|---|---|---|---|---|---|---|---|---|
| 1 | `r_customer_mandatory` | `MANDATORY_MISSING` | — | — | **MANUAL_REQUIRED** | false | false | `customerMandatory` | `""` |
| 2 | `r_contract_mandatory` | — | `MANDATORY_MISSING` | — | **MANUAL_REQUIRED** | false | false | `contractMandatory` | `""` |
| 3 | `r_tariff_mandatory` | — | — | `MANDATORY_MISSING` | **MANUAL_REQUIRED** | false | false | `tariffMandatory` | `""` |
| 4 | `r_customer_optional` | `OPTIONAL_MISSING` | — | — | **DEGRADED_ALLOWED** | true | true | `""` | `customerOptionalMissing` |
| 5 | `r_tariff_optional` | — | — | `OPTIONAL_MISSING` | **DEGRADED_ALLOWED** | true | true | `""` | `tariffOptionalMissing` |
| 6 | `r_full_default` | — | — | — | **FULL** | false | false | `""` | `""` |

> 🧭 **Warum die Reihenfolge entscheidend ist (FIRST):** Die **Pflicht**‑Regeln (1–3) stehen **vor** den **Optional**‑Regeln (4–5). Fehlt z. B. eine Pflicht‑Kundenadresse **und** gleichzeitig ein optionales Tariffeld, gewinnt Regel 1 (`MANUAL_REQUIRED`) — Pflicht schlägt Kür. Regel 6 ist die **Auffangregel** (alle Zellen leer) und liefert `FULL`, wenn keine Lücke gemeldet wurde.

---

## 5. Regel‑für‑Regel — die Begründung

- **1–3 (Pflicht fehlt → `MANUAL_REQUIRED`):** Ohne Pflichtfeld (z. B. fehlende Empfängeradresse) darf **nicht** automatisch verschickt werden. `degraded/degradationAllowed=false` — eine reduzierte Auslieferung ist hier **keine** Option, es braucht einen Menschen. `missingRequiredFields` benennt die Quelle (`customerMandatory` …) und steuert später `manualReason=MISSING_MANDATORY_DATA`.
- **4–5 (nur Optionales fehlt → `DEGRADED_ALLOWED`):** Der Auftrag **kann** weiterlaufen, aber „reduziert" (z. B. ohne Beraternamen/Tarif‑Begründung). `degraded=true`, `degradationAllowed=true`: Auslieferung ist erlaubt; der Outcome wird `DEGRADED_DISPATCHED`. `degradationReasons` dokumentiert, **was** fehlte.
- **6 (`FULL`):** Alles vorhanden → vollwertige Auslieferung, Ziel‑Outcome `FULLY_DISPATCHED`.

---

## 6. Schnittstelle zum Prozess

1. `evalCompleteness` ruft via `camunda:decisionRef="data-completeness"` diese Decision mit den drei Statusvariablen auf.
2. `mapDecisionResult="singleResult"` + `resultVariable="completenessResult"`: das (eine) Ergebnis kommt als Map.
3. Der `MapResultFlattenerListener` schreibt jede Ausgabespalte als **eigene** Prozessvariable (`completenessClass`, `degraded`, `degradationAllowed`, `missingRequiredFields`, `degradationReasons`) und entfernt `completenessResult`.
4. `gw_completeness` verzweigt: `completenessClass == "MANUAL_REQUIRED"` → User Task; sonst (`FULL`/`DEGRADED_ALLOWED`) → weiter zu `evalVariant`.

> 💡 **Feinheit:** `DEGRADED_ALLOWED` führt **nicht** sofort in die User Task — der Auftrag läuft automatisch weiter und wird `degraded` ausgeliefert. Die User Task wird nur bei `MANUAL_REQUIRED` betreten. `degradationAllowed=true` wird erst dann relevant, wenn **aus anderem Grund** (z. B. Zustellproblem) doch ein Mensch eingreift und „Reduziert ausliefern" wählen möchte.

---

## 7. Durchgerechnete Beispiele

| `customerDataStatus` | `contractDataStatus` | `tariffDataStatus` | gefeuerte Regel | Klasse | Profil, das das erzeugt |
|---|---|---|---|---|---|
| OK | OK | OK | 6 | `FULL` | `HAPPY` |
| `MANDATORY_MISSING` | OK | OK | 1 | `MANUAL_REQUIRED` | `MANDATORY_DATA_MISSING` |
| `OPTIONAL_MISSING` | OK | OK | 4 | `DEGRADED_ALLOWED` | `OPTIONAL_DATA_MISSING` (Kunde) |
| OK | OK | `OPTIONAL_MISSING` | 5 | `DEGRADED_ALLOWED` | `OPTIONAL_DATA_MISSING` (Tarif) |
| `MANDATORY_MISSING` | OK | `OPTIONAL_MISSING` | 1 (FIRST!) | `MANUAL_REQUIRED` | — (Pflicht schlägt Kür) |

---

## 8. Wie testen / nachverfolgen?
- **Cockpit:** Bei einer Instanz an `evalCompleteness` zeigt der Reiter *„Called Decision Instances"* die gefeuerte Regel und die Ausgabewerte.
- **DMN isoliert testen:** im Camunda Modeler die DMN öffnen und mit dem Simulator/Tester die drei Status durchspielen.
- **Über den Prozess:** [`run-manual-review-demo.ps1`](../skripte/run-manual-review-demo.md) erzwingt über Profil `MANDATORY_DATA_MISSING` die Regel 1 → `MANUAL_REQUIRED`.

## 9. Querverweise
- BPMN: [`document-fulfillment`](../bpmn/document-fulfillment.md) (Task `evalCompleteness`, Gateway `gw_completeness`)
- Folge‑DMN: [`document-variant`](document-variant.md), [`delivery-policy`](delivery-policy.md)
- Treibendes Skript: [`run-manual-review-demo`](../skripte/run-manual-review-demo.md)
