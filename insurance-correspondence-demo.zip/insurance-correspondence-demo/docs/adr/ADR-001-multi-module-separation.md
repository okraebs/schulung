# ADR-001: Multi-Modul-Trennung

- Status: akzeptiert
- Datum: 2026-06-20
- Phase: 0

## Kontext
Die Demo soll Orchestrierung (Camunda-Engine), fachliche I/O-Arbeit (Worker),
simulierte Fremdsysteme und Lasterzeugung didaktisch klar trennen. Ein einzelnes
Modul würde Engine-, Worker- und Simulatorverantwortung vermischen und die für die
Schulung wichtige Grenze zwischen „Engine orchestriert" und „Worker arbeitet"
verwischen.

## Entscheidung
Ein Maven-Multi-Modul-Projekt mit fünf Modulen:
- `shared-contracts` — nur stabile DTOs, Enums, Ereignisverträge, Validierung, Test-Fixtures. Kein Engine-Code, keine DB.
- `orchestrator-app` — eingebettete Camunda-7-Engine, Webapps, REST, BPMN/DMN, Inbox. Port 8080.
- `worker-app` — External Task Client, Handler, Delivery-Outbox, Reconciliation. Port 8081 (Health/Metrics).
- `external-systems-simulator` — Quellsysteme + Output-Management mit deterministischen Fehlerprofilen. Port 8082.
- `load-generator` — Last-CLI.

`shared-contracts` ist die einzige modulübergreifende Code-Abhängigkeit. Worker und
Simulator kommunizieren mit dem Orchestrator ausschließlich über HTTP (Camunda REST
bzw. Demo-REST), nicht über gemeinsamen Engine-Code.

## Konsequenzen
- Klare Verantwortlichkeiten, getrennt deploybare Prozesse, realistische Verteilung.
- Etwas mehr Boilerplate (mehrere POMs, mehrere Spring-Boot-Anwendungen).
- Der Worker greift nie direkt auf die Engine-DB zu (Auftrag 3.3), was die
  Architektur ehrlich hält.
