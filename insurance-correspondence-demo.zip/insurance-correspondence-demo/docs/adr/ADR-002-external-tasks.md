# ADR-002: External Tasks statt JavaDelegate für fachliche I/O

- Status: akzeptiert
- Datum: 2026-06-20
- Phase: 0

## Kontext
Fachliche Arbeit (Datenbeschaffung, PDF-Rendering, Dispatch, Reconciliation) ist
I/O-lastig und potenziell langsam. Solche Arbeit in JavaDelegates auszuführen würde
den Engine-Thread und die Engine-Transaktion über langsame HTTP-Aufrufe offen halten
(Anti-Pattern, Auftrag 22.5).

## Entscheidung
- Fachliche I/O-Arbeit liegt in External Task Workern (`worker-app`), die über das
  External-Task-Protokoll (Long Polling, Lock, Complete) mit der Engine arbeiten.
- JavaDelegates nur für kurze, lokale, deterministische Schritte: Normalisierung der
  Anfrage und finaler idempotenter Statusabgleich (`outcome`).
- Fehlerklassifizierung im Worker: TechnicalTransient → `handleFailure` mit Retries +
  Backoff; TechnicalPermanent → `retries=0` → Incident; BusinessDegradable /
  BusinessManualRequired → fachlicher Status bzw. BPMN-Error.

## Konsequenzen
- Engine-Threads bleiben frei; Wartezustände sind echte Wait States.
- Worker sind horizontal skalierbar (eindeutige Worker-IDs).
- Etwas mehr Infrastruktur (Client, Topic-Verträge, Lock-Dauer-Tuning), dafür
  realitätsnah und schulungstauglich.
