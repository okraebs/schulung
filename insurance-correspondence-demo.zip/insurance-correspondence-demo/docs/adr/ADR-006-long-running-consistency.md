# ADR-006: Konsistenz langlaufender Abläufe ohne verteilte ACID-Transaktion

- Status: akzeptiert
- Datum: 2026-06-20
- Phase: 0

## Kontext
Der Ablauf überspannt mehrere Systeme (Engine, Worker, Output-Management) und lange
Wartezeiten (technische Annahme kommt asynchron). Eine verteilte ACID-Transaktion
oder eine globale Kompensations-Saga wäre falsch (Anti-Pattern, Auftrag 22.9, 4.8).

## Entscheidung
Konsistenz über Systemgrenzen wird hergestellt durch:
- **Idempotenz**: `documentJobId` ist Idempotency Key für Rendering, Speicherung,
  Delivery Request und Callback-Verarbeitung. Jeder Worker mit Seiteneffekt ist
  idempotent.
- **Outbox** (Worker): Delivery Request + Outbox Event entstehen in einer lokalen
  Transaktion; ein Publisher sendet offene Events und markiert sie erst nach
  bestätigter Annahme.
- **Inbox** (Orchestrator): `DeliveryResultReceived`-Callbacks mit
  `callbackEventId`-Unique-Constraint, idempotente Persistenz, spätere Korrelation
  über Scheduler.
- **Reconciliation**: Timer-Boundary-Pfad an der Receive Task prüft den
  Providerzustand (`reconcile-delivery`).
- **Bewusste asynchrone Fortsetzung**: `asyncBefore` an der ersten DMN-Auswertung,
  damit die erfolgreiche External-Task-Vervollständigung unabhängig von einer später
  fehlschlagenden Regelbewertung committet wird.

Die Lücke zwischen lokalem Commit und External-Task-Complete wird durch erneutes,
idempotentes Ausführen geschlossen (vorhandener Delivery Request wird wiederverwendet).

## Konsequenzen
- Robust gegen Lock-Ablauf, verlorenes Complete-Response und doppelte Callbacks.
- Keine zweite Prozessinstanz, kein zweites PDF, kein zweiter Delivery Request.
- Dies ist der Kern des Schulungsthemas „langlaufende Transaktionen".
