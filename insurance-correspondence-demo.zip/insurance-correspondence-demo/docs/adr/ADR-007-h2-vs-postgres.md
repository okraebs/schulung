# ADR-007: H2 für Demo, PostgreSQL für Last

- Status: akzeptiert
- Datum: 2026-06-20
- Phase: 0

## Kontext
Die Demo muss ohne Docker/WSL lokal starten (Auftrag 2.1) und Neustarts überstehen.
Gleichzeitig sollen 20.000–30.000 Aufträge und mehrere Worker realistisch
demonstrierbar sein.

## Entscheidung
- **demo** (Standard): persistente H2-Dateidatenbanken, damit Prozessinstanzen,
  User Tasks, Receive Tasks und Outbox-Einträge einen Neustart überstehen.
- **test**: H2 in-memory, kontrollierte Timer, deaktivierte Scheduler soweit nicht
  getestet.
- **postgres**: PostgreSQL, größere Pools, konfigurierbare Workerzahl, Batchgrößen;
  Zugangsdaten ausschließlich aus Umgebungsvariablen.
- **load**: erbt/ergänzt postgres; optional `document.render.mode=METADATA_ONLY`.

## Konsequenzen
- H2-Ergebnisse sind funktionale Nachweise, **keine** produktiven Leistungswerte
  (Auftrag 15.2, 22.12).
- Horizontale Skalierung mit mehreren Prozessen wird nur im PostgreSQL-Profil
  behauptet, nie auf einer einzelnen H2-Dateidatenbank (Auftrag 15.7).
- Anwendungstabellen über Flyway, JPA `ddl-auto=validate`; die Engine darf im
  Demo-Profil ihr Schema selbst verwalten.
