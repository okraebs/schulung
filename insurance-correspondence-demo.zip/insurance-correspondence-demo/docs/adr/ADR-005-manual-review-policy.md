# ADR-005: Manuelle Klärung statt blindem Versenden

- Status: akzeptiert
- Datum: 2026-06-20
- Phase: 0

## Kontext
„Trotz Fehlern wird immer etwas ausgeliefert" darf nicht als blindes Versenden
verstanden werden (Auftrag 1, 22.7). Fehlen rechtlich/fachlich notwendige Angaben,
muss ein Mensch entscheiden.

## Entscheidung
- `data-completeness.dmn` klassifiziert jeden Auftrag als `FULL`,
  `DEGRADED_ALLOWED` oder `MANUAL_REQUIRED`.
- Nur optionale Inhalte dürfen fehlen → `degraded=true`, Versand erlaubt
  (Outcome `DEGRADED_DISPATCHED`), aber nur wenn die DMN-Entscheidung es ausdrücklich
  erlaubt.
- Fehlen Pflichtdaten → User Task „Dokumentauftrag manuell klären" (Candidate Group
  `document-ops`). Manuelle Entscheidungen: `RETRY_ENRICHMENT`, `DELIVER_REDUCED`
  (nur bei erlaubter Degradation), `CANCEL_REQUEST` → `CANCELLED_AFTER_MANUAL_REVIEW`.
- `MANUAL_REVIEW` und `TECHNICAL_INCIDENT` sind aktive Wartezustände, keine
  erfolgreichen Endzustände.

## Konsequenzen
- Fachlich korrektes Verhalten, keine fehlerhaften Dokumente an Kunden.
- User Task ist Kernbestandteil des Prozesses, kein Zusatzszenario; wird getestet
  (Retry/Reduced/Cancel).
