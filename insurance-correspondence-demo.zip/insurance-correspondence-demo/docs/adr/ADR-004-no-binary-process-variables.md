# ADR-004: Keine Binär- oder Großdaten als Prozessvariablen

- Status: akzeptiert
- Datum: 2026-06-20
- Phase: 0

## Kontext
PDFs, große Collections oder serialisierte Java-Objekte als Prozessvariablen
belasten die Engine-DB, brechen Versionierbarkeit und erschweren Migration
(Anti-Pattern, Auftrag 22.2/22.3, 4.4/4.5).

## Entscheidung
- Prozessvariablen enthalten nur kleine fachliche Werte, Enums als Strings und
  kleine, versionierte JSON-Strukturen (mit Obergrenze, getestet).
- Das PDF liegt im Dateisystem des Demo-Profils unter `var/documents/{documentJobId}/`
  bzw. in einem abstrahierten DocumentStore. Im Prozess stehen nur `documentUri`,
  `documentSha256`, `documentSize`, `documentContentType`.
- Keine JPA-Entities oder beliebige serialisierte Objekte als langlebige Variablen.

## Konsequenzen
- Schlanke Engine-DB, klare Trennung zwischen Orchestrierungszustand und Nutzdaten.
- Ein Test stellt sicher, dass keine Variable versehentlich große Nutzlasten enthält
  (Auftrag 18.4.12 / 10.3).
