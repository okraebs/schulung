# ADR-003: Eine Prozessinstanz pro Dokumentauftrag

- Status: akzeptiert
- Datum: 2026-06-20
- Phase: 0

## Kontext
Periodische Beitragsanpassungen erzeugen 20.000–30.000 Dokumentaufträge. Ein
naheliegendes, aber falsches Muster wäre ein einzelner Batch-Prozess mit einer
Multi-Instance-Aktivität über zehntausende Elemente oder einer riesigen Collection
als Prozessvariable (Anti-Pattern, Auftrag 22.1/22.2).

## Entscheidung
- Genau eine `document_fulfillment`-Prozessinstanz repräsentiert genau einen
  Dokumentauftrag. `documentJobId` ist Business Key und fachlicher Schlüssel.
- Der `document_batch_planner` plant und veröffentlicht Arbeit nur seitenweise
  (`plan-batch`, `publish-batch-page`) und startet unabhängige Instanzen über
  denselben idempotenten Startservice wie ein Einzelereignis.
- Der Planer hält niemals alle Aufträge als Prozessvariable und wartet nicht auf
  Kindinstanzen. Backpressure über `maxInFlight` + Timer-Reprüfung.

## Konsequenzen
- Lineare Skalierung über viele kleine, unabhängige Instanzen.
- Ein wiederholter Lauf mit derselben `batchId` erzeugt keine Duplikate (Idempotenz).
- Engine-/History-Datenmenge muss bewusst gemanagt werden (History TTL, Cleanup).
