# Trainerleitfaden (ca. 60–90 Minuten)

Voraussetzung: `setup-check.ps1` grün, `build.ps1` erfolgreich, `start-demo.ps1` gestartet
(Cockpit/Tasklist unter <http://127.0.0.1:8080/camunda>).

Für jeden Schritt: **Ziel · Kommando · erwarteter Bildschirm · Lehrpunkt**.

---

## 0. Überblick (5 min)
- **Ziel:** Architektur und Lernziele einordnen.
- **Bildschirm:** [architecture.md](architecture.md) (Mermaid-Diagramme).
- **Lehrpunkt:** Camunda orchestriert, External Tasks arbeiten; eine Instanz = ein Dokumentauftrag.

## 1. Happy Path (10 min)
- **Kommando:** `.\scripts\run-smoke.ps1`
- **Bildschirm:** Outcome `FULLY_DISPATCHED`; PDF unter `var/documents/<id>/document.pdf`.
- **Cockpit:** Instanz (abgeschlossen), Prozessvariablen (nur Referenzen/kleine Werte), Verlauf.
- **Lehrpunkt:** Message Start, External Tasks, DMN, Receive Task, Inbox-Korrelation; kein PDF in
  der Engine.

## 2. DMN-Variante & Degradation (10 min)
- **Kommando:** `Invoke-RestMethod -Method Post "http://127.0.0.1:8080/api/demo/events?failureProfile=OPTIONAL_DATA_MISSING"`
- **Bildschirm:** Outcome `DEGRADED_DISPATCHED`; PDF enthält einen Degradationshinweis.
- **Lehrpunkt:** `data-completeness.dmn` erlaubt reduzierten Versand nur für optionale Lücken.

## 3. User Task / manuelle Klärung (15 min)
- **Kommando:** `.\scripts\run-manual-review-demo.ps1`
- **Bildschirm:** Tasklist als `ops`/`ops` → Aufgabe „Dokumentauftrag manuell klären" → Claim →
  Formular (Klärungsgrund, fehlende Pflichtfelder) → Entscheidung.
- **Lehrpunkt:** RETRY_ENRICHMENT (+ korrigierte Adresse) → Erfolg; CANCEL → CANCELLED;
  DELIVER_REDUCED nur bei erlaubter Degradation. Pflichtdatenmangel ⇒ kein blindes Versenden.

## 4. Technischer Incident & Retry (15 min)
- **Kommando:** `.\scripts\run-incident-demo.ps1 -AutoFix`
- **Bildschirm:** Cockpit zeigt einen Incident an `render-document` (retries=0); nach Fix
  (Ursache + Retries) läuft der Auftrag bis `FULLY_DISPATCHED`.
- **Lehrpunkt:** TechnicalPermanent → Incident (nicht jeder Fehler ist BPMN-Fehler); kontrollierte
  Wiederaufnahme.

## 5. Langlaufende Transaktion / Restart (10 min)
- **Kommando:** `.\scripts\run-restart-demo.ps1`
- **Bildschirm:** Auftrag wartet an der Receive Task; Orchestrator-Neustart; Instanz weiterhin
  `ACTIVE`; gepufferter Callback → `FULLY_DISPATCHED`.
- **Lehrpunkt:** Wait-State-Persistenz; langlebiger Prozess ≠ lange DB-Transaktion;
  Inbox puffert Callbacks.

## 6. Batch & Backpressure (10 min)
- **Kommando:** `.\scripts\run-load.ps1 -Count 20`
- **Bildschirm:** Cockpit zeigt viele unabhängige `document_fulfillment`-Instanzen; Batch-Bilanz
  konsistent (`started == fully + degraded + cancelled + active + manual`).
- **Lehrpunkt:** Seitenweise Veröffentlichung über den idempotenten Startservice, Backpressure
  statt riesiger Multi-Instance; Re-Run je `batchId` idempotent.

## Was außerdem zu zeigen ist (Cockpit)
- Eine laufende Instanz an der Receive Task, eine Instanz mit Incident, Prozessvariablen, ein Retry
  nach Behebung, die Wirkung eines Batchlaufs.
- Tasklist: User Task, Claim, Bearbeitung, Formularfelder, Completion und resultierender Pfad.

## Community vs. Enterprise
Die Kernanwendung läuft vollständig ohne Enterprise-Lizenz. Enterprise-Funktionen (z. B.
Operate/Optimize-ähnliche Auswertungen, erweiterte Cockpit-Plugins) dürfen gezeigt werden, wenn eine
Lizenz vorhanden ist, sind aber **keine** Laufzeitabhängigkeit.

## Observability
Keine eigene Weboberfläche nötig: Actuator (`/actuator/health`, `/actuator/metrics`,
`/actuator/prometheus`), strukturierte Logs (MDC), Cockpit, Tasklist und `/api/demo/summary` genügen.
