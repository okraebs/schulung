# Architektur

## Module und Datenflüsse

```mermaid
flowchart LR
  subgraph Orchestrator[orchestrator-app :8080]
    ENG[Camunda 7 Engine\nBPMN/DMN]
    REST[Demo-REST\n/api/...]
    INBOX[(delivery_callback_inbox)]
    WEB[Cockpit / Tasklist / Admin]
  end
  subgraph Worker[worker-app :8081]
    ETC[External Task Client]
    PDF[OpenPDF-Renderer]
    OUT[(document_artifact\ndelivery_request\noutbox_event)]
    PUB[Outbox-Publisher]
  end
  subgraph Sim[external-systems-simulator :8082]
    SRC[Quellsysteme\nKunde/Vertrag/Tarif]
    OM[Output-Management\nprovider_delivery]
  end
  LOAD[load-generator CLI]

  LOAD -->|POST /api/document-requests| REST
  REST --> ENG
  ENG <-->|External Task Protokoll\n(REST, Long Polling)| ETC
  ETC -->|GET Stammdaten| SRC
  PUB -->|POST Delivery Request| OM
  OM -->|POST /api/delivery-results| INBOX
  INBOX -->|Korrelation| ENG
  ETC --> PDF --> OUT
  WEB --- ENG
```

- Der **Worker** greift auf die Engine **ausschließlich über die Camunda REST API** zu (nie auf die
  Engine-DB). Quelldaten und Output laufen über den **Simulator**.
- Jede App hat ihre eigene H2-Datei (Demo-Profil): `orchestrator`, `worker`. Der Simulator hält den
  Providerzustand in-memory.

## Happy-Path-Sequenz

```mermaid
sequenceDiagram
  participant C as Client/REST
  participant E as Engine (document_fulfillment)
  participant W as Worker
  participant S as Simulator
  C->>E: POST /api/document-requests (idempotent, Business Key)
  E->>E: normalize (Delegate)
  E->>W: External Tasks load-customer/contract/tariff
  W->>S: GET Stammdaten
  E->>E: asyncBefore + DMN: completeness / variant / policy
  E->>W: render-document
  W->>W: OpenPDF -> var/documents, SHA-256 (Artefakt idempotent)
  E->>W: dispatch-document
  W->>W: delivery_request + outbox_event (lokale TX)
  W->>S: Outbox-Publisher: Delivery Request (dedup)
  E->>E: Receive Task wartet (DeliveryResultReceived)
  S-->>E: POST /api/delivery-results (Inbox, idempotent)
  E->>E: Korrelation -> finalize -> FULLY_DISPATCHED
```

## Wichtige Architekturentscheidungen
Siehe [ADRs](adr/): Multi-Modul-Trennung, External Tasks, eine Instanz pro Dokument, keine
Binär-Prozessvariablen, Manual-Review-Policy, Konsistenz langlaufender Abläufe, H2 vs. PostgreSQL.

## Persistenz
- Engine-Schema: von Camunda verwaltet (Demo-Profil `schema-update`).
- Anwendungstabellen: **Flyway** (`orchestrator: V1 Inbox`, `worker: V1 Outbox/Artifact/Request`),
  JPA `ddl-auto=validate`. Produktive Migrationen würden anders behandelt (kontrolliert, reviewt).

## Konfigurationsprofile
`demo` (Standard, H2-Datei) · `test` (H2 in-memory) · `postgres` · `load`. Siehe
[load-test.md](load-test.md).
