# Camunda-8-Ausblick

Dieser Ausblick ist **konzeptionell**. Die Kernanwendung bleibt Camunda 7; es wird keine reale
Camunda-8- oder LLM-Abhängigkeit eingeführt.

## Zuordnung Camunda 7 → Camunda 8
| Camunda 7 (diese Demo) | Camunda 8 (Zeebe) |
|---|---|
| External Task + External Task Client | **Job Worker** (gRPC, Long Polling) |
| Cockpit | **Operate** |
| Tasklist (Camunda 7) | **Camunda 8 Tasklist** |
| Message-Korrelation (Business Key) | **Message-Korrelation** über Correlation Key |
| DMN über die Engine | DMN über die **Zeebe**-Ausführung |
| H2/PostgreSQL relationale Engine-DB | Zeebe (ereignisbasiert, Exporter nach Elasticsearch/OpenSearch) |
| Incident + Retries | Incident + Job-Retries (Operate) |

Architekturmuster bleiben gültig: Worker für I/O, Wait States, Idempotenz, Outbox/Inbox,
Reconciliation. Die **Message Start**-/**Receive**-Semantik und die Idempotenz über einen fachlichen
Schlüssel übertragen sich direkt auf das Camunda-8-Modell.

## Migrationshinweise (konzeptionell)
- External-Task-Topics → Job-Typen; `handleFailure`/Retries → Job-`fail` mit `retries`.
- Eingebettete Engine (Spring Boot) → Zeebe-Cluster (oder Camunda 8 Run / SaaS).
- Relationale Anwendungstabellen (Inbox/Outbox) bleiben unverändert sinnvoll – sie sind unabhängig
  von der Workflow-Engine.

## Agentischer Ausblick (rein konzeptionell)
Ein AI Agent könnte **unstrukturierte** eingehende Korrespondenz klassifizieren oder einen
**Vorschlag** zur Klärung fehlender Daten erzeugen (z. B. „vermutlich fehlt die Postanschrift –
Vorschlag: …"). Die **Entscheidung** bliebe bei der **User Task** (`document-ops`): der Agent liefert
nur einen Vorschlag, der Mensch wählt RETRY_ENRICHMENT / DELIVER_REDUCED / CANCEL_REQUEST.

Wichtig: In der Camunda-7-Kernanwendung wird **keine** reale LLM-Abhängigkeit integriert. Ein solcher
Agent wäre ein zusätzlicher, klar getrennter Dienst hinter der bestehenden REST-/Task-Grenze.
