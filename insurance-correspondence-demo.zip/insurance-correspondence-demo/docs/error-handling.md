# Fehlerkonzept

Nicht jeder Fehler ist ein BPMN-Fehler. Die Demo unterscheidet bewusst:

## 1. Technische, voraussichtlich vorübergehende Fehler (TechnicalTransient)
- Beispiel: `TRANSIENT_SOURCE_FAILURE` (Quellsystem antwortet kurz mit HTTP 503).
- Behandlung: External-Task **`handleFailure`** mit dekrementierten Retries und Backoff.
- Der Simulator lässt die ersten Versuche deterministisch scheitern und danach gelingen
  (`AttemptTracker`) → Retry führt zum Erfolg, **kein** Incident.

## 2. Technische, dauerhafte Fehler (TechnicalPermanent)
- Beispiel: `PERMANENT_RENDER_FAILURE`.
- Behandlung: `handleFailure` dekrementiert die Retries bis **0** → die Engine erzeugt einen
  **Incident**. Recovery: Ursache beheben (hier Demo: Variable `failureProfile=HAPPY`) und Retries
  über Cockpit oder REST hochsetzen → der Auftrag läuft weiter.
- Nachweis: `run-incident-demo.ps1 -AutoFix` (Zähler `documents.incidents`, Engine-Incident,
  anschließend `FULLY_DISPATCHED`).

## 3. Fachliche Abweichung mit erlaubter Degradation (BusinessDegradable)
- Beispiel: `OPTIONAL_DATA_MISSING`.
- Behandlung: `data-completeness.dmn` liefert `DEGRADED_ALLOWED`, `degraded=true`. Der Auftrag wird
  reduziert ausgeliefert → `DEGRADED_DISPATCHED`. Nur **optionale** Inhalte fehlen.

## 4. Fachliche Klärung erforderlich (BusinessManualRequired)
- Beispiel: `MANDATORY_DATA_MISSING` (fehlende Zieladresse).
- Behandlung: `data-completeness.dmn` liefert `MANUAL_REQUIRED` → **User Task**. Entscheidungen:
  RETRY_ENRICHMENT (nach Korrektur Erfolg), DELIVER_REDUCED (nur bei erlaubter Degradation),
  CANCEL_REQUEST (→ `CANCELLED_AFTER_MANUAL_REVIEW`).

## Warum nicht alles als BPMN-Fehler?
- Technische Fehler sollen **Retries** auslösen (Selbstheilung), nicht sofort einen fachlichen Pfad.
- Pauschale BPMN-Fehler verlören die Unterscheidung zwischen „später nochmal" und „Mensch nötig".
- Fachliche Ergebnisse sind über DMN und Ergebnisvariablen nachvollziehbar und testbar.

## Grenzen und Garantien
- Fehlerdetails enthalten keine sensiblen Daten. Es gibt **keine** unendlichen Retries und **keine**
  unendlichen Prozessschleifen (`maxStatusChecks` begrenzt die Reconciliation-Schleife).
- „Trotz Fehlern wird etwas ausgeliefert" gilt **nur** für optionale Inhalte und nur, wenn die
  DMN-Entscheidung es erlaubt – niemals bei fehlenden Pflichtangaben (kein blindes Versenden).
