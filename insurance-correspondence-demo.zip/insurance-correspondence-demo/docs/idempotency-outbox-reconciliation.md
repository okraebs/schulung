# Idempotenz, Outbox, Inbox und Reconciliation

Nebenläufigkeit und Wiederholung sind Normalfälle. Jeder Worker mit Seiteneffekt ist idempotent:
ein Lock-Ablauf, ein verlorenes Complete-Response oder ein doppelter Callback erzeugt **kein**
zweites PDF, **keinen** zweiten Delivery Request und **keine** zweite Prozessinstanz.

## Idempotency Key
`documentJobId` ist der gemeinsame Schlüssel für Start, Rendering, Speicherung, Delivery Request und
Callback-Verarbeitung.

## Idempotenter Start (Orchestrator)
`POST /api/document-requests` startet bei neuer `documentJobId` eine Instanz mit dieser als Business
Key. Bei einer Dublette wird **kein** zweiter Prozess gestartet, sondern der bestehende Status
geliefert (HTTP 200 statt 201).

## Render-Idempotenz (Worker)
`render-document` prüft `document_artifact` (PK = documentJobId). Existiert bereits ein Artefakt, wird
es wiederverwendet – nicht erneut gerendert.

## Delivery-Outbox (Worker)
`dispatch-document` schreibt **in einer lokalen Transaktion** `delivery_request`
(UNIQUE `document_job_id`) **und** `outbox_event`. Der External Task wird **erst nach dem Commit**
abgeschlossen. Ein erneuter Lauf (z. B. verlorenes Complete-Response) findet den vorhandenen Delivery
Request und verwendet ihn wieder → kein zweiter Request.

Ein **Outbox-Publisher** sendet offene Outbox-Einträge an das Output-Management (HTTP **außerhalb**
der DB-Transaktion) und markiert sie erst nach Annahme als SENT. Der Simulator dedupliziert über
`documentJobId`/`deliveryRequestId`, daher ist ein erneutes Senden unschädlich.

## Inbox (Orchestrator)
`POST /api/delivery-results` schreibt jeden Callback in `delivery_callback_inbox`
(UNIQUE `callback_event_id`). **Speicherung und Korrelation laufen in getrennten Transaktionen**:
- Speicherung committet immer (der Callback ist gepuffert).
- Die Korrelation mit der wartenden Receive Task läuft separat; schlägt sie fehl (keine wartende
  Instanz, paralleler Job-Executor), bleibt der Eintrag PENDING und ein Scheduler versucht es erneut.
- Ein **doppelter Callback** (gleicher `callback_event_id`) liefert idempotent eine erfolgreiche
  Antwort und erzeugt **keinen** zweiten Prozessfortschritt.

## Reconciliation
Läuft der Timer an der Receive Task ab, fragt `reconcile-delivery` den Providerstatus ab:
- `ACCEPTED` → Abschluss.
- `PENDING` und `statusCheckCount < maxStatusChecks` → Zähler erhöhen, zurück zur Receive Task.
- `REJECTED`/`UNKNOWN` oder Maximum erreicht → User Task.

## Zusammenspiel = Kern des Schulungsthemas
Die Kombination aus **Wait-State-Persistenz + Idempotenz + Outbox + Inbox + Reconciliation** stellt
Konsistenz über Systemgrenzen her – ohne verteilte ACID-Transaktion und ohne globale Kompensations-Saga.

## Getestete Fälle
- Verlorenes Complete-Response → erneuter Lauf nutzt denselben Delivery Request (ein Request, ein
  Artefakt). (`DeliveryOutboxIdempotencyTest`)
- Doppelter Callback → genau ein Prozessfortschritt. (`DocumentFulfillmentProcessTest`,
  realer E2E mit `DUPLICATE_CALLBACK`)
- Timeout → Reconciliation PENDING-Schleife → ACCEPTED → Abschluss.
