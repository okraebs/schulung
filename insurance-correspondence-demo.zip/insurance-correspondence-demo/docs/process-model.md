# Prozessmodell

## document_fulfillment.bpmn (Kernprozess)
Eine Prozessinstanz repräsentiert genau **einen** Dokumentauftrag. `documentJobId` ist Business Key
und Idempotency Key.

| Element | Typ | Fachlicher/technischer Grund |
|---|---|---|
| `start` | **Message Start Event** (`DocumentRequestReceived`) | Einzelereignis und Batch nutzen denselben idempotenten Startweg. |
| `normalizeRequest` | JavaDelegate | Kurz, lokal, deterministisch (statusCheckCount=0, degraded=false). |
| `loadCustomer/Contract/Tariff` | **External Task** | I/O-Arbeit im Worker; sichtbar als drei Aufgaben. Sequenzielle Hauptvariante (stabiler Join). |
| `evalCompleteness` | **Business Rule Task** + **asyncBefore** | `data-completeness.dmn`. Die asyncBefore-Grenze committet die erfolgreiche Anreicherung unabhängig von einer später fehlschlagenden Regelbewertung. |
| `gw_completeness` | Exclusive Gateway | FULL/DEGRADED_ALLOWED → weiter; MANUAL_REQUIRED → User Task. |
| `evalVariant` / `evalPolicy` | Business Rule Task | `document-variant.dmn` / `delivery-policy.dmn`. |
| `renderDocument` | External Task | Echtes PDF (OpenPDF), nur Referenz/Hash/Größe/Content-Type als Variablen. |
| `dispatchDocument` | External Task | Delivery Request + Outbox in lokaler TX; Complete erst nach Commit. |
| `receiveResult` | **Receive Task** (`DeliveryResultReceived`) | Wartet auf die asynchrone technische Annahme. |
| `timer_ack` | **Interrupting Timer Boundary Event** | Demo `PT15S` (über `acknowledgementTimeout` konfigurierbar). |
| `reconcileDelivery` | External Task | Fragt den Providerstatus ab. |
| `gw_reconcile` | Exclusive Gateway | ACCEPTED → Abschluss; PENDING & < max → Statuszähler + zurück zur Receive Task; sonst → User Task. |
| `manualReview` | **User Task** (`document-ops`) | Manuelle Klärung; erreicht bei Pflichtdatenmangel, Ablehnung oder ungeklärtem Timeout. |
| `gw_manual` | Exclusive Gateway | RETRY_ENRICHMENT → Datenbeschaffung; DELIVER_REDUCED (nur erlaubt) → markDegraded; CANCEL_REQUEST → Abbruch. |
| `finalizeOutcome` | JavaDelegate | FULLY_DISPATCHED bzw. DEGRADED_DISPATCHED. |

### Fehlerbehandlung im Modell
Technische, voraussichtlich vorübergehende Fehler erzeugen External-Task-Retries; erst bei
aufgebrauchten Retries entsteht ein Incident. Fachliche Abweichungen laufen über DMN bzw. die User
Task, nicht pauschal über BPMN-Fehler. Siehe [error-handling.md](error-handling.md).

### Backpressure-Schleife
Im Batch-Planer (siehe unten), nicht im Kernprozess.

## document_batch_planner.bpmn
```
Timer Start (03:00) / REST-Start
  -> plan-batch (External Task: Plan mit Seed, totalCount/pageSize/maxInFlight)
  -> [Schleife] backpressureCheck (Delegate, asyncBefore)
        -> belowLimit? publish-batch-page (External Task) : Timer PT3S -> erneut prüfen
        -> weitere Seiten? zurück : Ende
```
Jeder veröffentlichte Auftrag startet als **unabhängige** `document_fulfillment`-Instanz über den
idempotenten Startservice (`POST /api/document-requests`). Keine Multi-Instance über zehntausende
Elemente, keine Collection als Prozessvariable. Re-Run mit derselben `batchId` ist idempotent
(deterministische `documentJobId`s).

## DMN-Modelle
- `data-completeness.dmn` → `completenessClass`, `degraded`, `degradationAllowed`,
  `missingRequiredFields`, `degradationReasons` (Hit Policy FIRST, Default-Regel).
- `document-variant.dmn` → `templateId`, `legalTextKey`, `attachmentKeys`.
- `delivery-policy.dmn` → `deliveryChannel`, `requiresTechnicalAck`, `acknowledgementTimeout`,
  `maxStatusChecks`, `deliveryPriority`.

Alle Modelle besitzen `historyTimeToLive=P30D`.
