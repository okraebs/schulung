# Transaktionskonzept

## Wait States und kurze ACID-Transaktionen
Eine Prozessinstanz überspannt viele **kurze** Datenbanktransaktionen. An jedem Wait State
persistiert die Engine den Zustand und gibt den Thread frei:
- **External Tasks** (Datenbeschaffung, Render, Dispatch, Reconcile)
- **Receive Task** (technische Annahme)
- **Timer** (Bestätigungsfrist, Backpressure)
- **User Task** (manuelle Klärung)

Es bleibt zu **keinem** Zeitpunkt eine ACID-Transaktion über einen externen HTTP-Aufruf, eine
Wartezeit von Minuten oder eine menschliche Bearbeitung offen.

## Bewusst gesetzte asynchrone Fortsetzung (`asyncBefore`)
`evalCompleteness` trägt `camunda:asyncBefore="true"`. Damit wird die erfolgreiche Vervollständigung
der drei Datenbeschaffungs-External-Tasks in einer eigenen Transaktion committet, **bevor** die erste
DMN-Auswertung läuft. Schlägt die Regelbewertung später fehl, muss die teure Datenanreicherung nicht
wiederholt werden. Dies ist die einzige bewusst zusätzliche Transaktionsgrenze – es werden **nicht**
pauschal asyncBefore/asyncAfter gesetzt (Wait States sind bereits Transaktionsgrenzen).

## Langlebiger Prozess ≠ lange Datenbanktransaktion
Die technische Annahme des Output-Managements kommt **asynchron**. Der Prozess wartet deshalb in der
Receive Task. Im Demo-Profil dauert die Antwort Sekunden; fachlich repräsentiert sie Minuten/Stunden.
Der Prozess ist also langlebig, ohne dass eine Datenbanktransaktion lange offen bleibt.

## Restart-Persistenz (nachgewiesen)
Mit persistenten H2-Dateidatenbanken überstehen Prozessinstanzen, User Tasks, Receive Tasks und
Inbox/Outbox-Einträge einen Neustart. Nachweis: `run-restart-demo.ps1` führt einen Auftrag bis zur
Receive Task, startet **nur** den Orchestrator neu (Worker/Simulator laufen weiter) und zeigt, dass
die Instanz weiter am Wait State steht und nach einem gepufferten Callback fortgesetzt wird. Analog
überlebt eine User Task den Neustart.

## Konsistenz über Systemgrenzen
Keine verteilte ACID-Transaktion, keine globale Kompensations-Saga. Stattdessen:
**Idempotenz + Outbox + Inbox + Reconciliation** (siehe
[idempotency-outbox-reconciliation.md](idempotency-outbox-reconciliation.md)).

Die Lücke zwischen lokalem Commit (Delivery Request + Outbox) und External-Task-Complete wird durch
erneutes, idempotentes Ausführen geschlossen: Schlägt das Complete nach erfolgreichem Commit fehl,
erkennt der erneut ausgeführte Handler den vorhandenen Delivery Request und verwendet ihn wieder.
