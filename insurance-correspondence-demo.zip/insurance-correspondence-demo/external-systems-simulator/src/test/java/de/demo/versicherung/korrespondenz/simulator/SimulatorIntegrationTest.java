package de.demo.versicherung.korrespondenz.simulator;

import static org.assertj.core.api.Assertions.assertThat;

import de.demo.versicherung.korrespondenz.contracts.CustomerData;
import de.demo.versicherung.korrespondenz.contracts.DeliveryChannel;
import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchRequest;
import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchResponse;
import de.demo.versicherung.korrespondenz.contracts.DeliveryResultStatus;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProviderStatusResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SimulatorIntegrationTest {

    @Autowired
    TestRestTemplate rest;

    @Test
    void happyCustomerHasMandatoryAndOptionalFields() {
        CustomerData data = rest.getForObject("/sim/customers/C-1001?profile=HAPPY", CustomerData.class);
        assertThat(data.fullName()).isNotBlank();
        assertThat(data.advisorName()).isNotBlank();
    }

    @Test
    void optionalDataMissingDropsOptionalFieldsOnly() {
        CustomerData data =
                rest.getForObject("/sim/customers/C-1001?profile=OPTIONAL_DATA_MISSING", CustomerData.class);
        assertThat(data.fullName()).as("Pflichtfeld bleibt").isNotBlank();
        assertThat(data.advisorName()).as("optionales Feld fehlt").isNull();
        assertThat(data.marketingInsert()).isNull();
    }

    @Test
    void mandatoryDataMissingDropsDeliveryAddress() {
        CustomerData data =
                rest.getForObject("/sim/customers/C-1001?profile=MANDATORY_DATA_MISSING", CustomerData.class);
        // Name bleibt erhalten; die Zieladresse fehlt und kann manuell korrigiert werden
        assertThat(data.fullName()).as("Name bleibt").isNotBlank();
        assertThat(data.email()).as("E-Mail fehlt").isNull();
        assertThat(data.postalAddress()).as("Anschrift fehlt").isNull();
    }

    @Test
    void dispatchIsIdempotentForSameDocumentJobId() {
        var request = new DeliveryDispatchRequest(
                "DOC-IT-1",
                DeliveryChannel.EMAIL,
                "doc-it-1@example.test",
                "file:///var/documents/DOC-IT-1/document.pdf",
                "abc123",
                "NORMAL",
                FailureProfile.HAPPY);

        DeliveryDispatchResponse first =
                rest.postForObject("/sim/output/delivery-requests", request, DeliveryDispatchResponse.class);
        DeliveryDispatchResponse second =
                rest.postForObject("/sim/output/delivery-requests", request, DeliveryDispatchResponse.class);

        assertThat(first.accepted()).isTrue();
        assertThat(first.duplicate()).isFalse();
        assertThat(second.duplicate()).as("zweiter Dispatch ist Dublette").isTrue();
        assertThat(second.deliveryRequestId()).isEqualTo(first.deliveryRequestId());

        ProviderStatusResponse status = rest.getForObject(
                "/sim/output/delivery-requests/" + first.deliveryRequestId() + "/status", ProviderStatusResponse.class);
        assertThat(status.deliveryResultStatus()).isEqualTo(DeliveryResultStatus.ACCEPTED);
    }
}
