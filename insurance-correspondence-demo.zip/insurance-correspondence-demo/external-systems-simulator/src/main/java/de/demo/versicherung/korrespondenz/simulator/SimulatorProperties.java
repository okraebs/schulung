package de.demo.versicherung.korrespondenz.simulator;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Konfiguration des Simulators (Praefix {@code simulator}).
 *
 * @param orchestratorBaseUrl Basis-URL des Orchestrators fuer asynchrone Callbacks
 * @param callbackDelay Verzoegerung bis zur technischen Annahme im Demo-Profil
 */
@ConfigurationProperties(prefix = "simulator")
public record SimulatorProperties(String orchestratorBaseUrl, Duration callbackDelay) {}
