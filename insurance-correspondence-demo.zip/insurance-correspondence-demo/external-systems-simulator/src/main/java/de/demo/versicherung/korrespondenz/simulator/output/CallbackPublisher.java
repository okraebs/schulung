package de.demo.versicherung.korrespondenz.simulator.output;

import de.demo.versicherung.korrespondenz.contracts.DeliveryResultCallback;
import de.demo.versicherung.korrespondenz.contracts.DeliveryResultStatus;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.simulator.SimulatorProperties;
import java.time.Duration;
import java.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * Sendet die asynchrone technische Annahme (DeliveryResultReceived) deterministisch je Fehlerprofil
 * an den Orchestrator (Auftrag 12.2 / 12.5). Bei Verbindungsfehlern (z. B. Orchestrator unten)
 * wird mit Backoff erneut versucht (CALLBACK_WHILE_ORCHESTRATOR_DOWN).
 */
@Component
public class CallbackPublisher {

    private static final Logger log = LoggerFactory.getLogger(CallbackPublisher.class);
    private static final int MAX_SEND_ATTEMPTS = 8;
    private static final Duration DELAYED_CALLBACK = Duration.ofSeconds(20);
    private static final Duration RETRY_BACKOFF = Duration.ofSeconds(3);

    private final RestClient orchestratorClient;
    private final TaskScheduler scheduler;
    private final SimulatorProperties properties;

    public CallbackPublisher(SimulatorProperties properties, TaskScheduler scheduler) {
        this.properties = properties;
        this.scheduler = scheduler;
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Duration.ofSeconds(2));
        factory.setReadTimeout(Duration.ofSeconds(5));
        this.orchestratorClient = RestClient.builder()
                .baseUrl(properties.orchestratorBaseUrl())
                .requestFactory(factory)
                .build();
    }

    /** Plant den/die Callback(s) gemaess Fehlerprofil. */
    public void scheduleFor(ProviderDelivery delivery) {
        FailureProfile profile = delivery.profile();
        Duration baseDelay = properties.callbackDelay() != null ? properties.callbackDelay() : Duration.ofSeconds(2);
        switch (profile) {
            case DELIVERY_TIMEOUT -> log.info(
                    "DELIVERY_TIMEOUT: kein Callback fuer documentJobId={}", delivery.documentJobId());
            case DELIVERY_REJECTED -> schedule(delivery, DeliveryResultStatus.REJECTED, baseDelay);
            case DELIVERY_DELAYED -> scheduler.schedule(
                    () -> {
                        delivery.status(DeliveryResultStatus.ACCEPTED);
                        send(delivery, DeliveryResultStatus.ACCEPTED, MAX_SEND_ATTEMPTS);
                    },
                    Instant.now().plus(DELAYED_CALLBACK));
            case DUPLICATE_CALLBACK -> {
                schedule(delivery, DeliveryResultStatus.ACCEPTED, baseDelay);
                schedule(delivery, DeliveryResultStatus.ACCEPTED, baseDelay.plusSeconds(1));
            }
            default -> schedule(delivery, DeliveryResultStatus.ACCEPTED, baseDelay);
        }
    }

    private void schedule(ProviderDelivery delivery, DeliveryResultStatus status, Duration delay) {
        scheduler.schedule(
                () -> send(delivery, status, MAX_SEND_ATTEMPTS), Instant.now().plus(delay));
    }

    private void send(ProviderDelivery delivery, DeliveryResultStatus status, int attemptsLeft) {
        DeliveryResultCallback callback = new DeliveryResultCallback(
                delivery.documentJobId(),
                delivery.deliveryRequestId(),
                status,
                delivery.providerReference(),
                delivery.callbackEventId());
        try {
            orchestratorClient
                    .post()
                    .uri("/api/delivery-results")
                    .body(callback)
                    .retrieve()
                    .toBodilessEntity();
            delivery.incrementCallbacksSent();
            log.info("Callback gesendet: documentJobId={} status={}", delivery.documentJobId(), status);
        } catch (RuntimeException e) {
            if (attemptsLeft > 1) {
                log.warn(
                        "Callback fehlgeschlagen (documentJobId={}), erneuter Versuch in {}s",
                        delivery.documentJobId(),
                        RETRY_BACKOFF.toSeconds());
                scheduler.schedule(
                        () -> send(delivery, status, attemptsLeft - 1),
                        Instant.now().plus(RETRY_BACKOFF));
            } else {
                log.error("Callback endgueltig nicht zustellbar: documentJobId={}", delivery.documentJobId());
            }
        }
    }
}
