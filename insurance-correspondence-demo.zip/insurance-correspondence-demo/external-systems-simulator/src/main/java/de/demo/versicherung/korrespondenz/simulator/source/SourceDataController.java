package de.demo.versicherung.korrespondenz.simulator.source;

import de.demo.versicherung.korrespondenz.contracts.ContractData;
import de.demo.versicherung.korrespondenz.contracts.CustomerData;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.TariffData;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/**
 * Quellsystem-Endpunkte fuer Kunden-, Vertrags- und Tarifdaten (Auftrag 12.1). Das Fehlerprofil
 * steuert deterministisch, welche Felder fehlen bzw. ob ein voruebergehender Fehler auftritt.
 */
@RestController
@RequestMapping("/sim")
public class SourceDataController {

    /** Anzahl der voruebergehend scheiternden Versuche vor Erfolg (TechnicalTransient-Demo). */
    private static final int TRANSIENT_FAILURES_BEFORE_SUCCESS = 2;

    private final SyntheticDataFactory dataFactory;
    private final AttemptTracker attemptTracker;

    public SourceDataController(SyntheticDataFactory dataFactory, AttemptTracker attemptTracker) {
        this.dataFactory = dataFactory;
        this.attemptTracker = attemptTracker;
    }

    @GetMapping("/customers/{customerId}")
    public CustomerData customer(
            @PathVariable String customerId, @RequestParam(defaultValue = "HAPPY") FailureProfile profile) {
        failTransientlyIfConfigured(profile, "customer:" + customerId);
        return dataFactory.customer(customerId, profile);
    }

    @GetMapping("/contracts/{contractId}")
    public ContractData contract(
            @PathVariable String contractId, @RequestParam(defaultValue = "HAPPY") FailureProfile profile) {
        return dataFactory.contract(contractId, profile);
    }

    @GetMapping("/tariffs/{product}")
    public TariffData tariff(
            @PathVariable String product, @RequestParam(defaultValue = "HAPPY") FailureProfile profile) {
        return dataFactory.tariff(product, profile);
    }

    private void failTransientlyIfConfigured(FailureProfile profile, String key) {
        if (profile == FailureProfile.TRANSIENT_SOURCE_FAILURE
                && attemptTracker.shouldFailTransiently(key, TRANSIENT_FAILURES_BEFORE_SUCCESS)) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE, "Voruebergehender Quellsystemfehler (deterministisch)");
        }
    }
}
