package de.demo.versicherung.korrespondenz.simulator.output;

import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchRequest;
import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchResponse;
import de.demo.versicherung.korrespondenz.contracts.ProviderStatusResponse;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/**
 * Output-Management des Simulators (Auftrag 12.1/12.6): nimmt Delivery Requests idempotent an und
 * stellt einen abfragbaren Providerstatus fuer die Reconciliation bereit. Die asynchrone technische
 * Annahme (DeliveryResultReceived-Callback) wird ab Phase 5 ergaenzt.
 */
@RestController
@RequestMapping("/sim/output")
public class OutputManagementController {

    private static final Logger log = LoggerFactory.getLogger(OutputManagementController.class);

    private final ProviderDeliveryStore store;
    private final CallbackPublisher callbackPublisher;

    public OutputManagementController(ProviderDeliveryStore store, CallbackPublisher callbackPublisher) {
        this.store = store;
        this.callbackPublisher = callbackPublisher;
    }

    @PostMapping("/delivery-requests")
    public DeliveryDispatchResponse dispatch(@Valid @RequestBody DeliveryDispatchRequest request) {
        ProviderDeliveryStore.Result result = store.accept(request);
        // Nur fuer einen neu angenommenen Auftrag den asynchronen Callback planen (Idempotenz)
        if (!result.duplicate()) {
            callbackPublisher.scheduleFor(result.delivery());
        }
        log.info(
                "Dispatch documentJobId={} -> deliveryRequestId={} duplicate={} status={}",
                request.documentJobId(),
                result.delivery().deliveryRequestId(),
                result.duplicate(),
                result.delivery().status());
        return new DeliveryDispatchResponse(result.delivery().deliveryRequestId(), true, result.duplicate());
    }

    @GetMapping("/delivery-requests/{deliveryRequestId}/status")
    public ProviderStatusResponse status(@PathVariable String deliveryRequestId) {
        ProviderDelivery delivery = store.byDeliveryRequestId(deliveryRequestId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Unbekannter deliveryRequestId: " + deliveryRequestId));
        return new ProviderStatusResponse(
                delivery.deliveryRequestId(), delivery.status(), delivery.providerReference());
    }
}
