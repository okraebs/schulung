package de.demo.versicherung.korrespondenz.simulator.source;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.stereotype.Component;

/**
 * Zählt Aufrufe je Schlüssel, um deterministisch "voruebergehende" Fehler abzubilden: die ersten
 * N Versuche scheitern, danach folgt Erfolg (Auftrag 12.4 – reproduzierbar, kein Zufall). So lässt
 * sich ein TechnicalTransient-Fehler mit anschliessendem erfolgreichem Retry demonstrieren.
 */
@Component
public class AttemptTracker {

    private final ConcurrentHashMap<String, AtomicInteger> attempts = new ConcurrentHashMap<>();

    /** Liefert true, solange die Zahl der bisherigen Versuche {@code failuresBeforeSuccess} nicht übersteigt. */
    public boolean shouldFailTransiently(String key, int failuresBeforeSuccess) {
        int attempt = attempts.computeIfAbsent(key, k -> new AtomicInteger()).incrementAndGet();
        return attempt <= failuresBeforeSuccess;
    }

    public void reset(String key) {
        attempts.remove(key);
    }

    public void resetAll() {
        attempts.clear();
    }
}
