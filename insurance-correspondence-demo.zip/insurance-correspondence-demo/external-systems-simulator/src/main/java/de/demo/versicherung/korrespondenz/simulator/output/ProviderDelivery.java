package de.demo.versicherung.korrespondenz.simulator.output;

import de.demo.versicherung.korrespondenz.contracts.DeliveryResultStatus;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;

/**
 * Ein beim Provider gespeicherter Zustellauftrag (Auftrag 10.6: {@code provider_delivery}).
 * Bewusst eine kleine, veränderbare Klasse, da sich der Status im Lebenszyklus ändert.
 */
public class ProviderDelivery {

    private final String deliveryRequestId;
    private final String documentJobId;
    private final FailureProfile profile;
    private final String callbackEventId;
    private DeliveryResultStatus status;
    private String providerReference;
    private int callbacksSent;

    public ProviderDelivery(
            String deliveryRequestId,
            String documentJobId,
            FailureProfile profile,
            DeliveryResultStatus status,
            String providerReference,
            String callbackEventId) {
        this.deliveryRequestId = deliveryRequestId;
        this.documentJobId = documentJobId;
        this.profile = profile;
        this.status = status;
        this.providerReference = providerReference;
        this.callbackEventId = callbackEventId;
    }

    public String deliveryRequestId() {
        return deliveryRequestId;
    }

    public String documentJobId() {
        return documentJobId;
    }

    public FailureProfile profile() {
        return profile;
    }

    public String callbackEventId() {
        return callbackEventId;
    }

    public DeliveryResultStatus status() {
        return status;
    }

    public void status(DeliveryResultStatus status) {
        this.status = status;
    }

    public String providerReference() {
        return providerReference;
    }

    public int callbacksSent() {
        return callbacksSent;
    }

    public void incrementCallbacksSent() {
        this.callbacksSent++;
    }
}
