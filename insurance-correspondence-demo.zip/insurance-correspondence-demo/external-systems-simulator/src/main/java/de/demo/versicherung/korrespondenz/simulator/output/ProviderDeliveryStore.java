package de.demo.versicherung.korrespondenz.simulator.output;

import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchRequest;
import de.demo.versicherung.korrespondenz.contracts.DeliveryResultStatus;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

/**
 * In-Memory-Store der Provider-Zustellaufträge mit Idempotenz: ein wiederholter Dispatch mit
 * derselben {@code documentJobId} erzeugt keinen zweiten Providerauftrag (Auftrag 12.6 / 8.5).
 *
 * <p>{@code deliveryRequestId} wird deterministisch aus {@code documentJobId} abgeleitet, sodass
 * die Idempotenz auch ueber Wiederholungen stabil bleibt.
 */
@Component
public class ProviderDeliveryStore {

    private final ConcurrentHashMap<String, ProviderDelivery> byDocumentJobId = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, ProviderDelivery> byDeliveryRequestId = new ConcurrentHashMap<>();

    /** Nimmt einen Dispatch idempotent an und liefert den (ggf. bereits vorhandenen) Eintrag. */
    public Result accept(DeliveryDispatchRequest request) {
        ProviderDelivery existing = byDocumentJobId.get(request.documentJobId());
        if (existing != null) {
            return new Result(existing, true);
        }
        String deliveryRequestId = "DR-" + request.documentJobId();
        FailureProfile profile = request.failureProfile() != null ? request.failureProfile() : FailureProfile.HAPPY;
        ProviderDelivery created = new ProviderDelivery(
                deliveryRequestId,
                request.documentJobId(),
                profile,
                initialStatus(profile),
                "PROV-" + Integer.toHexString(Math.abs(deliveryRequestId.hashCode())),
                "cb-" + deliveryRequestId);
        // Idempotent: nur einsetzen, falls noch nicht vorhanden (paralleler doppelter Dispatch)
        ProviderDelivery raced = byDocumentJobId.putIfAbsent(request.documentJobId(), created);
        if (raced != null) {
            return new Result(raced, true);
        }
        byDeliveryRequestId.put(deliveryRequestId, created);
        return new Result(created, false);
    }

    private DeliveryResultStatus initialStatus(FailureProfile profile) {
        return switch (profile) {
            case DELIVERY_REJECTED -> DeliveryResultStatus.REJECTED;
                // Kein/verspaeteter Callback: zunaechst offener, abfragbarer Providerstatus
            case DELIVERY_TIMEOUT, DELIVERY_DELAYED -> DeliveryResultStatus.PENDING;
            default -> DeliveryResultStatus.ACCEPTED;
        };
    }

    public Optional<ProviderDelivery> byDeliveryRequestId(String deliveryRequestId) {
        return Optional.ofNullable(byDeliveryRequestId.get(deliveryRequestId));
    }

    public Optional<ProviderDelivery> byDocumentJobId(String documentJobId) {
        return Optional.ofNullable(byDocumentJobId.get(documentJobId));
    }

    public Collection<ProviderDelivery> all() {
        return byDocumentJobId.values();
    }

    public void clear() {
        byDocumentJobId.clear();
        byDeliveryRequestId.clear();
    }

    /** Ergebnis einer Annahme: der Eintrag und ob es sich um eine Dublette handelte. */
    public record Result(ProviderDelivery delivery, boolean duplicate) {}
}
