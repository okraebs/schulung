package de.demo.versicherung.korrespondenz.simulator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

/**
 * Simuliert externe Quellsysteme (Kunde/Vertrag/Tarif) und das Output-Management (E-Mail,
 * Kundenpostfach, Druck) mit deterministischen Fehlerprofilen (Auftrag 12). Port 8082.
 */
@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties(SimulatorProperties.class)
public class SimulatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimulatorApplication.class, args);
    }

    /** Scheduler fuer die zeitversetzten, deterministischen Provider-Callbacks. */
    @Bean
    public TaskScheduler simulatorTaskScheduler() {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(4);
        scheduler.setThreadNamePrefix("sim-callback-");
        return scheduler;
    }
}
