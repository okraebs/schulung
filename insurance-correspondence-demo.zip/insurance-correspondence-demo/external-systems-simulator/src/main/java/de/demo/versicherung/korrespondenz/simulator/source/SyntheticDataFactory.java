package de.demo.versicherung.korrespondenz.simulator.source;

import de.demo.versicherung.korrespondenz.contracts.ContractData;
import de.demo.versicherung.korrespondenz.contracts.CustomerData;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.TariffData;
import org.springframework.stereotype.Component;

/**
 * Erzeugt deterministische, rein synthetische Stammdaten (Auftrag 5.5) und wendet das jeweilige
 * {@link FailureProfile} an, indem Pflicht- bzw. Optionalfelder gezielt weggelassen werden.
 *
 * <p>Alle Werte sind aus der ID abgeleitet (kein Zufall), damit Demos reproduzierbar sind.
 */
@Component
public class SyntheticDataFactory {

    private static final String[] LANGUAGES = {"de", "de", "de", "en"};
    private static final String[] STATES = {"BY", "NW", "BE", "HE", "SN"};
    private static final String[] PRODUCTS = {"KFZ", "HAUSRAT", "LEBEN", "RECHTSSCHUTZ"};
    private static final String[] CHANNELS = {"EMAIL", "CUSTOMER_PORTAL", "PRINT"};

    private static int slot(String id, int modulo) {
        return Math.floorMod(id.hashCode(), modulo);
    }

    public CustomerData customer(String customerId, FailureProfile profile) {
        String language = LANGUAGES[slot(customerId, LANGUAGES.length)];
        String state = STATES[slot(customerId + "s", STATES.length)];
        String channel = CHANNELS[slot(customerId + "c", CHANNELS.length)];
        String fullName = "Kundin " + Integer.toHexString(Math.abs(customerId.hashCode()));
        String email = customerId.toLowerCase() + "@example.test";
        String postal = "Musterstrasse " + (slot(customerId, 89) + 1) + ", 80000 Musterstadt";
        String advisor = "Betreuer " + state;
        String marketing = "Beilage-" + language.toUpperCase();

        boolean dropOptional = profile == FailureProfile.OPTIONAL_DATA_MISSING;
        boolean dropMandatory = profile == FailureProfile.MANDATORY_DATA_MISSING;

        // Bei MANDATORY_DATA_MISSING fehlt die Zieladresse (E-Mail + Anschrift); der Kundenname
        // bleibt erhalten, damit eine manuelle Korrektur (correctedEmail/-PostalAddress) den
        // Auftrag wieder vollstaendig machen kann (Auftrag 6.2: RETRY nach Korrektur).
        // MANDATORY_DATA_MISSING entfernt ausschliesslich die Pflicht-Zieladresse, damit eine
        // Adresskorrektur den Auftrag wieder vollstaendig macht. OPTIONAL_DATA_MISSING entfernt nur
        // die optionalen Felder (Betreuer/Beilage).
        return new CustomerData(
                customerId,
                fullName,
                language,
                state,
                dropMandatory ? null : email,
                dropMandatory ? null : postal,
                channel,
                dropOptional ? null : advisor,
                dropOptional ? null : marketing);
    }

    public ContractData contract(String contractId, FailureProfile profile) {
        String product = PRODUCTS[slot(contractId, PRODUCTS.length)];
        String number = "VN-" + Math.abs(contractId.hashCode() % 1_000_000);
        String effectiveDate = "2026-07-01";
        return new ContractData(contractId, number, product, effectiveDate, "alt", "neu");
    }

    public TariffData tariff(String product, FailureProfile profile) {
        boolean dropOptional = profile == FailureProfile.OPTIONAL_DATA_MISSING;
        String reason = dropOptional ? null : "Jaehrliche Anpassung";
        return new TariffData(product, product + "-Tarif 2026", "100,00", "108,50", reason);
    }
}
