package de.demo.versicherung.korrespondenz.contracts;

/**
 * Deterministische Fehlerprofile des Simulators (Auftrag 12.3 / 12.4). Steuern reproduzierbar,
 * welche Fehlersituation eine Demo erzeugt. Keine zufaelligen, nicht reproduzierbaren Fehler.
 */
public enum FailureProfile {
    /** Alles vorhanden, technische Annahme erfolgt zeitnah. */
    HAPPY,
    /** Nur optionale Daten fehlen -> erlaubte Degradation. */
    OPTIONAL_DATA_MISSING,
    /** Pflichtdaten fehlen -> menschliche Klaerung. */
    MANDATORY_DATA_MISSING,
    /** Voruebergehender Quellsystemfehler -> External-Task-Retries. */
    TRANSIENT_SOURCE_FAILURE,
    /** Dauerhafter Renderfehler -> Incident nach aufgebrauchten Retries. */
    PERMANENT_RENDER_FAILURE,
    /** Technische Annahme kommt verspaetet (Timer/Reconciliation greift). */
    DELIVERY_DELAYED,
    /** Provider lehnt ab. */
    DELIVERY_REJECTED,
    /** Kein Callback; nur abfragbarer Providerstatus (Timeout-Pfad). */
    DELIVERY_TIMEOUT,
    /** Derselbe callbackEventId wird mehrfach gesendet (Idempotenz-Demo). */
    DUPLICATE_CALLBACK,
    /** Callback wird wiederholt, waehrend der Orchestrator unten ist (Inbox-Demo). */
    CALLBACK_WHILE_ORCHESTRATOR_DOWN
}
