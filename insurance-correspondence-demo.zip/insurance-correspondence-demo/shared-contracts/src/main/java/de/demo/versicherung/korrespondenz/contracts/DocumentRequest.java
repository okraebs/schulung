package de.demo.versicherung.korrespondenz.contracts;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;

/**
 * Kanonischer Dokumentauftrag (Auftrag 5.2). Wird über {@code POST /api/document-requests}
 * entgegengenommen und ausschliesslich anhand von {@code documentJobId} idempotent verarbeitet.
 *
 * <p>{@code documentJobId} ist Business Key und Idempotency Key (Auftrag 4.6).
 *
 * @param documentJobId stabile fachliche ID und Business Key
 * @param sourceEventId ID des ausloesenden Ereignisses
 * @param requestSource Herkunft (Einzelereignis oder Batch)
 * @param documentType Dokumentart
 * @param customerId Kundenreferenz (synthetisch)
 * @param contractId Vertragsreferenz (synthetisch)
 * @param requestedAt Zeitpunkt der Anforderung
 * @param batchId optionale Batch-Zugehoerigkeit
 * @param failureProfile optionales deterministisches Fehlerprofil fuer die Demo
 */
public record DocumentRequest(
        @NotBlank String documentJobId,
        @NotBlank String sourceEventId,
        @NotNull RequestSource requestSource,
        @NotNull DocumentType documentType,
        @NotBlank String customerId,
        @NotBlank String contractId,
        @NotNull Instant requestedAt,
        String batchId,
        FailureProfile failureProfile) {

    /** Liefert das wirksame Fehlerprofil; fehlt es, gilt {@link FailureProfile#HAPPY}. */
    public FailureProfile effectiveFailureProfile() {
        return failureProfile != null ? failureProfile : FailureProfile.HAPPY;
    }
}
