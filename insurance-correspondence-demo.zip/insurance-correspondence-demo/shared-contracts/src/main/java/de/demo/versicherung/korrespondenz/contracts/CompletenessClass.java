package de.demo.versicherung.korrespondenz.contracts;

/** Ergebnis der Datenvollstaendigkeits-Entscheidung data-completeness.dmn (Auftrag 7.1). */
public enum CompletenessClass {
    /** Alle Pflicht- und optionalen Daten vorhanden. */
    FULL,
    /** Nur optionale Daten fehlen; reduzierter Versand ausdruecklich erlaubt. */
    DEGRADED_ALLOWED,
    /** Pflichtdaten fehlen oder Degradation unzulaessig; menschliche Klaerung noetig. */
    MANUAL_REQUIRED
}
