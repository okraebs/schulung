package de.demo.versicherung.korrespondenz.contracts;

/**
 * Synthetische Kundendaten aus dem Simulator (Auftrag 5.3/5.4). Pflichtfelder sind {@code fullName}
 * und – je nach Kanal – eine passende Zieladresse ({@code email} bzw. {@code postalAddress}).
 * Optionale Felder sind {@code advisorName} und {@code marketingInsert}.
 *
 * <p>Der Worker leitet daraus {@code customerDataStatus} ab; der Simulator liefert die Rohdaten.
 */
public record CustomerData(
        String customerId,
        String fullName,
        String preferredLanguage,
        String federalState,
        String email,
        String postalAddress,
        String preferredChannel,
        String advisorName,
        String marketingInsert) {}
