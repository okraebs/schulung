package de.demo.versicherung.korrespondenz.contracts;

/**
 * Synthetische Tarifdaten aus dem Simulator (Auftrag 8.3). Geldbetraege werden als Strings gefuehrt,
 * damit Prozessvariablen klein und primitiv bleiben (Auftrag 4.5).
 */
public record TariffData(
        String product, String tariffName, String premiumOld, String premiumNew, String adjustmentReason) {}
