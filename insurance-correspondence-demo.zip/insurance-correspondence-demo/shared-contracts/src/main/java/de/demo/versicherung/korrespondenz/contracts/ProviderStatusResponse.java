package de.demo.versicherung.korrespondenz.contracts;

/**
 * Abfragbarer Providerstatus fuer die Reconciliation (Auftrag 8.6 / 12.6).
 *
 * @param deliveryRequestId technische ID des Delivery Requests
 * @param deliveryResultStatus aktueller Zustand beim Provider
 * @param providerReference optionale Providerreferenz
 */
public record ProviderStatusResponse(
        String deliveryRequestId, DeliveryResultStatus deliveryResultStatus, String providerReference) {}
