package de.demo.versicherung.korrespondenz.contracts;

/** Zulaessige Entscheidungen in der User Task "Dokumentauftrag manuell klären" (Auftrag 6.2). */
public enum ManualResolution {
    /** Kontrolliert zurueck zur Datenbeschaffung springen. */
    RETRY_ENRICHMENT,
    /** Reduziert ausliefern (nur bei erlaubter Degradation zulaessig). */
    DELIVER_REDUCED,
    /** Auftrag beenden -> Outcome CANCELLED_AFTER_MANUAL_REVIEW. */
    CANCEL_REQUEST
}
