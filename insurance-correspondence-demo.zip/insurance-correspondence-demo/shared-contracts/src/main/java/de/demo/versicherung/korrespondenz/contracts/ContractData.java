package de.demo.versicherung.korrespondenz.contracts;

/**
 * Synthetische Vertragsdaten aus dem Simulator (Auftrag 8.2). Pflichtfelder sind
 * {@code contractNumber}, {@code product} und {@code effectiveDate}.
 */
public record ContractData(
        String contractId,
        String contractNumber,
        String product,
        String effectiveDate,
        String previousValue,
        String newValue) {}
