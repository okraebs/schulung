package de.demo.versicherung.korrespondenz.contracts.fixtures;

import de.demo.versicherung.korrespondenz.contracts.DocumentRequest;
import de.demo.versicherung.korrespondenz.contracts.DocumentType;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.RequestSource;
import java.time.Instant;

/**
 * Gemeinsame, deterministische Test-Fixtures (Auftrag 3.1). Verwenden ausschliesslich synthetische
 * Daten (Auftrag 5.5). Stehen bewusst im Hauptscope, damit alle Module sie in Tests nutzen koennen.
 */
public final class DemoFixtures {

    private DemoFixtures() {}

    private static final Instant FIXED_REQUESTED_AT = Instant.parse("2026-06-20T08:00:00Z");

    /** Happy-Path-Einzelereignis fuer eine Vertragsaenderungsbestaetigung. */
    public static DocumentRequest happyContractChange(String documentJobId) {
        return new DocumentRequest(
                documentJobId,
                "evt-" + documentJobId,
                RequestSource.SINGLE_EVENT,
                DocumentType.CONTRACT_CHANGE_CONFIRMATION,
                "C-1001",
                "V-2001",
                FIXED_REQUESTED_AT,
                null,
                FailureProfile.HAPPY);
    }

    /** Auftrag mit einem bestimmten deterministischen Fehlerprofil. */
    public static DocumentRequest withFailureProfile(String documentJobId, FailureProfile profile) {
        DocumentRequest base = happyContractChange(documentJobId);
        return new DocumentRequest(
                base.documentJobId(),
                base.sourceEventId(),
                base.requestSource(),
                base.documentType(),
                base.customerId(),
                base.contractId(),
                base.requestedAt(),
                base.batchId(),
                profile);
    }
}
