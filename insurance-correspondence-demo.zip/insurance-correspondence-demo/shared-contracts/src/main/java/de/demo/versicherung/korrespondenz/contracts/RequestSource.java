package de.demo.versicherung.korrespondenz.contracts;

/** Herkunft eines Dokumentauftrags (Auftrag 1: zwei Ausloeser). */
public enum RequestSource {
    /** Einzelnes Vertragsaenderungs-Ereignis. */
    SINGLE_EVENT,
    /** Periodische Beitragsanpassung ueber den Batch-Planer. */
    BATCH
}
