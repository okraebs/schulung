package de.demo.versicherung.korrespondenz.contracts;

/**
 * Status der Datenbeschaffung je Quellsystem (customerDataStatus, contractDataStatus,
 * tariffDataStatus). Trennt fachliche Unvollstaendigkeit von technischen Fehlern (Auftrag 8.10).
 */
public enum DataStatus {
    /** Alle relevanten Daten geliefert. */
    OK,
    /** Nur optionale Felder fehlen (fachlich degradierbar). */
    OPTIONAL_MISSING,
    /** Pflichtfelder fehlen (fuehrt zu menschlicher Klaerung). */
    MANDATORY_MISSING
}
