package de.demo.versicherung.korrespondenz.contracts;

/** Unterstuetzte Dokumentarten (Auftrag 5.1). */
public enum DocumentType {
    /** Ereignisgetrieben durch eine einzelne Vertragsaenderung (Auftrag 5.1.1). */
    CONTRACT_CHANGE_CONFIRMATION,
    /** Ueberwiegend im Batch erzeugte Beitragsanpassung (Auftrag 5.1.2). */
    PREMIUM_ADJUSTMENT
}
