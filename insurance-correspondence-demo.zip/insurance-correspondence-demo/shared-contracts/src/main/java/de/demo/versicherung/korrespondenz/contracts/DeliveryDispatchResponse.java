package de.demo.versicherung.korrespondenz.contracts;

/**
 * Antwort des Output-Managements auf einen Dispatch (Auftrag 8.5).
 *
 * @param deliveryRequestId technische ID des (ggf. wiederverwendeten) Delivery Requests
 * @param accepted true, wenn der Auftrag angenommen wurde
 * @param duplicate true, wenn dieser documentJobId bereits einen Request hatte (Idempotenz)
 */
public record DeliveryDispatchResponse(String deliveryRequestId, boolean accepted, boolean duplicate) {}
