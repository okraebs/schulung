package de.demo.versicherung.korrespondenz.contracts;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Auftrag des Workers an das Output-Management des Simulators (Auftrag 8.5 / 12.1).
 *
 * <p>{@code documentJobId} dient als Idempotency-ID: derselbe Auftrag erzeugt keinen zweiten
 * Providerauftrag (Auftrag 12.6). {@code failureProfile} steuert das deterministische Verhalten.
 *
 * @param documentJobId fachlicher Schluessel und Idempotency-ID
 * @param deliveryChannel gewaehlter Auslieferungskanal
 * @param recipient zum Kanal passende Zieladresse (z. B. E-Mail oder Postanschrift)
 * @param documentUri Referenz auf das gerenderte PDF (nicht der Inhalt)
 * @param documentSha256 Hash des Dokuments
 * @param priority Zustellpriorität
 * @param failureProfile deterministisches Fehlerprofil fuer die Demo
 */
public record DeliveryDispatchRequest(
        @NotBlank String documentJobId,
        @NotNull DeliveryChannel deliveryChannel,
        String recipient,
        @NotBlank String documentUri,
        String documentSha256,
        String priority,
        FailureProfile failureProfile) {}
