package de.demo.versicherung.korrespondenz.contracts;

/**
 * Zentrale, modulübergreifende Namenskonstanten: Prozessschlüssel, Message-Namen,
 * External-Task-Topics, BPMN-Error-Codes und Prozessvariablennamen (Auftrag 10.2).
 *
 * <p>Technische IDs sind englisch (Auftrag 3.8). Eine einzige Definitionsstelle verhindert
 * Tippfehler-Divergenzen zwischen BPMN/DMN, Orchestrator und Worker.
 */
public final class ProcessConstants {

    private ProcessConstants() {}

    // --- Prozessschlüssel ---
    public static final String PROCESS_DOCUMENT_FULFILLMENT = "document_fulfillment";
    public static final String PROCESS_BATCH_PLANNER = "document_batch_planner";

    // --- Message-Namen ---
    public static final String MSG_DOCUMENT_REQUEST_RECEIVED = "DocumentRequestReceived";
    public static final String MSG_DELIVERY_RESULT_RECEIVED = "DeliveryResultReceived";

    // --- External-Task-Topics (Auftrag 8) ---
    public static final String TOPIC_LOAD_CUSTOMER = "load-customer-data";
    public static final String TOPIC_LOAD_CONTRACT = "load-contract-data";
    public static final String TOPIC_LOAD_TARIFF = "load-tariff-data";
    public static final String TOPIC_RENDER_DOCUMENT = "render-document";
    public static final String TOPIC_DISPATCH_DOCUMENT = "dispatch-document";
    public static final String TOPIC_RECONCILE_DELIVERY = "reconcile-delivery";
    public static final String TOPIC_PLAN_BATCH = "plan-batch";
    public static final String TOPIC_PUBLISH_BATCH_PAGE = "publish-batch-page";

    // --- BPMN-Error-Codes (Auftrag 8.10.4) ---
    public static final String ERROR_MANUAL_REVIEW_REQUIRED = "MANUAL_REVIEW_REQUIRED";
    public static final String ERROR_PERMANENT_RENDER_FAILURE = "PERMANENT_RENDER_FAILURE";

    // --- Prozessvariablen (Auftrag 10.2) ---
    public static final String VAR_DOCUMENT_JOB_ID = "documentJobId";
    public static final String VAR_SOURCE_EVENT_ID = "sourceEventId";
    public static final String VAR_REQUEST_SOURCE = "requestSource";
    public static final String VAR_BATCH_ID = "batchId";
    public static final String VAR_DOCUMENT_TYPE = "documentType";
    public static final String VAR_CUSTOMER_ID = "customerId";
    public static final String VAR_CONTRACT_ID = "contractId";
    public static final String VAR_REQUESTED_AT = "requestedAt";
    public static final String VAR_FAILURE_PROFILE = "failureProfile";

    public static final String VAR_CUSTOMER_DATA_STATUS = "customerDataStatus";
    public static final String VAR_CONTRACT_DATA_STATUS = "contractDataStatus";
    public static final String VAR_TARIFF_DATA_STATUS = "tariffDataStatus";

    public static final String VAR_COMPLETENESS_CLASS = "completenessClass";
    public static final String VAR_DEGRADATION_ALLOWED = "degradationAllowed";
    public static final String VAR_MISSING_REQUIRED_FIELDS = "missingRequiredFields";
    public static final String VAR_DEGRADED = "degraded";
    public static final String VAR_DEGRADATION_REASONS = "degradationReasons";

    public static final String VAR_TEMPLATE_ID = "templateId";
    public static final String VAR_LANGUAGE = "language";
    public static final String VAR_LEGAL_TEXT_KEY = "legalTextKey";
    public static final String VAR_ATTACHMENT_KEYS = "attachmentKeys";

    public static final String VAR_DELIVERY_CHANNEL = "deliveryChannel";
    public static final String VAR_DELIVERY_PRIORITY = "deliveryPriority";
    public static final String VAR_REQUIRES_TECHNICAL_ACK = "requiresTechnicalAck";
    public static final String VAR_ACKNOWLEDGEMENT_TIMEOUT = "acknowledgementTimeout";
    public static final String VAR_MAX_STATUS_CHECKS = "maxStatusChecks";
    public static final String VAR_STATUS_CHECK_COUNT = "statusCheckCount";

    public static final String VAR_DOCUMENT_URI = "documentUri";
    public static final String VAR_DOCUMENT_SHA256 = "documentSha256";
    public static final String VAR_DOCUMENT_SIZE = "documentSize";
    public static final String VAR_DOCUMENT_CONTENT_TYPE = "documentContentType";

    public static final String VAR_DELIVERY_REQUEST_ID = "deliveryRequestId";
    public static final String VAR_DELIVERY_RESULT_STATUS = "deliveryResultStatus";
    public static final String VAR_PROVIDER_REFERENCE = "providerReference";

    public static final String VAR_MANUAL_REASON = "manualReason";
    public static final String VAR_MANUAL_RESOLUTION = "manualResolution";
    public static final String VAR_MANUAL_COMMENT = "manualComment";

    public static final String VAR_OUTCOME = "outcome";

    // --- Candidate Group der User Task (Auftrag 6.2) ---
    public static final String GROUP_DOCUMENT_OPS = "document-ops";
}
