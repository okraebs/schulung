package de.demo.versicherung.korrespondenz.contracts;

/** Ergebnis der technischen Annahme bzw. Reconciliation (Auftrag 6.1.9 / 8.6). */
public enum DeliveryResultStatus {
    /** Provider hat die Zustellung technisch angenommen. */
    ACCEPTED,
    /** Noch keine endgueltige Antwort; Reconciliation kann zurueckschleifen. */
    PENDING,
    /** Provider hat endgueltig abgelehnt. */
    REJECTED,
    /** Zustand unbekannt; fuehrt zur menschlichen Klaerung. */
    UNKNOWN
}
