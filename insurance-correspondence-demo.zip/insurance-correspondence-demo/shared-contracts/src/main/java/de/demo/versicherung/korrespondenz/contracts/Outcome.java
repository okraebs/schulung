package de.demo.versicherung.korrespondenz.contracts;

/**
 * Mögliche finale fachliche Ergebnisse eines Dokumentauftrags (Auftrag 1.28).
 *
 * <p>Achtung: {@code MANUAL_REVIEW} und {@code TECHNICAL_INCIDENT} sind KEINE Endzustaende, sondern
 * aktive Wartezustaende und daher hier bewusst nicht enthalten.
 */
public enum Outcome {
    /** Vollstaendig technisch uebergeben. */
    FULLY_DISPATCHED,
    /** Reduziert (nur optionale Inhalte fehlten) und durch DMN erlaubt uebergeben. */
    DEGRADED_DISPATCHED,
    /** Nach menschlicher Pruefung abgebrochen. */
    CANCELLED_AFTER_MANUAL_REVIEW
}
