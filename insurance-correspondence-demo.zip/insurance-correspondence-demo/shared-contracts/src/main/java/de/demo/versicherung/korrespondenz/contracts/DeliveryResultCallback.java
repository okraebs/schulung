package de.demo.versicherung.korrespondenz.contracts;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Idempotenter Simulator-Callback der technischen Annahme (Auftrag 6.1.9 / 11.6).
 *
 * @param documentJobId fachlicher Schluessel zur Korrelation
 * @param deliveryRequestId technische ID des Delivery Requests
 * @param deliveryResultStatus Ergebnis der technischen Annahme
 * @param providerReference Referenz des Output-Managements
 * @param callbackEventId eindeutige Callback-ID (Unique Constraint, Dedup-Schluessel)
 */
public record DeliveryResultCallback(
        @NotBlank String documentJobId,
        @NotBlank String deliveryRequestId,
        @NotNull DeliveryResultStatus deliveryResultStatus,
        String providerReference,
        @NotBlank String callbackEventId) {}
