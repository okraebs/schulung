package de.demo.versicherung.korrespondenz.contracts;

/** Auslieferungskanal laut delivery-policy.dmn (Auftrag 7.3). */
public enum DeliveryChannel {
    /** Versand per E-Mail. */
    EMAIL,
    /** Zustellung in das Kundenpostfach. */
    CUSTOMER_PORTAL,
    /** Physischer Druck und Postversand. */
    PRINT
}
