package de.demo.versicherung.korrespondenz.contracts;

import static org.assertj.core.api.Assertions.assertThat;

import de.demo.versicherung.korrespondenz.contracts.fixtures.DemoFixtures;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.time.Instant;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class DocumentRequestValidationTest {

    private static ValidatorFactory factory;
    private static Validator validator;

    @BeforeAll
    static void setUp() {
        factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @AfterAll
    static void tearDown() {
        factory.close();
    }

    @Test
    void validRequestHasNoViolations() {
        var request = DemoFixtures.happyContractChange("DOC-1");
        assertThat(validator.validate(request)).isEmpty();
    }

    @Test
    void blankDocumentJobIdIsRejected() {
        var invalid = new DocumentRequest(
                "  ",
                "evt-1",
                RequestSource.SINGLE_EVENT,
                DocumentType.CONTRACT_CHANGE_CONFIRMATION,
                "C-1",
                "V-1",
                Instant.parse("2026-06-20T08:00:00Z"),
                null,
                null);
        assertThat(validator.validate(invalid))
                .anyMatch(v -> v.getPropertyPath().toString().equals("documentJobId"));
    }

    @Test
    void effectiveFailureProfileDefaultsToHappy() {
        var request = new DocumentRequest(
                "DOC-2",
                "evt-2",
                RequestSource.SINGLE_EVENT,
                DocumentType.CONTRACT_CHANGE_CONFIRMATION,
                "C-1",
                "V-1",
                Instant.parse("2026-06-20T08:00:00Z"),
                null,
                null);
        assertThat(request.effectiveFailureProfile()).isEqualTo(FailureProfile.HAPPY);
    }
}
