package de.demo.versicherung.korrespondenz.dmn;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.camunda.bpm.engine.DecisionService;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Parametrisierte DMN-Tests mit lesbarer Regelmatrix (Auftrag 7.4 / 18.3). Deckt Happy Paths,
 * Grenzfaelle, Vorrang (FIRST) und Default-Regeln ab. Alle Tabellen haben eine Default-Regel,
 * daher kann kein No-Match auftreten – das ist bewusst so modelliert und hier abgesichert.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ActiveProfiles("test")
class DmnDecisionTest {

    @Autowired
    DecisionService decisionService;

    // --- data-completeness ---

    static java.util.stream.Stream<Arguments> completenessCases() {
        return java.util.stream.Stream.of(
                Arguments.of("OK", "OK", "OK", "FULL", false),
                Arguments.of("OPTIONAL_MISSING", "OK", "OK", "DEGRADED_ALLOWED", true),
                Arguments.of("OK", "OK", "OPTIONAL_MISSING", "DEGRADED_ALLOWED", true),
                Arguments.of("MANDATORY_MISSING", "OK", "OK", "MANUAL_REQUIRED", false),
                Arguments.of("OK", "MANDATORY_MISSING", "OK", "MANUAL_REQUIRED", false),
                Arguments.of("OK", "OK", "MANDATORY_MISSING", "MANUAL_REQUIRED", false),
                // Vorrang: Pflichtfehler schlaegt optionalen Fehler (FIRST-Reihenfolge)
                Arguments.of("MANDATORY_MISSING", "OK", "OPTIONAL_MISSING", "MANUAL_REQUIRED", false));
    }

    @ParameterizedTest(name = "completeness[{0},{1},{2}] -> {3}")
    @MethodSource("completenessCases")
    void dataCompleteness(
            String customer, String contract, String tariff, String expectedClass, boolean expectedDegraded) {
        Map<String, Object> result = evaluate(
                "data-completeness",
                Variables.createVariables()
                        .putValue("customerDataStatus", customer)
                        .putValue("contractDataStatus", contract)
                        .putValue("tariffDataStatus", tariff));
        assertThat(result.get("completenessClass")).isEqualTo(expectedClass);
        assertThat(result.get("degraded")).isEqualTo(expectedDegraded);
    }

    // --- document-variant ---

    static java.util.stream.Stream<Arguments> variantCases() {
        return java.util.stream.Stream.of(
                Arguments.of("CONTRACT_CHANGE_CONFIRMATION", "de", "CCC_DE"),
                Arguments.of("CONTRACT_CHANGE_CONFIRMATION", "en", "CCC_EN"),
                Arguments.of("PREMIUM_ADJUSTMENT", "de", "PA_DE"),
                Arguments.of("PREMIUM_ADJUSTMENT", "en", "PA_EN"),
                Arguments.of("UNKNOWN", "de", "GENERIC"));
    }

    @ParameterizedTest(name = "variant[{0},{1}] -> {2}")
    @MethodSource("variantCases")
    void documentVariant(String documentType, String language, String expectedTemplate) {
        Map<String, Object> result = evaluate(
                "document-variant",
                Variables.createVariables()
                        .putValue("documentType", documentType)
                        .putValue("language", language));
        assertThat(result.get("templateId")).isEqualTo(expectedTemplate);
    }

    // --- delivery-policy ---

    @Test
    void deliveryPolicyKeepsPrintPreference() {
        Map<String, Object> result = evaluate(
                "delivery-policy",
                Variables.createVariables()
                        .putValue("deliveryChannel", "PRINT")
                        .putValue("documentType", "CONTRACT_CHANGE_CONFIRMATION"));
        assertThat(result.get("deliveryChannel")).isEqualTo("PRINT");
        assertThat(result.get("requiresTechnicalAck")).isEqualTo(true);
        assertThat(((Number) result.get("maxStatusChecks")).intValue()).isEqualTo(3);
    }

    @Test
    void deliveryPolicyPremiumIsHighPriorityWithMoreChecks() {
        Map<String, Object> result = evaluate(
                "delivery-policy",
                Variables.createVariables()
                        .putValue("deliveryChannel", "EMAIL")
                        .putValue("documentType", "PREMIUM_ADJUSTMENT"));
        assertThat(result.get("deliveryPriority")).isEqualTo("HIGH");
        assertThat(((Number) result.get("maxStatusChecks")).intValue()).isEqualTo(5);
    }

    @Test
    void deliveryPolicyDefaultIsEmailNormal() {
        Map<String, Object> result = evaluate(
                "delivery-policy",
                Variables.createVariables()
                        .putValue("deliveryChannel", "EMAIL")
                        .putValue("documentType", "CONTRACT_CHANGE_CONFIRMATION"));
        assertThat(result.get("deliveryChannel")).isEqualTo("EMAIL");
        assertThat(result.get("deliveryPriority")).isEqualTo("NORMAL");
    }

    private Map<String, Object> evaluate(String decisionKey, org.camunda.bpm.engine.variable.VariableMap variables) {
        return decisionService
                .evaluateDecisionTableByKey(decisionKey, variables)
                .getSingleResult()
                .getEntryMap();
    }
}
