package de.demo.versicherung.korrespondenz;

import static org.assertj.core.api.Assertions.assertThat;

import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RepositoryService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Phase-1-Smoke-Test: Der Spring-Kontext startet mit eingebetteter Camunda-Engine, der minimale
 * Prozess ist deployed und die Demo-Identitaeten (demo, ops, document-ops) sind angelegt.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ActiveProfiles("test")
class OrchestratorSmokeTest {

    @Autowired
    ProcessEngine processEngine;

    @Autowired
    RepositoryService repositoryService;

    @Autowired
    IdentityService identityService;

    @Test
    void engineStartsAndSmokeProcessIsDeployed() {
        assertThat(processEngine).isNotNull();
        long deployed = repositoryService
                .createProcessDefinitionQuery()
                .processDefinitionKey("smoke_process")
                .count();
        assertThat(deployed).isGreaterThanOrEqualTo(1);
    }

    @Test
    void demoIdentitiesAreProvisioned() {
        assertThat(identityService.createUserQuery().userId("demo").count())
                .as("Admin-Benutzer demo")
                .isEqualTo(1);
        assertThat(identityService.createUserQuery().userId("ops").count())
                .as("Benutzer ops")
                .isEqualTo(1);
        assertThat(identityService.createGroupQuery().groupId("document-ops").count())
                .as("Gruppe document-ops")
                .isEqualTo(1);
        assertThat(identityService
                        .createUserQuery()
                        .userId("ops")
                        .memberOfGroup("document-ops")
                        .count())
                .as("ops ist Mitglied von document-ops")
                .isEqualTo(1);
    }
}
