package de.demo.versicherung.korrespondenz.process;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import de.demo.versicherung.korrespondenz.api.DocumentRequestService;
import de.demo.versicherung.korrespondenz.api.DocumentRequestStatus;
import de.demo.versicherung.korrespondenz.contracts.DeliveryResultCallback;
import de.demo.versicherung.korrespondenz.contracts.DeliveryResultStatus;
import de.demo.versicherung.korrespondenz.contracts.ManualResolution;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.contracts.fixtures.DemoFixtures;
import de.demo.versicherung.korrespondenz.inbox.DeliveryCallbackService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.camunda.bpm.engine.ExternalTaskService;
import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.externaltask.LockedExternalTask;
import org.camunda.bpm.engine.runtime.Job;
import org.camunda.bpm.engine.task.Task;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * BPMN-Prozesstests fuer document_fulfillment (Auftrag 18.4.1/18.4.3). External Tasks werden als
 * simulierter Worker vervollstaendigt; die asyncBefore-Jobs (Transaktionsgrenze vor der ersten DMN)
 * werden ueber den ManagementService getrieben. So sind BPMN-Verdrahtung, DMN-Routing und Delegates
 * ohne laufende Worker-/Simulator-Prozesse deterministisch getestet.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ActiveProfiles("test")
class DocumentFulfillmentProcessTest {

    private static final String WORKER_ID = "test-worker";

    @Autowired
    DocumentRequestService documentRequestService;

    @Autowired
    RuntimeService runtimeService;

    @Autowired
    ExternalTaskService externalTaskService;

    @Autowired
    ManagementService managementService;

    @Autowired
    TaskService taskService;

    @Autowired
    DeliveryCallbackService deliveryCallbackService;

    @Test
    void eventDrivenHappyPathReachesFullyDispatched() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-HP-1"));
        drive("DOC-HP-1", "OK");

        DocumentRequestStatus status = documentRequestService.status("DOC-HP-1");
        assertThat(status.status()).isEqualTo("COMPLETED");
        assertThat(status.outcome()).isEqualTo("FULLY_DISPATCHED");
        assertThat(activeCount("DOC-HP-1")).isZero();
    }

    @Test
    void missingOptionalDataReachesDegradedDispatched() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-DEG-1"));
        drive("DOC-DEG-1", "OPTIONAL_MISSING");

        DocumentRequestStatus status = documentRequestService.status("DOC-DEG-1");
        assertThat(status.status()).isEqualTo("COMPLETED");
        assertThat(status.outcome()).isEqualTo("DEGRADED_DISPATCHED");
    }

    @Test
    void missingMandatoryDataReachesUserTask() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-MAN-1"));
        drive("DOC-MAN-1", "MANDATORY_MISSING");

        DocumentRequestStatus status = documentRequestService.status("DOC-MAN-1");
        assertThat(status.status()).isEqualTo("ACTIVE");
        assertThat(status.activeActivity()).contains("manualReview");
    }

    @Test
    void manualCancelEndsCancelledAfterReview() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-CANCEL-1"));
        drive("DOC-CANCEL-1", "MANDATORY_MISSING");
        completeUserTask("DOC-CANCEL-1", ManualResolution.CANCEL_REQUEST, Map.of());

        DocumentRequestStatus status = documentRequestService.status("DOC-CANCEL-1");
        assertThat(status.status()).isEqualTo("COMPLETED");
        assertThat(status.outcome()).isEqualTo("CANCELLED_AFTER_MANUAL_REVIEW");
    }

    @Test
    void manualRetryAfterCorrectionLeadsToSuccess() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-RETRY-1"));
        drive("DOC-RETRY-1", "MANDATORY_MISSING");
        completeUserTask(
                "DOC-RETRY-1", ManualResolution.RETRY_ENRICHMENT, Map.of("correctedEmail", "fix@example.test"));
        // Erneute Anreicherung liefert nun vollstaendige Daten
        drive("DOC-RETRY-1", "OK");

        DocumentRequestStatus status = documentRequestService.status("DOC-RETRY-1");
        assertThat(status.outcome()).isEqualTo("FULLY_DISPATCHED");
    }

    @Test
    void manualDeliverReducedIsRejectedWhenDegradationNotAllowed() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-RED-REJ-1"));
        drive("DOC-RED-REJ-1", "MANDATORY_MISSING");
        // degradationAllowed=false (Pflichtdaten fehlen) -> DELIVER_REDUCED muss abgelehnt werden
        assertThatThrownBy(() -> completeUserTask("DOC-RED-REJ-1", ManualResolution.DELIVER_REDUCED, Map.of()))
                .hasMessageContaining("DELIVER_REDUCED");
        assertThat(documentRequestService.status("DOC-RED-REJ-1").status()).isEqualTo("ACTIVE");
    }

    @Test
    void manualDeliverReducedSucceedsWhenDegradationAllowed() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-RED-OK-1"));
        drive("DOC-RED-OK-1", "MANDATORY_MISSING");
        // Eine erlaubte Degradation simulieren (z. B. spaeter Provider-Pfad)
        runtimeService.setVariable(processInstanceId("DOC-RED-OK-1"), ProcessConstants.VAR_DEGRADATION_ALLOWED, true);
        completeUserTask("DOC-RED-OK-1", ManualResolution.DELIVER_REDUCED, Map.of());
        drive("DOC-RED-OK-1", "OK");

        DocumentRequestStatus status = documentRequestService.status("DOC-RED-OK-1");
        assertThat(status.outcome()).isEqualTo("DEGRADED_DISPATCHED");
    }

    @Test
    void duplicateCallbackProgressesOnlyOnce() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-DUP-1"));
        driveUntilReceive("OK");

        DeliveryCallbackService.Result first = deliveryCallbackService.accept(new DeliveryResultCallback(
                "DOC-DUP-1", "DR-DOC-DUP-1", DeliveryResultStatus.ACCEPTED, "prov-ref", "cb-DUP-1"));
        DeliveryCallbackService.Result second = deliveryCallbackService.accept(new DeliveryResultCallback(
                "DOC-DUP-1", "DR-DOC-DUP-1", DeliveryResultStatus.ACCEPTED, "prov-ref", "cb-DUP-1"));

        assertThat(first.duplicate()).isFalse();
        assertThat(first.correlatedNow()).isTrue();
        assertThat(second.duplicate()).as("zweiter Callback ist Dublette").isTrue();

        DocumentRequestStatus status = documentRequestService.status("DOC-DUP-1");
        assertThat(status.status()).isEqualTo("COMPLETED");
        assertThat(status.outcome()).isEqualTo("FULLY_DISPATCHED");
    }

    @Test
    void deliveryTimeoutTriggersReconciliationLoopThenAccept() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-TMO-1"));
        driveUntilReceive("OK");

        // Erster Timeout -> Reconciliation PENDING -> kontrollierte Rueckschleife
        fireTimer("DOC-TMO-1");
        completeReconcile("DOC-TMO-1", DeliveryResultStatus.PENDING);
        assertThat(isWaitingAtReceive("DOC-TMO-1"))
                .as("zurueck an der Receive Task")
                .isTrue();

        // Zweiter Timeout -> Reconciliation ACCEPTED -> Abschluss
        fireTimer("DOC-TMO-1");
        completeReconcile("DOC-TMO-1", DeliveryResultStatus.ACCEPTED);

        DocumentRequestStatus status = documentRequestService.status("DOC-TMO-1");
        assertThat(status.outcome()).isEqualTo("FULLY_DISPATCHED");
    }

    @Test
    void deliveryRejectedRoutesToUserTask() {
        documentRequestService.startIfAbsent(DemoFixtures.happyContractChange("DOC-REJ-1"));
        driveUntilReceive("OK");

        correlate("DOC-REJ-1", DeliveryResultStatus.REJECTED, "cb-REJ-1");

        DocumentRequestStatus status = documentRequestService.status("DOC-REJ-1");
        assertThat(status.status()).isEqualTo("ACTIVE");
        assertThat(status.activeActivity()).contains("manualReview");
    }

    private String processInstanceId(String businessKey) {
        return runtimeService
                .createProcessInstanceQuery()
                .processInstanceBusinessKey(businessKey)
                .singleResult()
                .getId();
    }

    private void completeUserTask(String businessKey, ManualResolution resolution, Map<String, Object> extra) {
        Task task = taskService
                .createTaskQuery()
                .processInstanceBusinessKey(businessKey)
                .taskDefinitionKey("manualReview")
                .singleResult();
        Map<String, Object> vars = new HashMap<>(extra);
        vars.put(ProcessConstants.VAR_MANUAL_RESOLUTION, resolution.name());
        taskService.complete(task.getId(), vars);
    }

    /**
     * Treibt den Prozess im Happy-Delivery-Modus: arbeitet jobs (asyncBefore) und External Tasks ab
     * und korreliert an der Receive Task automatisch eine ACCEPTED-Annahme ueber die Inbox.
     */
    private void drive(String businessKey, String customerStatus) {
        for (int guard = 0; guard < 200; guard++) {
            if (driveWork(customerStatus)) {
                continue;
            }
            if (isWaitingAtReceive(businessKey)) {
                correlate(businessKey, DeliveryResultStatus.ACCEPTED, "cb-" + businessKey);
                continue;
            }
            return;
        }
    }

    /** Treibt nur jobs + load/render/dispatch-Tasks; stoppt an der Receive Task (ohne Korrelation). */
    private void driveUntilReceive(String customerStatus) {
        while (driveWork(customerStatus)) {
            // weiterarbeiten bis nur noch der Wait State der Receive Task verbleibt
        }
    }

    /** Fuehrt eine Einheit Arbeit aus (faellige jobs ODER External Tasks). True, wenn etwas getan wurde. */
    private boolean driveWork(String customerStatus) {
        List<Job> jobs = managementService.createJobQuery().executable().list();
        if (!jobs.isEmpty()) {
            jobs.forEach(job -> managementService.executeJob(job.getId()));
            return true;
        }
        List<LockedExternalTask> tasks = externalTaskService
                .fetchAndLock(10, WORKER_ID)
                .topic(ProcessConstants.TOPIC_LOAD_CUSTOMER, 10_000)
                .topic(ProcessConstants.TOPIC_LOAD_CONTRACT, 10_000)
                .topic(ProcessConstants.TOPIC_LOAD_TARIFF, 10_000)
                .topic(ProcessConstants.TOPIC_RENDER_DOCUMENT, 10_000)
                .topic(ProcessConstants.TOPIC_DISPATCH_DOCUMENT, 10_000)
                .execute();
        if (tasks.isEmpty()) {
            return false;
        }
        for (LockedExternalTask task : tasks) {
            externalTaskService.complete(task.getId(), WORKER_ID, variablesFor(task.getTopicName(), customerStatus));
        }
        return true;
    }

    private boolean isWaitingAtReceive(String businessKey) {
        return runtimeService
                        .createEventSubscriptionQuery()
                        .eventType("message")
                        .eventName(ProcessConstants.MSG_DELIVERY_RESULT_RECEIVED)
                        .processInstanceId(processInstanceIdOrNull(businessKey))
                        .count()
                > 0;
    }

    private String processInstanceIdOrNull(String businessKey) {
        var pi = runtimeService
                .createProcessInstanceQuery()
                .processInstanceBusinessKey(businessKey)
                .singleResult();
        return pi == null ? "none" : pi.getId();
    }

    private void correlate(String businessKey, DeliveryResultStatus status, String callbackEventId) {
        deliveryCallbackService.accept(
                new DeliveryResultCallback(businessKey, "DR-" + businessKey, status, "prov-ref", callbackEventId));
    }

    private void fireTimer(String businessKey) {
        Job timer = managementService
                .createJobQuery()
                .processInstanceId(processInstanceIdOrNull(businessKey))
                .timers()
                .singleResult();
        managementService.executeJob(timer.getId());
    }

    private void completeReconcile(String businessKey, DeliveryResultStatus status) {
        List<LockedExternalTask> tasks = externalTaskService
                .fetchAndLock(1, WORKER_ID)
                .topic(ProcessConstants.TOPIC_RECONCILE_DELIVERY, 10_000)
                .execute();
        Map<String, Object> vars = new HashMap<>();
        vars.put(ProcessConstants.VAR_DELIVERY_RESULT_STATUS, status.name());
        vars.put(ProcessConstants.VAR_PROVIDER_REFERENCE, "prov-ref");
        externalTaskService.complete(tasks.get(0).getId(), WORKER_ID, vars);
    }

    private long activeCount(String businessKey) {
        return runtimeService
                .createProcessInstanceQuery()
                .processInstanceBusinessKey(businessKey)
                .count();
    }

    private Map<String, Object> variablesFor(String topic, String customerStatus) {
        Map<String, Object> vars = new HashMap<>();
        switch (topic) {
            case ProcessConstants.TOPIC_LOAD_CUSTOMER -> {
                vars.put(ProcessConstants.VAR_CUSTOMER_DATA_STATUS, customerStatus);
                vars.put(ProcessConstants.VAR_LANGUAGE, "de");
                vars.put(ProcessConstants.VAR_DELIVERY_CHANNEL, "EMAIL");
                vars.put("customerFederalState", "BY");
            }
            case ProcessConstants.TOPIC_LOAD_CONTRACT -> {
                vars.put(ProcessConstants.VAR_CONTRACT_DATA_STATUS, "OK");
                vars.put("product", "KFZ");
            }
            case ProcessConstants.TOPIC_LOAD_TARIFF -> vars.put(ProcessConstants.VAR_TARIFF_DATA_STATUS, "OK");
            case ProcessConstants.TOPIC_RENDER_DOCUMENT -> {
                vars.put(ProcessConstants.VAR_DOCUMENT_URI, "file:///var/documents/x/document.pdf");
                vars.put(ProcessConstants.VAR_DOCUMENT_SHA256, "0".repeat(64));
                vars.put(ProcessConstants.VAR_DOCUMENT_SIZE, 1234L);
                vars.put(ProcessConstants.VAR_DOCUMENT_CONTENT_TYPE, "application/pdf");
            }
            case ProcessConstants.TOPIC_DISPATCH_DOCUMENT -> vars.put(ProcessConstants.VAR_DELIVERY_REQUEST_ID, "DR-x");
            default -> {
                /* keine Variablen */
            }
        }
        return vars;
    }
}
