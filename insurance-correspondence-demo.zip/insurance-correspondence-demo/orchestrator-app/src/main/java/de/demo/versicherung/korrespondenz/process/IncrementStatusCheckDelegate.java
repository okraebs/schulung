package de.demo.versicherung.korrespondenz.process;

import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/**
 * Erhoeht {@code statusCheckCount} vor dem Zuruckschleifen zur Receive Task (Auftrag 6.1.11).
 */
@Component("incrementStatusCheckDelegate")
public class IncrementStatusCheckDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        Object current = execution.getVariable(ProcessConstants.VAR_STATUS_CHECK_COUNT);
        int count = current instanceof Number number ? number.intValue() : 0;
        execution.setVariable(ProcessConstants.VAR_STATUS_CHECK_COUNT, count + 1);
    }
}
