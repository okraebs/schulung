package de.demo.versicherung.korrespondenz.api;

import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Demo-REST fuer Batchlaeufe (Auftrag 11.3 / 11.5). */
@RestController
@RequestMapping("/api/demo/batches")
public class BatchController {

    private final RuntimeService runtimeService;
    private final BatchStatusService batchStatusService;

    public BatchController(RuntimeService runtimeService, BatchStatusService batchStatusService) {
        this.runtimeService = runtimeService;
        this.batchStatusService = batchStatusService;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> startBatch(@RequestBody(required = false) BatchRequest request) {
        BatchRequest effective = request != null ? request : new BatchRequest(null, null, null, null, null, null);
        String batchId = "batch-" + UUID.randomUUID().toString().substring(0, 8);

        Map<String, Object> variables = new HashMap<>();
        variables.put(ProcessConstants.VAR_BATCH_ID, batchId);
        variables.put("count", effective.countOr(20));
        variables.put("pageSize", effective.pageSizeOr(25));
        variables.put("targetRate", effective.targetRateOr(3));
        variables.put("maxInFlight", effective.maxInFlightOr(100));
        variables.put("seed", effective.seedOr(42L));
        variables.put(
                ProcessConstants.VAR_FAILURE_PROFILE,
                effective.failureProfileOr(FailureProfile.HAPPY).name());

        runtimeService.startProcessInstanceByKey(ProcessConstants.PROCESS_BATCH_PLANNER, batchId, variables);
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(Map.of("batchId", batchId, "count", effective.countOr(20)));
    }

    @GetMapping("/{batchId}")
    public BatchStatus status(@PathVariable String batchId) {
        return batchStatusService.aggregate(batchId);
    }

    /** Eingabe fuer einen Batchlauf; alle Felder optional mit Defaults. */
    public record BatchRequest(
            Integer count,
            Integer pageSize,
            Integer targetRate,
            Integer maxInFlight,
            Long seed,
            FailureProfile failureProfile) {

        int countOr(int d) {
            return count != null ? count : d;
        }

        int pageSizeOr(int d) {
            return pageSize != null ? pageSize : d;
        }

        int targetRateOr(int d) {
            return targetRate != null ? targetRate : d;
        }

        int maxInFlightOr(int d) {
            return maxInFlight != null ? maxInFlight : d;
        }

        long seedOr(long d) {
            return seed != null ? seed : d;
        }

        FailureProfile failureProfileOr(FailureProfile d) {
            return failureProfile != null ? failureProfile : d;
        }
    }
}
