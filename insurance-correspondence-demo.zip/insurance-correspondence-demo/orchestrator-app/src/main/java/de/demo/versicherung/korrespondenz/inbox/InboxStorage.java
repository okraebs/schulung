package de.demo.versicherung.korrespondenz.inbox;

import de.demo.versicherung.korrespondenz.contracts.DeliveryResultCallback;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Persistiert Inbox-Eintraege in einer eigenen Transaktion (getrennt von der Korrelation). Dadurch
 * bleibt ein Callback auch dann gepuffert, wenn die Korrelation gerade nicht moeglich ist.
 */
@Component
public class InboxStorage {

    private final DeliveryCallbackInboxRepository repository;

    public InboxStorage(DeliveryCallbackInboxRepository repository) {
        this.repository = repository;
    }

    /** Legt einen neuen Eintrag an oder meldet eine Dublette (idempotent ueber callbackEventId). */
    @Transactional
    public Optional<String> storeIfNew(DeliveryResultCallback callback) {
        if (repository.existsByCallbackEventId(callback.callbackEventId())) {
            return Optional.empty();
        }
        DeliveryCallbackInbox entry = new DeliveryCallbackInbox(
                UUID.randomUUID().toString(),
                callback.callbackEventId(),
                callback.documentJobId(),
                callback.deliveryRequestId(),
                callback.deliveryResultStatus().name(),
                callback.providerReference(),
                Instant.now());
        repository.save(entry);
        return Optional.of(entry.getId());
    }

    @Transactional(readOnly = true)
    public List<DeliveryCallbackInbox> pending() {
        return repository.findByStatus(DeliveryCallbackInbox.Status.PENDING);
    }
}
