package de.demo.versicherung.korrespondenz.process;

import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/**
 * Kurzer lokaler Backpressure-Check (Auftrag 6.3): zaehlt die aktuell aktiven
 * document_fulfillment-Instanzen und setzt {@code belowLimit}. Ist {@code maxInFlight} erreicht,
 * wartet der Batch-Planer ueber einen Timer und prueft erneut.
 */
@Component("backpressureCheckDelegate")
public class BackpressureCheckDelegate implements JavaDelegate {

    private final RuntimeService runtimeService;

    public BackpressureCheckDelegate(RuntimeService runtimeService) {
        this.runtimeService = runtimeService;
    }

    @Override
    public void execute(DelegateExecution execution) {
        long inFlight = runtimeService
                .createProcessInstanceQuery()
                .processDefinitionKey(ProcessConstants.PROCESS_DOCUMENT_FULFILLMENT)
                .active()
                .count();
        Object max = execution.getVariable("maxInFlight");
        int maxInFlight = max instanceof Number number ? number.intValue() : 100;
        execution.setVariable("inFlight", inFlight);
        execution.setVariable("belowLimit", inFlight < maxInFlight);
    }
}
