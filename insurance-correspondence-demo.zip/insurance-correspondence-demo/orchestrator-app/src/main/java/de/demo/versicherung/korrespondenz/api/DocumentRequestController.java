package de.demo.versicherung.korrespondenz.api;

import de.demo.versicherung.korrespondenz.contracts.DocumentRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST-API fuer kanonische Dokumentauftraege (Auftrag 11.1 / 11.4). Der POST ist idempotent: eine
 * Dublette startet keinen zweiten Prozess und liefert den bestehenden Status.
 */
@RestController
@RequestMapping("/api/document-requests")
public class DocumentRequestController {

    private final DocumentRequestService service;

    public DocumentRequestController(DocumentRequestService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DocumentRequestStatus> submit(@Valid @RequestBody DocumentRequest request) {
        DocumentRequestStatus status = service.startIfAbsent(request);
        HttpStatus httpStatus = status.duplicate() ? HttpStatus.OK : HttpStatus.CREATED;
        return ResponseEntity.status(httpStatus).body(status);
    }

    @GetMapping("/{documentJobId}")
    public ResponseEntity<DocumentRequestStatus> status(@PathVariable String documentJobId) {
        DocumentRequestStatus status = service.status(documentJobId);
        if ("NOT_FOUND".equals(status.status())) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(status);
    }
}
