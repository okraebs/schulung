package de.demo.versicherung.korrespondenz.inbox;

import de.demo.versicherung.korrespondenz.contracts.DeliveryResultCallback;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Idempotenter Inbox-Dienst (Auftrag 9.4). Trennt Speicherung ({@link InboxStorage}) und Korrelation
 * ({@link MessageCorrelator}) in getrennte Transaktionen: ein Callback wird zuerst sicher gepuffert
 * und dann – tolerant gegen Fehlschlaege – korreliert. Doppelte Callbacks erzeugen keinen zweiten
 * Prozessfortschritt; eine spaetere Korrelation uebernimmt der Scheduler.
 */
@Service
public class DeliveryCallbackService {

    private static final Logger log = LoggerFactory.getLogger(DeliveryCallbackService.class);

    private final InboxStorage storage;
    private final MessageCorrelator correlator;
    private final MeterRegistry meterRegistry;

    public DeliveryCallbackService(InboxStorage storage, MessageCorrelator correlator, MeterRegistry meterRegistry) {
        this.storage = storage;
        this.correlator = correlator;
        this.meterRegistry = meterRegistry;
    }

    public Result accept(DeliveryResultCallback callback) {
        Optional<String> entryId = storage.storeIfNew(callback);
        if (entryId.isEmpty()) {
            meterRegistry.counter("callback.duplicates").increment();
            log.info("Doppelter Callback callbackEventId={} – idempotent ignoriert.", callback.callbackEventId());
            return new Result(true, false);
        }
        boolean correlated = tryCorrelate(entryId.get(), callback.documentJobId());
        return new Result(false, correlated);
    }

    /** Vom Scheduler getrieben: alle noch nicht korrelierten Eintraege erneut versuchen. */
    public int correlatePending() {
        int correlated = 0;
        for (DeliveryCallbackInbox entry : storage.pending()) {
            if (tryCorrelate(entry.getId(), entry.getDocumentJobId())) {
                correlated++;
            }
        }
        return correlated;
    }

    private boolean tryCorrelate(String entryId, String documentJobId) {
        try {
            correlator.correlate(entryId);
            log.info("Callback korreliert: documentJobId={}", documentJobId);
            return true;
        } catch (RuntimeException e) {
            // Noch keine wartende Instanz oder konkurrierender Zugriff -> bleibt PENDING, Scheduler retryt.
            log.debug("Korrelation (noch) nicht moeglich fuer documentJobId={}: {}", documentJobId, e.getMessage());
            return false;
        }
    }

    /**
     * @param duplicate true, wenn der Callback bereits bekannt war (idempotent)
     * @param correlatedNow true, wenn er sofort korreliert werden konnte
     */
    public record Result(boolean duplicate, boolean correlatedNow) {}
}
