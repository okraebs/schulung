package de.demo.versicherung.korrespondenz.api;

import de.demo.versicherung.korrespondenz.contracts.DocumentRequest;
import de.demo.versicherung.korrespondenz.contracts.DocumentType;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.RequestSource;
import java.time.Instant;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Demo-Hilfsendpunkt (Auftrag 11.2): erzeugt ein einzelnes synthetisches
 * CONTRACT_CHANGE_CONFIRMATION-Ereignis und startet den Prozess idempotent.
 */
@RestController
@RequestMapping("/api/demo/events")
public class DemoEventController {

    private final DocumentRequestService service;

    public DemoEventController(DocumentRequestService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DocumentRequestStatus> createEvent(
            @RequestParam(defaultValue = "HAPPY") FailureProfile failureProfile,
            @RequestParam(required = false) String customerId,
            @RequestParam(required = false) String contractId) {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        DocumentRequest request = new DocumentRequest(
                "DOC-" + suffix,
                "evt-" + suffix,
                RequestSource.SINGLE_EVENT,
                DocumentType.CONTRACT_CHANGE_CONFIRMATION,
                customerId != null ? customerId : "C-" + suffix,
                contractId != null ? contractId : "V-" + suffix,
                Instant.now(),
                null,
                failureProfile);
        DocumentRequestStatus status = service.startIfAbsent(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(status);
    }
}
