package de.demo.versicherung.korrespondenz.inbox;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

/**
 * Inbox-Eintrag fuer einen DeliveryResultReceived-Callback (Auftrag 9.4 / 10.6). Die
 * {@code callbackEventId} ist eindeutig (Unique Constraint) und dient der Deduplizierung.
 */
@Entity
@Table(name = "delivery_callback_inbox")
public class DeliveryCallbackInbox {

    public enum Status {
        PENDING,
        CORRELATED
    }

    @Id
    @Column(name = "id", length = 36)
    private String id;

    @Column(name = "callback_event_id", nullable = false, unique = true, length = 100)
    private String callbackEventId;

    @Column(name = "document_job_id", nullable = false, length = 100)
    private String documentJobId;

    @Column(name = "delivery_request_id", length = 100)
    private String deliveryRequestId;

    @Column(name = "delivery_result_status", nullable = false, length = 30)
    private String deliveryResultStatus;

    @Column(name = "provider_reference", length = 100)
    private String providerReference;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private Status status;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "correlated_at")
    private Instant correlatedAt;

    protected DeliveryCallbackInbox() {}

    public DeliveryCallbackInbox(
            String id,
            String callbackEventId,
            String documentJobId,
            String deliveryRequestId,
            String deliveryResultStatus,
            String providerReference,
            Instant createdAt) {
        this.id = id;
        this.callbackEventId = callbackEventId;
        this.documentJobId = documentJobId;
        this.deliveryRequestId = deliveryRequestId;
        this.deliveryResultStatus = deliveryResultStatus;
        this.providerReference = providerReference;
        this.status = Status.PENDING;
        this.createdAt = createdAt;
    }

    public void markCorrelated(Instant when) {
        this.status = Status.CORRELATED;
        this.correlatedAt = when;
    }

    public String getId() {
        return id;
    }

    public String getCallbackEventId() {
        return callbackEventId;
    }

    public String getDocumentJobId() {
        return documentJobId;
    }

    public String getDeliveryResultStatus() {
        return deliveryResultStatus;
    }

    public String getProviderReference() {
        return providerReference;
    }

    public Status getStatus() {
        return status;
    }
}
