package de.demo.versicherung.korrespondenz.api;

import de.demo.versicherung.korrespondenz.contracts.DocumentRequest;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.camunda.bpm.engine.history.HistoricVariableInstance;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Idempotenter Start- und Statusdienst (Auftrag 11.1 / 11.4). Ein wiederholter Aufruf mit derselben
 * {@code documentJobId} startet keinen zweiten Prozess, sondern liefert den bestehenden Status.
 *
 * <p>Die Idempotenz beruht in dieser Phase auf dem Business Key (= documentJobId). Eine zusaetzliche
 * Unique-Constraint-Absicherung ueber {@code document_request_registry} folgt mit der Inbox/Outbox
 * (Phase 5/6) und schliesst auch das Wettlaufrennen zweier paralleler Starts.
 */
@Service
public class DocumentRequestService {

    private static final Logger log = LoggerFactory.getLogger(DocumentRequestService.class);

    private final RuntimeService runtimeService;
    private final HistoryService historyService;
    private final MeterRegistry meterRegistry;

    public DocumentRequestService(
            RuntimeService runtimeService, HistoryService historyService, MeterRegistry meterRegistry) {
        this.runtimeService = runtimeService;
        this.historyService = historyService;
        this.meterRegistry = meterRegistry;
    }

    /** Startet die Prozessinstanz, falls fuer diese documentJobId noch keine existiert. */
    public synchronized DocumentRequestStatus startIfAbsent(DocumentRequest request) {
        String documentJobId = request.documentJobId();
        if (instanceExists(documentJobId)) {
            log.info("Dublette: documentJobId={} existiert bereits, kein neuer Start.", documentJobId);
            return status(documentJobId, true);
        }
        Map<String, Object> variables = toVariables(request);
        ProcessInstance instance = runtimeService.startProcessInstanceByMessage(
                ProcessConstants.MSG_DOCUMENT_REQUEST_RECEIVED, documentJobId, variables);
        meterRegistry.counter("documents.started").increment();
        log.info(
                "Prozess gestartet: documentJobId={} processInstanceId={}",
                documentJobId,
                instance.getProcessInstanceId());
        return status(documentJobId, false);
    }

    public DocumentRequestStatus status(String documentJobId) {
        return status(documentJobId, false);
    }

    private DocumentRequestStatus status(String documentJobId, boolean duplicate) {
        ProcessInstance active = runtimeService
                .createProcessInstanceQuery()
                .processInstanceBusinessKey(documentJobId)
                .singleResult();
        if (active != null) {
            List<String> activities = runtimeService.getActiveActivityIds(active.getId());
            return new DocumentRequestStatus(
                    documentJobId,
                    active.getProcessInstanceId(),
                    "ACTIVE",
                    String.join(",", activities),
                    null,
                    duplicate);
        }
        HistoricProcessInstance historic = historyService
                .createHistoricProcessInstanceQuery()
                .processInstanceBusinessKey(documentJobId)
                .singleResult();
        if (historic != null) {
            return new DocumentRequestStatus(
                    documentJobId, historic.getId(), historic.getState(), null, outcome(historic.getId()), duplicate);
        }
        return new DocumentRequestStatus(documentJobId, null, "NOT_FOUND", null, null, duplicate);
    }

    private boolean instanceExists(String documentJobId) {
        boolean active = runtimeService
                        .createProcessInstanceQuery()
                        .processInstanceBusinessKey(documentJobId)
                        .count()
                > 0;
        boolean historic = historyService
                        .createHistoricProcessInstanceQuery()
                        .processInstanceBusinessKey(documentJobId)
                        .count()
                > 0;
        return active || historic;
    }

    private String outcome(String processInstanceId) {
        HistoricVariableInstance variable = historyService
                .createHistoricVariableInstanceQuery()
                .processInstanceId(processInstanceId)
                .variableName(ProcessConstants.VAR_OUTCOME)
                .singleResult();
        return variable == null ? null : String.valueOf(variable.getValue());
    }

    private Map<String, Object> toVariables(DocumentRequest request) {
        Map<String, Object> variables = new HashMap<>();
        variables.put(ProcessConstants.VAR_DOCUMENT_JOB_ID, request.documentJobId());
        variables.put(ProcessConstants.VAR_SOURCE_EVENT_ID, request.sourceEventId());
        variables.put(
                ProcessConstants.VAR_REQUEST_SOURCE, request.requestSource().name());
        variables.put(ProcessConstants.VAR_DOCUMENT_TYPE, request.documentType().name());
        variables.put(ProcessConstants.VAR_CUSTOMER_ID, request.customerId());
        variables.put(ProcessConstants.VAR_CONTRACT_ID, request.contractId());
        variables.put(ProcessConstants.VAR_REQUESTED_AT, request.requestedAt().toString());
        variables.put(
                ProcessConstants.VAR_FAILURE_PROFILE,
                request.effectiveFailureProfile().name());
        if (request.batchId() != null) {
            variables.put(ProcessConstants.VAR_BATCH_ID, request.batchId());
        }
        return variables;
    }
}
