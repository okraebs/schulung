package de.demo.versicherung.korrespondenz.inbox;

import de.demo.versicherung.korrespondenz.contracts.DeliveryResultCallback;
import jakarta.validation.Valid;
import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Nimmt idempotente Simulator-Callbacks der technischen Annahme entgegen und speist die Inbox
 * (Auftrag 11.6). Doppelte Callbacks liefern eine idempotente erfolgreiche Antwort.
 */
@RestController
@RequestMapping("/api/delivery-results")
public class DeliveryResultController {

    private final DeliveryCallbackService service;

    public DeliveryResultController(DeliveryCallbackService service) {
        this.service = service;
    }

    @PostMapping
    public Map<String, Object> receive(@Valid @RequestBody DeliveryResultCallback callback) {
        DeliveryCallbackService.Result result = service.accept(callback);
        return Map.of(
                "documentJobId", callback.documentJobId(),
                "duplicate", result.duplicate(),
                "correlated", result.correlatedNow());
    }
}
