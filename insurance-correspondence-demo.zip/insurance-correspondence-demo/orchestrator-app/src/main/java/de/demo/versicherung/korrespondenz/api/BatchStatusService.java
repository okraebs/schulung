package de.demo.versicherung.korrespondenz.api;

import de.demo.versicherung.korrespondenz.contracts.Outcome;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.history.HistoricVariableInstance;
import org.springframework.stereotype.Service;

/** Aggregiert den Status aller document_fulfillment-Instanzen einer batchId (Auftrag 11.5). */
@Service
public class BatchStatusService {

    private static final String VAR_BATCH_ID = ProcessConstants.VAR_BATCH_ID;
    private static final String VAR_OUTCOME = ProcessConstants.VAR_OUTCOME;
    private static final String DOC = ProcessConstants.PROCESS_DOCUMENT_FULFILLMENT;

    private final RuntimeService runtimeService;
    private final HistoryService historyService;

    public BatchStatusService(RuntimeService runtimeService, HistoryService historyService) {
        this.runtimeService = runtimeService;
        this.historyService = historyService;
    }

    public BatchStatus aggregate(String batchId) {
        long started = historyService
                .createHistoricProcessInstanceQuery()
                .processDefinitionKey(DOC)
                .variableValueEquals(VAR_BATCH_ID, batchId)
                .count();
        long active = runtimeService
                .createProcessInstanceQuery()
                .processDefinitionKey(DOC)
                .variableValueEquals(VAR_BATCH_ID, batchId)
                .active()
                .count();
        long manual = runtimeService
                .createProcessInstanceQuery()
                .processDefinitionKey(DOC)
                .variableValueEquals(VAR_BATCH_ID, batchId)
                .activityIdIn("manualReview")
                .count();
        long incident = runtimeService
                .createProcessInstanceQuery()
                .processDefinitionKey(DOC)
                .variableValueEquals(VAR_BATCH_ID, batchId)
                .withIncident()
                .count();

        return new BatchStatus(
                batchId,
                plannedTotal(batchId, started),
                started,
                active,
                manual,
                incident,
                outcomeCount(batchId, Outcome.FULLY_DISPATCHED),
                outcomeCount(batchId, Outcome.DEGRADED_DISPATCHED),
                outcomeCount(batchId, Outcome.CANCELLED_AFTER_MANUAL_REVIEW));
    }

    private long outcomeCount(String batchId, Outcome outcome) {
        return historyService
                .createHistoricProcessInstanceQuery()
                .processDefinitionKey(DOC)
                .variableValueEquals(VAR_BATCH_ID, batchId)
                .variableValueEquals(VAR_OUTCOME, outcome.name())
                .count();
    }

    /** Geplante Gesamtzahl aus der Planner-Instanz (Business Key = batchId); Fallback: started. */
    private long plannedTotal(String batchId, long started) {
        HistoricVariableInstance totalCount = historyService
                .createHistoricVariableInstanceQuery()
                .processInstanceIdIn(plannerInstanceId(batchId))
                .variableName("totalCount")
                .singleResult();
        if (totalCount != null && totalCount.getValue() instanceof Number number) {
            return number.longValue();
        }
        return started;
    }

    private String plannerInstanceId(String batchId) {
        var planner = historyService
                .createHistoricProcessInstanceQuery()
                .processDefinitionKey(ProcessConstants.PROCESS_BATCH_PLANNER)
                .processInstanceBusinessKey(batchId)
                .singleResult();
        return planner == null ? "none" : planner.getId();
    }
}
