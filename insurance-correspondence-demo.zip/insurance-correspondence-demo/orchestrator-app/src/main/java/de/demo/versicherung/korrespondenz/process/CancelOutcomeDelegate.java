package de.demo.versicherung.korrespondenz.process;

import de.demo.versicherung.korrespondenz.contracts.Outcome;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import io.micrometer.core.instrument.MeterRegistry;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/**
 * Setzt das finale Outcome auf CANCELLED_AFTER_MANUAL_REVIEW (Auftrag 6.2: CANCEL_REQUEST) und zaehlt
 * es (Auftrag 17.2).
 */
@Component("cancelOutcomeDelegate")
public class CancelOutcomeDelegate implements JavaDelegate {

    private final MeterRegistry meterRegistry;

    public CancelOutcomeDelegate(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Override
    public void execute(DelegateExecution execution) {
        execution.setVariable(ProcessConstants.VAR_OUTCOME, Outcome.CANCELLED_AFTER_MANUAL_REVIEW.name());
        meterRegistry
                .counter("documents.dispatched", "outcome", Outcome.CANCELLED_AFTER_MANUAL_REVIEW.name())
                .increment();
    }
}
