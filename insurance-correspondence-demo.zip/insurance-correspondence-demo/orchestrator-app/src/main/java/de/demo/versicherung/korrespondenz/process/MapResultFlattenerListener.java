package de.demo.versicherung.korrespondenz.process;

import java.util.Map;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.camunda.bpm.engine.delegate.Expression;

/**
 * Execution Listener (Event {@code end}), der das Ergebnis einer Business Rule Task – eine in der
 * via {@code source} benannten Variable abgelegte Map (mapDecisionResult=singleResult) – in einzelne
 * Prozessvariablen aufteilt und die temporaere Quellvariable entfernt.
 *
 * <p>Bewusst klassenbasiert (kein Spring-Bean), damit Camunda die {@code camunda:field}-Injektion
 * durchfuehren kann.
 */
public class MapResultFlattenerListener implements ExecutionListener {

    private Expression source;

    @Override
    public void notify(DelegateExecution execution) {
        if (source == null) {
            return;
        }
        String variableName = String.valueOf(source.getValue(execution));
        Object value = execution.getVariable(variableName);
        if (value instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                execution.setVariable(String.valueOf(entry.getKey()), entry.getValue());
            }
        }
        execution.removeVariable(variableName);
    }

    public void setSource(Expression source) {
        this.source = source;
    }
}
