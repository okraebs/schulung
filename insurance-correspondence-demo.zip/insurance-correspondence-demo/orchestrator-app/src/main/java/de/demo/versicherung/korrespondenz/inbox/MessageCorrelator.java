package de.demo.versicherung.korrespondenz.inbox;

import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import java.time.Instant;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Korreliert einen gepufferten Callback mit der wartenden Receive Task – in einer eigenen
 * Transaktion. Schlaegt die Korrelation fehl (keine wartende Instanz, optimistisches Locking durch
 * den parallelen Job-Executor o. Ae.), wird die Transaktion sauber zurueckgerollt und der Eintrag
 * bleibt PENDING. Der Aufrufer faengt die Ausnahme ab.
 */
@Component
public class MessageCorrelator {

    private final DeliveryCallbackInboxRepository repository;
    private final RuntimeService runtimeService;

    public MessageCorrelator(DeliveryCallbackInboxRepository repository, RuntimeService runtimeService) {
        this.repository = repository;
        this.runtimeService = runtimeService;
    }

    @Transactional
    public void correlate(String entryId) {
        DeliveryCallbackInbox entry = repository
                .findById(entryId)
                .orElseThrow(() -> new IllegalStateException("Inbox-Eintrag weg: " + entryId));
        runtimeService
                .createMessageCorrelation(ProcessConstants.MSG_DELIVERY_RESULT_RECEIVED)
                .processInstanceBusinessKey(entry.getDocumentJobId())
                .setVariable(ProcessConstants.VAR_DELIVERY_RESULT_STATUS, entry.getDeliveryResultStatus())
                .setVariable(ProcessConstants.VAR_PROVIDER_REFERENCE, entry.getProviderReference())
                .correlate();
        entry.markCorrelated(Instant.now());
        repository.save(entry);
    }
}
