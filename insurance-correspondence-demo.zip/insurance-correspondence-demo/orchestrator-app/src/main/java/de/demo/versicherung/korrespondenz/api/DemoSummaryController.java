package de.demo.versicherung.korrespondenz.api;

import de.demo.versicherung.korrespondenz.contracts.Outcome;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import java.util.LinkedHashMap;
import java.util.Map;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Einfache Zusammenfassung fuer Skripte und Trainer (Auftrag 11.8). Eine eigene grafische
 * Weboberflaeche ist nicht erforderlich – Cockpit und Tasklist bleiben die primaeren UIs.
 */
@RestController
@RequestMapping("/api/demo/summary")
public class DemoSummaryController {

    private static final String DOC = ProcessConstants.PROCESS_DOCUMENT_FULFILLMENT;

    private final RuntimeService runtimeService;
    private final HistoryService historyService;

    public DemoSummaryController(RuntimeService runtimeService, HistoryService historyService) {
        this.runtimeService = runtimeService;
        this.historyService = historyService;
    }

    @GetMapping
    public Map<String, Object> summary() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put(
                "started",
                historyService
                        .createHistoricProcessInstanceQuery()
                        .processDefinitionKey(DOC)
                        .count());
        result.put(
                "active",
                runtimeService
                        .createProcessInstanceQuery()
                        .processDefinitionKey(DOC)
                        .active()
                        .count());
        result.put(
                "manual",
                runtimeService
                        .createProcessInstanceQuery()
                        .processDefinitionKey(DOC)
                        .activityIdIn("manualReview")
                        .count());
        result.put(
                "incident",
                runtimeService
                        .createProcessInstanceQuery()
                        .processDefinitionKey(DOC)
                        .withIncident()
                        .count());
        result.put("fullyDispatched", outcomeCount(Outcome.FULLY_DISPATCHED));
        result.put("degradedDispatched", outcomeCount(Outcome.DEGRADED_DISPATCHED));
        result.put("cancelled", outcomeCount(Outcome.CANCELLED_AFTER_MANUAL_REVIEW));
        return result;
    }

    private long outcomeCount(Outcome outcome) {
        return historyService
                .createHistoricProcessInstanceQuery()
                .processDefinitionKey(DOC)
                .variableValueEquals(ProcessConstants.VAR_OUTCOME, outcome.name())
                .count();
    }
}
