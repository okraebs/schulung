package de.demo.versicherung.korrespondenz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Orchestrator: eingebettete Camunda-7-Engine mit Webapps (Cockpit, Tasklist, Admin) und REST-API.
 *
 * <p>Die fachlichen BPMN-/DMN-Modelle unter {@code src/main/resources} werden durch den Camunda
 * Spring-Boot-Starter automatisch deployed. Standardport 8080, Bindung an 127.0.0.1.
 */
@SpringBootApplication
@EnableScheduling
public class OrchestratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrchestratorApplication.class, args);
    }
}
