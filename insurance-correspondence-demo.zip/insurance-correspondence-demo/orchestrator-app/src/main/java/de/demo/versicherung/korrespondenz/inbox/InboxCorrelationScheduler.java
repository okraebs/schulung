package de.demo.versicherung.korrespondenz.inbox;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Versucht periodisch, noch nicht korrelierte Inbox-Eintraege erneut zu korrelieren (Auftrag 9.4).
 * Wichtig fuer den Fall, dass ein Callback eintraf, bevor der Prozess die Receive Task erreichte,
 * oder waehrend der Orchestrator unten war.
 */
@Component
public class InboxCorrelationScheduler {

    private static final Logger log = LoggerFactory.getLogger(InboxCorrelationScheduler.class);

    private final DeliveryCallbackService service;

    public InboxCorrelationScheduler(DeliveryCallbackService service) {
        this.service = service;
    }

    @Scheduled(fixedDelayString = "${inbox.correlation-interval-ms:3000}")
    public void retryPendingCorrelations() {
        int correlated = service.correlatePending();
        if (correlated > 0) {
            log.info("Inbox-Scheduler: {} Callback(s) nachtraeglich korreliert.", correlated);
        }
    }
}
