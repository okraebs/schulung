package de.demo.versicherung.korrespondenz.process;

import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/**
 * Kurzer, lokaler, deterministischer JavaDelegate (Auftrag 4.1 / 6.1.1): normalisiert die Anfrage
 * und setzt Basisvariablen. Fuehrt keine langsamen I/O-Aufrufe aus.
 */
@Component("normalizeRequestDelegate")
public class NormalizeRequestDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        if (execution.getVariable(ProcessConstants.VAR_STATUS_CHECK_COUNT) == null) {
            execution.setVariable(ProcessConstants.VAR_STATUS_CHECK_COUNT, 0);
        }
        if (execution.getVariable(ProcessConstants.VAR_DEGRADED) == null) {
            execution.setVariable(ProcessConstants.VAR_DEGRADED, false);
        }
    }
}
