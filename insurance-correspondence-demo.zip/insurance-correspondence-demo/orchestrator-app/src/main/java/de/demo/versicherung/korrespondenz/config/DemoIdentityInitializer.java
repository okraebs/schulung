package de.demo.versicherung.korrespondenz.config;

import jakarta.annotation.PostConstruct;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.identity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * Legt im Demo-/Test-Profil idempotent die Demo-Benutzer und -Gruppen an (Auftrag 6.2 / 16.1).
 *
 * <ul>
 *   <li>Benutzer {@code demo}/{@code demo} (administrativ) wird vom Camunda-Starter via
 *       {@code camunda.bpm.admin-user} erzeugt.
 *   <li>Gruppe {@code document-ops} sowie Benutzer {@code ops}/{@code ops} und dessen Mitgliedschaft
 *       werden hier angelegt.
 * </ul>
 *
 * <p>WARNUNG: Diese Zugangsdaten sind reine Demo-Werte und NICHT produktionsgeeignet (Auftrag 2.9).
 * Deshalb ist diese Initialisierung auf die Profile {@code demo} und {@code test} beschraenkt.
 */
@Component
@Profile({"demo", "test"})
public class DemoIdentityInitializer {

    private static final Logger log = LoggerFactory.getLogger(DemoIdentityInitializer.class);

    private static final String OPS_GROUP_ID = "document-ops";
    private static final String OPS_GROUP_NAME = "Document Operations";
    private static final String OPS_USER_ID = "ops";
    private static final String OPS_USER_PASSWORD = "ops";

    private final ProcessEngine processEngine;

    public DemoIdentityInitializer(ProcessEngine processEngine) {
        this.processEngine = processEngine;
    }

    @PostConstruct
    public void initialize() {
        IdentityService identity = processEngine.getIdentityService();
        ensureGroup(identity, OPS_GROUP_ID, OPS_GROUP_NAME);
        ensureUser(identity, OPS_USER_ID, OPS_USER_PASSWORD, "Olivia", "Operatorin");
        ensureMembership(identity, OPS_USER_ID, OPS_GROUP_ID);
        log.info("Demo-Identitaeten sichergestellt: Benutzer 'ops' in Gruppe 'document-ops' (Demo-Zugangsdaten!).");
    }

    private void ensureGroup(IdentityService identity, String groupId, String name) {
        if (identity.createGroupQuery().groupId(groupId).count() > 0) {
            return;
        }
        Group group = identity.newGroup(groupId);
        group.setName(name);
        group.setType("WORKFLOW");
        identity.saveGroup(group);
    }

    private void ensureUser(
            IdentityService identity, String userId, String password, String firstName, String lastName) {
        if (identity.createUserQuery().userId(userId).count() > 0) {
            return;
        }
        User user = identity.newUser(userId);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setPassword(password);
        identity.saveUser(user);
    }

    private void ensureMembership(IdentityService identity, String userId, String groupId) {
        boolean alreadyMember =
                identity.createUserQuery().userId(userId).memberOfGroup(groupId).count() > 0;
        if (alreadyMember) {
            return;
        }
        identity.createMembership(userId, groupId);
    }
}
