package de.demo.versicherung.korrespondenz.process;

import de.demo.versicherung.korrespondenz.contracts.Outcome;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import io.micrometer.core.instrument.MeterRegistry;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/**
 * Kurzer, idempotenter Abschlussservice (Auftrag 6.1.12 / 4.1): setzt das finale {@code outcome}
 * abhaengig von {@code degraded} und zaehlt es (Auftrag 17.2). Bei {@code degraded=false}
 * FULLY_DISPATCHED, sonst DEGRADED_DISPATCHED.
 */
@Component("finalizeOutcomeDelegate")
public class FinalizeOutcomeDelegate implements JavaDelegate {

    private final MeterRegistry meterRegistry;

    public FinalizeOutcomeDelegate(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Override
    public void execute(DelegateExecution execution) {
        boolean degraded = Boolean.TRUE.equals(execution.getVariable(ProcessConstants.VAR_DEGRADED));
        Outcome outcome = degraded ? Outcome.DEGRADED_DISPATCHED : Outcome.FULLY_DISPATCHED;
        execution.setVariable(ProcessConstants.VAR_OUTCOME, outcome.name());
        meterRegistry.counter("documents.dispatched", "outcome", outcome.name()).increment();
    }
}
