package de.demo.versicherung.korrespondenz.inbox;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeliveryCallbackInboxRepository extends JpaRepository<DeliveryCallbackInbox, String> {

    boolean existsByCallbackEventId(String callbackEventId);

    List<DeliveryCallbackInbox> findByStatus(DeliveryCallbackInbox.Status status);
}
