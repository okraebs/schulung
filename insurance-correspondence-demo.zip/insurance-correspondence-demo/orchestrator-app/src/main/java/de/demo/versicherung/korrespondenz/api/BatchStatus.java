package de.demo.versicherung.korrespondenz.api;

/**
 * Aggregierter Batch-Status (Auftrag 11.5). Grundlage fuer die Konsistenzbilanz: Summe der finalen
 * Outcomes plus weiterhin aktive, erklaerbare Zustaende muss der Zahl gestarteter Auftraege
 * entsprechen (Auftrag 15.5).
 */
public record BatchStatus(
        String batchId,
        long planned,
        long started,
        long active,
        long manual,
        long incident,
        long fullyDispatched,
        long degradedDispatched,
        long cancelled) {}
