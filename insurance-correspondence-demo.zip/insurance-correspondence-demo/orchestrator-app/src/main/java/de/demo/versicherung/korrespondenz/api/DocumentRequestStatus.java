package de.demo.versicherung.korrespondenz.api;

/**
 * Fachlicher Status eines Dokumentauftrags (Auftrag 11.4). Enthaelt keine sensiblen Daten.
 *
 * @param documentJobId fachlicher Schluessel
 * @param processInstanceId aktive Prozessinstanz-ID (null, wenn bereits abgeschlossen)
 * @param status ACTIVE, COMPLETED, NOT_FOUND oder ein historischer Zustand
 * @param activeActivity aktiver Wait State (Aktivitaets-ID), falls vorhanden
 * @param outcome finales Ergebnis, falls vorhanden
 * @param duplicate true, wenn ein POST keinen neuen Prozess gestartet hat (Idempotenz)
 */
public record DocumentRequestStatus(
        String documentJobId,
        String processInstanceId,
        String status,
        String activeActivity,
        String outcome,
        boolean duplicate) {}
