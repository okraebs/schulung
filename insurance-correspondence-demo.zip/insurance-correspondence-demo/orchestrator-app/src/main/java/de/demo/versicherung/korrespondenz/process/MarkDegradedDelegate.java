package de.demo.versicherung.korrespondenz.process;

import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/**
 * Markiert den Auftrag als reduziert auszuliefern (Auftrag 6.2: DELIVER_REDUCED). Setzt
 * {@code degraded=true} und ergaenzt einen Degradationsgrund aus der manuellen Klaerung.
 */
@Component("markDegradedDelegate")
public class MarkDegradedDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        execution.setVariable(ProcessConstants.VAR_DEGRADED, true);
        Object existing = execution.getVariable(ProcessConstants.VAR_DEGRADATION_REASONS);
        String reason = "manuelleFreigabeReduziert";
        String reasons = (existing == null || String.valueOf(existing).isBlank()) ? reason : existing + ", " + reason;
        execution.setVariable(ProcessConstants.VAR_DEGRADATION_REASONS, reasons);
    }
}
