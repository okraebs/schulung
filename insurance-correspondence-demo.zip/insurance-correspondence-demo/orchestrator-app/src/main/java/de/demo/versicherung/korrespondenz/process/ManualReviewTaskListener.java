package de.demo.versicherung.korrespondenz.process;

import de.demo.versicherung.korrespondenz.contracts.ManualResolution;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import org.camunda.bpm.engine.ProcessEngineException;
import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;

/**
 * Task-Listener der User Task „Dokumentauftrag manuell klären" (Auftrag 6.2).
 *
 * <ul>
 *   <li>create: setzt {@code manualReason}, falls noch nicht vorhanden.
 *   <li>complete: validiert {@code manualResolution}. DELIVER_REDUCED ist nur zulaessig, wenn die
 *       Degradation erlaubt ist ({@code degradationAllowed=true}).
 * </ul>
 *
 * <p>Bewusst klassenbasiert; eine ungueltige Auswahl fuehrt zu einem Rollback der Task-Completion,
 * die Aufgabe bleibt offen.
 */
public class ManualReviewTaskListener implements TaskListener {

    @Override
    public void notify(DelegateTask delegateTask) {
        if (EVENTNAME_CREATE.equals(delegateTask.getEventName())) {
            onCreate(delegateTask);
        } else if (EVENTNAME_COMPLETE.equals(delegateTask.getEventName())) {
            onComplete(delegateTask);
        }
    }

    private void onCreate(DelegateTask task) {
        if (task.getVariable(ProcessConstants.VAR_MANUAL_REASON) == null) {
            Object missing = task.getVariable(ProcessConstants.VAR_MISSING_REQUIRED_FIELDS);
            boolean hasMissing = missing != null && !String.valueOf(missing).isBlank();
            task.setVariable(
                    ProcessConstants.VAR_MANUAL_REASON, hasMissing ? "MISSING_MANDATORY_DATA" : "DELIVERY_ISSUE");
        }
    }

    private void onComplete(DelegateTask task) {
        Object raw = task.getVariable(ProcessConstants.VAR_MANUAL_RESOLUTION);
        ManualResolution resolution;
        try {
            resolution = ManualResolution.valueOf(String.valueOf(raw));
        } catch (IllegalArgumentException e) {
            throw new ProcessEngineException("Ungueltige manualResolution: " + raw);
        }
        if (resolution == ManualResolution.DELIVER_REDUCED
                && !Boolean.TRUE.equals(task.getVariable(ProcessConstants.VAR_DEGRADATION_ALLOWED))) {
            throw new ProcessEngineException(
                    "DELIVER_REDUCED ist nur bei erlaubter Degradation zulaessig (degradationAllowed=false).");
        }
    }
}
