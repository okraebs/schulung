-- Inbox fuer idempotente DeliveryResultReceived-Callbacks (Auftrag 9.4 / 10.6).
-- callback_event_id traegt einen Unique Constraint und ist der Dedup-Schluessel.
CREATE TABLE delivery_callback_inbox (
    id                     VARCHAR(36)  NOT NULL,
    callback_event_id      VARCHAR(100) NOT NULL,
    document_job_id        VARCHAR(100) NOT NULL,
    delivery_request_id    VARCHAR(100),
    delivery_result_status VARCHAR(30)  NOT NULL,
    provider_reference     VARCHAR(100),
    status                 VARCHAR(20)  NOT NULL,
    created_at             TIMESTAMP    NOT NULL,
    correlated_at          TIMESTAMP,
    CONSTRAINT pk_delivery_callback_inbox PRIMARY KEY (id),
    CONSTRAINT uq_delivery_callback_event UNIQUE (callback_event_id)
);

CREATE INDEX idx_inbox_status ON delivery_callback_inbox (status);
CREATE INDEX idx_inbox_document_job ON delivery_callback_inbox (document_job_id);
