package de.demo.versicherung.korrespondenz.worker.render;

import static org.assertj.core.api.Assertions.assertThat;

import de.demo.versicherung.korrespondenz.worker.WorkerProperties;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PdfRenderAndStoreTest {

    private final PdfRenderer renderer = new PdfRenderer();

    private RenderModel sample(boolean degraded) {
        return new RenderModel(
                "DOC-T1",
                "CONTRACT_CHANGE_CONFIRMATION",
                "de",
                "CONTRACT_CHANGE_CONFIRMATION",
                "default",
                "Kundin Test",
                "VN-12345",
                "2026-07-01",
                "KFZ",
                "KFZ-Tarif 2026",
                "100,00",
                "108,50",
                degraded ? null : "Betreuer BY",
                degraded,
                degraded ? List.of("Marketingbeilage fehlt") : List.of());
    }

    @Test
    void rendersRealPdfBytes() {
        byte[] pdf = renderer.render(sample(false));
        assertThat(pdf).isNotEmpty();
        assertThat(new String(pdf, 0, 5)).startsWith("%PDF-");
    }

    @Test
    void storesPdfWithHashAndMetadata(@TempDir Path tempDir) {
        var properties = new WorkerProperties(
                "http://127.0.0.1:8082",
                "http://127.0.0.1:8080",
                tempDir.toString(),
                WorkerProperties.RenderMode.REAL_PDF);
        var store = new DocumentStore(properties);

        byte[] pdf = renderer.render(sample(true));
        DocumentArtifact artifact = store.store("DOC-T1", pdf);

        assertThat(artifact.documentContentType()).isEqualTo("application/pdf");
        assertThat(artifact.documentSize()).isEqualTo(pdf.length);
        assertThat(artifact.documentSha256()).hasSize(64);
        Path expected = tempDir.resolve("DOC-T1").resolve("document.pdf");
        assertThat(Files.exists(expected)).isTrue();
        assertThat(artifact.documentUri()).startsWith("file:");
    }

    @Test
    void rejectsPathTraversalInDocumentJobId(@TempDir Path tempDir) {
        var properties = new WorkerProperties(
                "http://127.0.0.1:8082",
                "http://127.0.0.1:8080",
                tempDir.toString(),
                WorkerProperties.RenderMode.REAL_PDF);
        var store = new DocumentStore(properties);

        // Pfadtrenner werden saniert; das Artefakt bleibt unter baseDir.
        DocumentArtifact artifact = store.store("../../evil", new byte[] {1, 2, 3});
        Path baseDir = store.baseDir();
        Path resolved = Path.of(java.net.URI.create(artifact.documentUri())).normalize();
        assertThat(resolved.startsWith(baseDir)).as("kein Pfadausbruch").isTrue();
    }
}
