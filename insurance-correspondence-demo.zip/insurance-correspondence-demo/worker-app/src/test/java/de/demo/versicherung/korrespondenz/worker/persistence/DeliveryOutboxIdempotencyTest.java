package de.demo.versicherung.korrespondenz.worker.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import de.demo.versicherung.korrespondenz.worker.render.DocumentArtifact;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Phase-6-Gate (Auftrag 9.5/9.6, 23.7): Idempotenz der Worker-Persistenz.
 *
 * <p>Simuliert das Szenario eines verlorenen External-Task-Complete-Response: derselbe Dispatch wird
 * zweimal verarbeitet und darf nur einen Delivery Request und einen Outbox-Eintrag erzeugen. Ebenso
 * wird ein Render-Artefakt nur einmal angelegt.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("test")
class DeliveryOutboxIdempotencyTest {

    @Autowired
    DeliveryOutboxService deliveryOutboxService;

    @Autowired
    ArtifactService artifactService;

    @Autowired
    DeliveryRequestRepository deliveryRequestRepository;

    @Autowired
    OutboxEventRepository outboxEventRepository;

    @Autowired
    DocumentArtifactRepository documentArtifactRepository;

    @Test
    void repeatedDispatchCreatesExactlyOneRequestAndOutbox() {
        var command = new DeliveryOutboxService.Command(
                "DOC-OB-1", "EMAIL", "ob1@example.test", "file:///x.pdf", "abc", "NORMAL", "HAPPY");

        var first = deliveryOutboxService.createOrGet(command);
        var second = deliveryOutboxService.createOrGet(command);

        assertThat(second.getDeliveryRequestId()).isEqualTo(first.getDeliveryRequestId());
        assertThat(deliveryRequestRepository.count()).isEqualTo(1);
        assertThat(outboxEventRepository.count()).as("genau ein Outbox-Eintrag").isEqualTo(1);
    }

    @Test
    void repeatedRenderStoresArtifactOnlyOnce() {
        var artifact = new DocumentArtifact("file:///doc.pdf", "h".repeat(64), 1234L, "application/pdf");

        artifactService.store("DOC-ART-1", artifact);
        artifactService.store(
                "DOC-ART-1", new DocumentArtifact("file:///other.pdf", "z".repeat(64), 999L, "application/pdf"));

        assertThat(documentArtifactRepository.count()).isEqualTo(1);
        var stored = artifactService.find("DOC-ART-1").orElseThrow();
        // Das zuerst gespeicherte Artefakt bleibt massgeblich (Idempotenz)
        assertThat(stored.getDocumentUri()).isEqualTo("file:///doc.pdf");
    }
}
