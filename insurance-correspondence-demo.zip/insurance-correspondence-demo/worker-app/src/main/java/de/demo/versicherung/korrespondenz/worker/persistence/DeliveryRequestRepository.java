package de.demo.versicherung.korrespondenz.worker.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeliveryRequestRepository extends JpaRepository<DeliveryRequestEntity, String> {

    Optional<DeliveryRequestEntity> findByDocumentJobId(String documentJobId);
}
