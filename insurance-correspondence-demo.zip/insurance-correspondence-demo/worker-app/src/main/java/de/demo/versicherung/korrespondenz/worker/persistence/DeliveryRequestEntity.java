package de.demo.versicherung.korrespondenz.worker.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

/**
 * Persistierter Delivery Request (Auftrag 9.5 / 10.6). document_job_id ist eindeutig: ein
 * wiederholter Dispatch erzeugt keinen zweiten Request.
 */
@Entity
@Table(name = "delivery_request")
public class DeliveryRequestEntity {

    public enum Status {
        CREATED,
        SENT
    }

    @Id
    @Column(name = "delivery_request_id", length = 100)
    private String deliveryRequestId;

    @Column(name = "document_job_id", nullable = false, unique = true, length = 100)
    private String documentJobId;

    @Column(name = "delivery_channel", nullable = false, length = 30)
    private String deliveryChannel;

    @Column(name = "recipient", length = 300)
    private String recipient;

    @Column(name = "document_uri", length = 500)
    private String documentUri;

    @Column(name = "document_sha256", length = 64)
    private String documentSha256;

    @Column(name = "priority", length = 20)
    private String priority;

    @Column(name = "failure_profile", length = 40)
    private String failureProfile;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private Status status;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    protected DeliveryRequestEntity() {}

    public DeliveryRequestEntity(
            String deliveryRequestId,
            String documentJobId,
            String deliveryChannel,
            String recipient,
            String documentUri,
            String documentSha256,
            String priority,
            String failureProfile,
            Instant createdAt) {
        this.deliveryRequestId = deliveryRequestId;
        this.documentJobId = documentJobId;
        this.deliveryChannel = deliveryChannel;
        this.recipient = recipient;
        this.documentUri = documentUri;
        this.documentSha256 = documentSha256;
        this.priority = priority;
        this.failureProfile = failureProfile;
        this.status = Status.CREATED;
        this.createdAt = createdAt;
    }

    public void markSent() {
        this.status = Status.SENT;
    }

    public String getDeliveryRequestId() {
        return deliveryRequestId;
    }

    public String getDocumentJobId() {
        return documentJobId;
    }

    public String getDeliveryChannel() {
        return deliveryChannel;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getDocumentUri() {
        return documentUri;
    }

    public String getDocumentSha256() {
        return documentSha256;
    }

    public String getPriority() {
        return priority;
    }

    public String getFailureProfile() {
        return failureProfile;
    }

    public Status getStatus() {
        return status;
    }
}
