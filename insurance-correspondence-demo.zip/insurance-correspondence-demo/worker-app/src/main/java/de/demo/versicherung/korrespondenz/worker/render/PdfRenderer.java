package de.demo.versicherung.korrespondenz.worker.render;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.io.ByteArrayOutputStream;
import org.springframework.stereotype.Component;

/**
 * Erzeugt ein echtes, kleines PDF aus einem {@link RenderModel} mittels OpenPDF (Auftrag 13.1/13.2).
 * Sichtbar unterschiedlich nach Dokumentart, Sprache und Degradationshinweis.
 */
@Component
public class PdfRenderer {

    private static final Font TITLE = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16, Color.BLACK);
    private static final Font HEADING = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, Color.BLACK);
    private static final Font BODY = FontFactory.getFont(FontFactory.HELVETICA, 11, Color.BLACK);
    private static final Font NOTICE = FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 10, new Color(160, 80, 0));

    public byte[] render(RenderModel model) {
        boolean english = "en".equalsIgnoreCase(model.language());
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            PdfWriter.getInstance(document, out);
            document.open();
            document.add(new Paragraph(title(model.documentType(), english), TITLE));
            document.add(new Paragraph(" "));
            document.add(new Paragraph(english ? "Customer" : "Kundin/Kunde", HEADING));
            document.add(new Paragraph(nullToDash(model.customerName()), BODY));
            document.add(new Paragraph(" "));
            document.add(new Paragraph(english ? "Contract" : "Vertrag", HEADING));
            document.add(new Paragraph(
                    (english ? "Number: " : "Vertragsnummer: ") + nullToDash(model.contractNumber()), BODY));
            document.add(new Paragraph(
                    (english ? "Effective date: " : "Wirksam ab: ") + nullToDash(model.effectiveDate()), BODY));
            document.add(new Paragraph((english ? "Product: " : "Produkt: ") + nullToDash(model.product()), BODY));
            document.add(new Paragraph(" "));
            if (model.premiumNew() != null) {
                document.add(new Paragraph(english ? "Premium" : "Beitrag", HEADING));
                document.add(new Paragraph(
                        (english ? "Previous: " : "Bisher: ") + nullToDash(model.premiumOld()) + " EUR", BODY));
                document.add(
                        new Paragraph((english ? "New: " : "Neu: ") + nullToDash(model.premiumNew()) + " EUR", BODY));
                document.add(new Paragraph(" "));
            }
            if (model.advisorName() != null) {
                document.add(
                        new Paragraph((english ? "Your advisor: " : "Ihr Betreuer: ") + model.advisorName(), BODY));
            }
            document.add(new Paragraph(" "));
            document.add(new Paragraph(legalText(model.legalTextKey(), english), BODY));
            if (model.degraded()) {
                document.add(new Paragraph(" "));
                Paragraph notice = new Paragraph(degradationNotice(model, english), NOTICE);
                notice.setAlignment(Element.ALIGN_LEFT);
                document.add(notice);
            }
            document.add(new Paragraph(" "));
            document.add(new Paragraph("documentJobId: " + model.documentJobId(), NOTICE));
            document.close();
        } catch (DocumentException e) {
            throw new IllegalStateException("PDF-Erzeugung fehlgeschlagen fuer " + model.documentJobId(), e);
        }
        return out.toByteArray();
    }

    private static String title(String documentType, boolean english) {
        if ("PREMIUM_ADJUSTMENT".equals(documentType)) {
            return english ? "Premium adjustment notice" : "Mitteilung ueber Beitragsanpassung";
        }
        return english ? "Contract change confirmation" : "Bestaetigung Ihrer Vertragsaenderung";
    }

    private static String legalText(String legalTextKey, boolean english) {
        if (english) {
            return "This is a synthetic demo document. No real personal data is used.";
        }
        return "Dies ist ein synthetisches Demodokument. Es werden keine echten personenbezogenen Daten verwendet.";
    }

    private static String degradationNotice(RenderModel model, boolean english) {
        String reasons = model.degradationReasons() == null ? "" : String.join(", ", model.degradationReasons());
        return (english
                        ? "Note: reduced document, optional content omitted ("
                        : "Hinweis: reduziertes Dokument, optionale Inhalte entfallen (")
                + reasons + ").";
    }

    private static String nullToDash(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}
