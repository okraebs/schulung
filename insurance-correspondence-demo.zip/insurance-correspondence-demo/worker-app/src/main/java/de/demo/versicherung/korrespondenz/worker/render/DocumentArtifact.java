package de.demo.versicherung.korrespondenz.worker.render;

/**
 * Referenz auf ein gespeichertes Dokument. Nur diese kleinen Werte gelangen in Prozessvariablen
 * (Auftrag 4.4) – niemals der PDF-Inhalt selbst.
 *
 * @param documentUri Datei-URI des gespeicherten Dokuments
 * @param documentSha256 SHA-256-Hash (hex)
 * @param documentSize Groesse in Bytes
 * @param documentContentType MIME-Typ
 */
public record DocumentArtifact(
        String documentUri, String documentSha256, long documentSize, String documentContentType) {}
