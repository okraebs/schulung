package de.demo.versicherung.korrespondenz.worker.batch;

import de.demo.versicherung.korrespondenz.contracts.DocumentRequest;
import de.demo.versicherung.korrespondenz.contracts.DocumentType;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.contracts.RequestSource;
import de.demo.versicherung.korrespondenz.worker.client.OrchestratorClient;
import java.time.Instant;
import java.util.Map;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Handler {@code publish-batch-page} (Auftrag 8.8 / 6.3): veroeffentlicht genau eine begrenzte Seite
 * unabhaengiger Auftraege ueber den idempotenten Startservice des Orchestrators. Wiederholtes
 * Ausfuehren mit derselben batchId behandelt dieselbe Seite idempotent (deterministische
 * documentJobIds), erzeugt also keine doppelten Instanzen.
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_PUBLISH_BATCH_PAGE)
public class PublishBatchPageHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(PublishBatchPageHandler.class);

    private final OrchestratorClient orchestratorClient;

    public PublishBatchPageHandler(OrchestratorClient orchestratorClient) {
        this.orchestratorClient = orchestratorClient;
    }

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        String batchId = requiredString(externalTask, ProcessConstants.VAR_BATCH_ID);
        int totalCount = intVar(externalTask, "totalCount", 0);
        int pageSize = intVar(externalTask, "pageSize", 25);
        int offset = intVar(externalTask, "publishedCount", 0);
        FailureProfile profile = failureProfile(externalTask);

        int end = Math.min(offset + pageSize, totalCount);
        int started = 0;
        for (int i = offset; i < end; i++) {
            DocumentRequest request = new DocumentRequest(
                    batchId + "-" + i,
                    batchId + "-evt-" + i,
                    RequestSource.BATCH,
                    DocumentType.PREMIUM_ADJUSTMENT,
                    "C-" + batchId + "-" + (i % 1000),
                    "V-" + batchId + "-" + i,
                    Instant.now(),
                    batchId,
                    profile);
            if (orchestratorClient.submit(request)) {
                started++;
            }
        }

        externalTaskService.complete(externalTask, Map.of("publishedCount", end));
        log.info("publish-batch-page batchId={} Seite [{},{}) neu gestartet={}", batchId, offset, end, started);
    }

    private int intVar(ExternalTask task, String name, int fallback) {
        Object value = task.getVariable(name);
        return value instanceof Number number ? number.intValue() : fallback;
    }

    private static String requiredString(ExternalTask task, String name) {
        String value = task.getVariable(name);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Fehlende Prozessvariable: " + name);
        }
        return value;
    }

    private FailureProfile failureProfile(ExternalTask task) {
        String raw = task.getVariable(ProcessConstants.VAR_FAILURE_PROFILE);
        if (raw == null || raw.isBlank()) {
            return FailureProfile.HAPPY;
        }
        return FailureProfile.valueOf(raw);
    }
}
