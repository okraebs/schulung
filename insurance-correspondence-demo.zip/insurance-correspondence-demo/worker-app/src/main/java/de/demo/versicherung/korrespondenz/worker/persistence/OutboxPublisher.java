package de.demo.versicherung.korrespondenz.worker.persistence;

import de.demo.versicherung.korrespondenz.contracts.DeliveryChannel;
import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchRequest;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.worker.client.SimulatorClient;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Sendet offene Outbox-Eintraege an das Output-Management des Simulators und markiert sie nach
 * bestaetigter Annahme als SENT (Auftrag 9.5). HTTP-Aufrufe laufen ausserhalb der DB-Transaktion;
 * das Markieren als SENT erfolgt in einer eigenen Transaktion. Der Simulator dedupliziert
 * wiederholte Requests, daher ist ein erneutes Senden unschaedlich (Auftrag 9.6).
 */
@Component
@ConditionalOnProperty(name = "outbox.publisher-enabled", havingValue = "true", matchIfMissing = true)
public class OutboxPublisher {

    private static final Logger log = LoggerFactory.getLogger(OutboxPublisher.class);

    private final DeliveryOutboxService outboxService;
    private final SimulatorClient simulatorClient;
    private final MeterRegistry meterRegistry;

    public OutboxPublisher(
            DeliveryOutboxService outboxService, SimulatorClient simulatorClient, MeterRegistry meterRegistry) {
        this.outboxService = outboxService;
        this.simulatorClient = simulatorClient;
        this.meterRegistry = meterRegistry;
    }

    @Scheduled(fixedDelayString = "${outbox.publish-interval-ms:2000}")
    public void publishPending() {
        for (OutboxEventEntity event : outboxService.pendingNew()) {
            DeliveryRequestEntity request;
            try {
                request = outboxService.requireRequest(event.getDeliveryRequestId());
            } catch (RuntimeException e) {
                continue;
            }
            outboxService.recordAttempt(event.getId());
            meterRegistry.counter("worker.outbox.attempts").increment();
            try {
                simulatorClient.dispatch(toDispatchRequest(request));
                outboxService.markSent(event.getId());
                log.info(
                        "Outbox gesendet: documentJobId={} deliveryRequestId={}",
                        request.getDocumentJobId(),
                        request.getDeliveryRequestId());
            } catch (RuntimeException e) {
                log.warn(
                        "Outbox-Versand fehlgeschlagen (documentJobId={}), bleibt NEW: {}",
                        request.getDocumentJobId(),
                        e.getMessage());
            }
        }
    }

    private DeliveryDispatchRequest toDispatchRequest(DeliveryRequestEntity request) {
        return new DeliveryDispatchRequest(
                request.getDocumentJobId(),
                parseChannel(request.getDeliveryChannel()),
                request.getRecipient(),
                request.getDocumentUri(),
                request.getDocumentSha256(),
                request.getPriority(),
                parseProfile(request.getFailureProfile()));
    }

    private DeliveryChannel parseChannel(String value) {
        try {
            return DeliveryChannel.valueOf(value);
        } catch (IllegalArgumentException | NullPointerException e) {
            return DeliveryChannel.EMAIL;
        }
    }

    private FailureProfile parseProfile(String value) {
        try {
            return FailureProfile.valueOf(value);
        } catch (IllegalArgumentException | NullPointerException e) {
            return FailureProfile.HAPPY;
        }
    }
}
