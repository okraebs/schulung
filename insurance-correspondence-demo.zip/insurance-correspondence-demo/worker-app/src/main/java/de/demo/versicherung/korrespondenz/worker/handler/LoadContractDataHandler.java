package de.demo.versicherung.korrespondenz.worker.handler;

import de.demo.versicherung.korrespondenz.contracts.ContractData;
import de.demo.versicherung.korrespondenz.contracts.DataStatus;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.worker.client.SimulatorClient;
import java.util.HashMap;
import java.util.Map;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Handler {@code load-contract-data} (Auftrag 8.2): laedt Vertragsdaten, setzt
 * {@code contractDataStatus} und das {@code product} (Eingabe fuer load-tariff-data und DMN).
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_LOAD_CONTRACT)
public class LoadContractDataHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(LoadContractDataHandler.class);

    private final SimulatorClient simulatorClient;

    public LoadContractDataHandler(SimulatorClient simulatorClient) {
        this.simulatorClient = simulatorClient;
    }

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        String contractId = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_CONTRACT_ID);
        FailureProfile profile = HandlerSupport.failureProfile(externalTask);

        ContractData contract = simulatorClient.loadContract(contractId, profile);
        DataStatus status = deriveStatus(contract);

        Map<String, Object> variables = new HashMap<>();
        variables.put(ProcessConstants.VAR_CONTRACT_DATA_STATUS, status.name());
        variables.put("product", contract.product() != null ? contract.product() : "UNKNOWN");

        externalTaskService.complete(externalTask, variables);
        log.info(
                "load-contract-data documentJobId={} status={} product={}",
                externalTask.getVariable(ProcessConstants.VAR_DOCUMENT_JOB_ID),
                status,
                contract.product());
    }

    private DataStatus deriveStatus(ContractData c) {
        boolean mandatoryPresent =
                isNotBlank(c.contractNumber()) && isNotBlank(c.product()) && isNotBlank(c.effectiveDate());
        return mandatoryPresent ? DataStatus.OK : DataStatus.MANDATORY_MISSING;
    }

    private static boolean isNotBlank(String s) {
        return s != null && !s.isBlank();
    }
}
