package de.demo.versicherung.korrespondenz.worker.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentArtifactRepository extends JpaRepository<DocumentArtifactEntity, String> {}
