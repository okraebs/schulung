package de.demo.versicherung.korrespondenz.worker.persistence;

import de.demo.versicherung.korrespondenz.worker.render.DocumentArtifact;
import java.time.Instant;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Idempotente Persistenz der Dokumentreferenz (Auftrag 8.4: vorhandenes Artefakt wiederverwenden). */
@Service
public class ArtifactService {

    private final DocumentArtifactRepository repository;

    public ArtifactService(DocumentArtifactRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public Optional<DocumentArtifactEntity> find(String documentJobId) {
        return repository.findById(documentJobId);
    }

    @Transactional
    public DocumentArtifactEntity store(String documentJobId, DocumentArtifact artifact) {
        return repository
                .findById(documentJobId)
                .orElseGet(() -> repository.save(new DocumentArtifactEntity(
                        documentJobId,
                        artifact.documentUri(),
                        artifact.documentSha256(),
                        artifact.documentSize(),
                        artifact.documentContentType(),
                        Instant.now())));
    }
}
