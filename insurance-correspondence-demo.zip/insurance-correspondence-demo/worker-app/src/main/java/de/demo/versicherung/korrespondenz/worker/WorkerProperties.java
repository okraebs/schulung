package de.demo.versicherung.korrespondenz.worker;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Worker-Konfiguration (Praefix {@code worker}).
 *
 * @param simulatorBaseUrl Basis-URL des Simulators
 * @param orchestratorBaseUrl Basis-URL des Orchestrators (Batch-Veroeffentlichung via Demo-REST)
 * @param documentBaseDir Verzeichnis fuer gerenderte PDFs
 * @param renderMode {@code REAL_PDF} (Demo/Smoke) oder {@code METADATA_ONLY} (Last)
 */
@ConfigurationProperties(prefix = "worker")
public record WorkerProperties(
        String simulatorBaseUrl, String orchestratorBaseUrl, String documentBaseDir, RenderMode renderMode) {

    public enum RenderMode {
        REAL_PDF,
        METADATA_ONLY
    }
}
