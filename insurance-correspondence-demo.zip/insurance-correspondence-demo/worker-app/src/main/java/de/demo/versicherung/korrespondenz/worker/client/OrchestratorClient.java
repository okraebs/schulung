package de.demo.versicherung.korrespondenz.worker.client;

import de.demo.versicherung.korrespondenz.contracts.DocumentRequest;
import de.demo.versicherung.korrespondenz.worker.WorkerProperties;
import java.time.Duration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * HTTP-Client zum Orchestrator. Der Batch-Planer veroeffentlicht Auftraege ueber die idempotente
 * Demo-REST-API {@code POST /api/document-requests} (Auftrag 6.3 / 11.1), damit ein wiederholter
 * Lauf keine doppelten Instanzen erzeugt. Endliche Timeouts (Auftrag 21.4).
 */
@Component
public class OrchestratorClient {

    private final RestClient restClient;

    public OrchestratorClient(WorkerProperties properties) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Duration.ofSeconds(3));
        factory.setReadTimeout(Duration.ofSeconds(10));
        this.restClient = RestClient.builder()
                .baseUrl(properties.orchestratorBaseUrl())
                .requestFactory(factory)
                .build();
    }

    /** Reicht einen Dokumentauftrag idempotent ein. Liefert true, wenn neu gestartet (kein Duplikat). */
    public boolean submit(DocumentRequest request) {
        var response = restClient
                .post()
                .uri("/api/document-requests")
                .body(request)
                .retrieve()
                .toBodilessEntity();
        // 201 Created = neu gestartet, 200 OK = Dublette (idempotent)
        return response.getStatusCode().value() == 201;
    }
}
