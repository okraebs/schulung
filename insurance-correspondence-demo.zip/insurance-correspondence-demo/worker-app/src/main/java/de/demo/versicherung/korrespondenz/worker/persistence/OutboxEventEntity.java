package de.demo.versicherung.korrespondenz.worker.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

/**
 * Outbox-Eintrag (Auftrag 9.5): entsteht in derselben lokalen Transaktion wie der Delivery Request.
 * Ein Publisher sendet NEW-Eintraege an den Simulator und markiert sie nach Annahme als SENT.
 */
@Entity
@Table(name = "outbox_event")
public class OutboxEventEntity {

    public enum Status {
        NEW,
        SENT
    }

    @Id
    @Column(name = "id", length = 36)
    private String id;

    @Column(name = "delivery_request_id", nullable = false, unique = true, length = 100)
    private String deliveryRequestId;

    @Column(name = "document_job_id", nullable = false, length = 100)
    private String documentJobId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private Status status;

    @Column(name = "attempts", nullable = false)
    private int attempts;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "sent_at")
    private Instant sentAt;

    protected OutboxEventEntity() {}

    public OutboxEventEntity(String id, String deliveryRequestId, String documentJobId, Instant createdAt) {
        this.id = id;
        this.deliveryRequestId = deliveryRequestId;
        this.documentJobId = documentJobId;
        this.status = Status.NEW;
        this.attempts = 0;
        this.createdAt = createdAt;
    }

    public void recordAttempt() {
        this.attempts++;
    }

    public void markSent(Instant when) {
        this.status = Status.SENT;
        this.sentAt = when;
    }

    public String getId() {
        return id;
    }

    public String getDeliveryRequestId() {
        return deliveryRequestId;
    }

    public String getDocumentJobId() {
        return documentJobId;
    }

    public Status getStatus() {
        return status;
    }

    public int getAttempts() {
        return attempts;
    }
}
