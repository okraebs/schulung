package de.demo.versicherung.korrespondenz.worker.handler;

import de.demo.versicherung.korrespondenz.contracts.ContractData;
import de.demo.versicherung.korrespondenz.contracts.CustomerData;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.contracts.TariffData;
import de.demo.versicherung.korrespondenz.worker.WorkerProperties;
import de.demo.versicherung.korrespondenz.worker.client.SimulatorClient;
import de.demo.versicherung.korrespondenz.worker.persistence.ArtifactService;
import de.demo.versicherung.korrespondenz.worker.persistence.DocumentArtifactEntity;
import de.demo.versicherung.korrespondenz.worker.render.DocumentArtifact;
import de.demo.versicherung.korrespondenz.worker.render.DocumentStore;
import de.demo.versicherung.korrespondenz.worker.render.PdfRenderer;
import de.demo.versicherung.korrespondenz.worker.render.RenderModel;
import io.micrometer.core.instrument.MeterRegistry;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

/**
 * Handler {@code render-document} (Auftrag 8.4 / 13 / 8.10): erzeugt ein echtes PDF (idempotent) und
 * legt nur Referenz/Hash/Größe/Content-Type als Prozessvariablen ab. Ein
 * {@code PERMANENT_RENDER_FAILURE} fuehrt ueber dekrementierte Retries zu {@code retries=0} und damit
 * zu einem Incident (Auftrag 8.10.2 / 23.9).
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_RENDER_DOCUMENT)
public class RenderDocumentHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(RenderDocumentHandler.class);
    private static final int INITIAL_RETRIES = 1;
    private static final long RETRY_BACKOFF_MS = 1500L;

    private final SimulatorClient simulatorClient;
    private final PdfRenderer pdfRenderer;
    private final DocumentStore documentStore;
    private final WorkerProperties properties;
    private final ArtifactService artifactService;
    private final MeterRegistry meterRegistry;

    public RenderDocumentHandler(
            SimulatorClient simulatorClient,
            PdfRenderer pdfRenderer,
            DocumentStore documentStore,
            WorkerProperties properties,
            ArtifactService artifactService,
            MeterRegistry meterRegistry) {
        this.simulatorClient = simulatorClient;
        this.pdfRenderer = pdfRenderer;
        this.documentStore = documentStore;
        this.properties = properties;
        this.artifactService = artifactService;
        this.meterRegistry = meterRegistry;
    }

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        String documentJobId = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_DOCUMENT_JOB_ID);
        MDC.put("documentJobId", documentJobId);
        MDC.put("externalTaskId", externalTask.getId());
        try {
            render(externalTask, externalTaskService, documentJobId);
        } catch (RuntimeException e) {
            handleFailure(externalTask, externalTaskService, e);
        } finally {
            MDC.clear();
        }
    }

    private void render(ExternalTask externalTask, ExternalTaskService externalTaskService, String documentJobId) {
        FailureProfile profile = HandlerSupport.failureProfile(externalTask);
        if (profile == FailureProfile.PERMANENT_RENDER_FAILURE) {
            throw new IllegalStateException("Permanenter Renderfehler (deterministisch)");
        }
        String documentType = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_DOCUMENT_TYPE);
        String customerId = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_CUSTOMER_ID);
        String contractId = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_CONTRACT_ID);

        CustomerData customer = simulatorClient.loadCustomer(customerId, profile);
        ContractData contract = simulatorClient.loadContract(contractId, profile);
        String product = contract.product() != null ? contract.product() : "UNKNOWN";
        TariffData tariff = simulatorClient.loadTariff(product, profile);

        boolean degraded = Boolean.TRUE.equals(externalTask.getVariable(ProcessConstants.VAR_DEGRADED));
        List<String> reasons = parseReasons(externalTask.getVariable(ProcessConstants.VAR_DEGRADATION_REASONS));
        String language =
                HandlerSupport.optionalString(externalTask, ProcessConstants.VAR_LANGUAGE, defaultLanguage(customer));
        String templateId = HandlerSupport.optionalString(externalTask, ProcessConstants.VAR_TEMPLATE_ID, documentType);
        String legalTextKey =
                HandlerSupport.optionalString(externalTask, ProcessConstants.VAR_LEGAL_TEXT_KEY, "default");

        RenderModel model = new RenderModel(
                documentJobId,
                documentType,
                language,
                templateId,
                legalTextKey,
                customer.fullName(),
                contract.contractNumber(),
                contract.effectiveDate(),
                product,
                tariff.tariffName(),
                tariff.premiumOld(),
                tariff.premiumNew(),
                degraded ? null : customer.advisorName(),
                degraded,
                reasons);

        DocumentArtifact artifact = renderAndStore(documentJobId, model);
        Map<String, Object> variables = Map.of(
                ProcessConstants.VAR_DOCUMENT_URI, artifact.documentUri(),
                ProcessConstants.VAR_DOCUMENT_SHA256, artifact.documentSha256(),
                ProcessConstants.VAR_DOCUMENT_SIZE, artifact.documentSize(),
                ProcessConstants.VAR_DOCUMENT_CONTENT_TYPE, artifact.documentContentType());
        externalTaskService.complete(externalTask, variables);
        log.info(
                "render-document documentJobId={} mode={} size={}",
                documentJobId,
                properties.renderMode(),
                artifact.documentSize());
    }

    private void handleFailure(ExternalTask externalTask, ExternalTaskService externalTaskService, RuntimeException e) {
        Integer current = externalTask.getRetries();
        // Erster Fehlversuch (retries == null): mit INITIAL_RETRIES beginnen; danach dekrementieren.
        int newRetries = (current == null) ? INITIAL_RETRIES : Math.max(0, current - 1);
        meterRegistry.counter("worker.render.failures").increment();
        log.info("render-document Fehlversuch: currentRetries={} -> newRetries={}", current, newRetries);
        if (newRetries == 0) {
            meterRegistry.counter("documents.incidents").increment();
            log.warn("render-document erschöpft (retries=0) -> Incident: {}", e.getMessage());
        }
        externalTaskService.handleFailure(
                externalTask, "render-document fehlgeschlagen", e.getMessage(), newRetries, RETRY_BACKOFF_MS);
    }

    private DocumentArtifact renderAndStore(String documentJobId, RenderModel model) {
        Optional<DocumentArtifactEntity> existing = artifactService.find(documentJobId);
        if (existing.isPresent()) {
            DocumentArtifactEntity e = existing.get();
            log.info("render-document documentJobId={} -> vorhandenes Artefakt wiederverwendet", documentJobId);
            return new DocumentArtifact(
                    e.getDocumentUri(), e.getDocumentSha256(), e.getDocumentSize(), e.getContentType());
        }
        DocumentArtifact produced;
        if (properties.renderMode() == WorkerProperties.RenderMode.METADATA_ONLY) {
            byte[] synthetic = (model.documentType() + "|" + model.language() + "|" + model.templateId())
                    .getBytes(StandardCharsets.UTF_8);
            produced = documentStore.storeMetadataOnly(documentJobId, synthetic);
        } else {
            byte[] pdf = pdfRenderer.render(model);
            produced = documentStore.store(documentJobId, pdf);
        }
        artifactService.store(documentJobId, produced);
        return produced;
    }

    private static String defaultLanguage(CustomerData customer) {
        return customer.preferredLanguage() != null ? customer.preferredLanguage() : "de";
    }

    private static List<String> parseReasons(Object raw) {
        if (raw == null) {
            return List.of();
        }
        if (raw instanceof List<?> list) {
            List<String> result = new ArrayList<>();
            for (Object o : list) {
                result.add(String.valueOf(o));
            }
            return result;
        }
        String s = String.valueOf(raw).trim();
        if (s.isEmpty()) {
            return List.of();
        }
        return List.of(s.split("\\s*,\\s*"));
    }
}
