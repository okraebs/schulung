package de.demo.versicherung.korrespondenz.worker.handler;

import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import org.camunda.bpm.client.task.ExternalTask;

/** Kleine Lesehilfen fuer External-Task-Variablen. */
final class HandlerSupport {

    private HandlerSupport() {}

    static FailureProfile failureProfile(ExternalTask task) {
        String raw = task.getVariable(ProcessConstants.VAR_FAILURE_PROFILE);
        if (raw == null || raw.isBlank()) {
            return FailureProfile.HAPPY;
        }
        return FailureProfile.valueOf(raw);
    }

    static String requiredString(ExternalTask task, String name) {
        String value = task.getVariable(name);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Fehlende Prozessvariable: " + name);
        }
        return value;
    }

    static String optionalString(ExternalTask task, String name, String fallback) {
        String value = task.getVariable(name);
        return value == null || value.isBlank() ? fallback : value;
    }
}
