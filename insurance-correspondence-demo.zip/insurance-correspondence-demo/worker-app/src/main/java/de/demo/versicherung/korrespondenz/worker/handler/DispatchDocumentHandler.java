package de.demo.versicherung.korrespondenz.worker.handler;

import de.demo.versicherung.korrespondenz.contracts.CustomerData;
import de.demo.versicherung.korrespondenz.contracts.DeliveryChannel;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.worker.client.SimulatorClient;
import de.demo.versicherung.korrespondenz.worker.persistence.DeliveryOutboxService;
import de.demo.versicherung.korrespondenz.worker.persistence.DeliveryRequestEntity;
import java.util.Map;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

/**
 * Handler {@code dispatch-document} (Auftrag 8.5 / 9.5): schreibt Delivery Request und Outbox Event
 * in einer lokalen Transaktion (idempotent je documentJobId) und schliesst den External Task erst
 * nach erfolgreichem Commit ab. Der eigentliche Versand an das Output-Management uebernimmt der
 * Outbox-Publisher. Schlaegt das External-Task-Complete nach dem Commit fehl, findet der erneut
 * ausgefuehrte Handler den vorhandenen Delivery Request und verwendet ihn wieder (Auftrag 9.6).
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_DISPATCH_DOCUMENT)
public class DispatchDocumentHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(DispatchDocumentHandler.class);

    private final SimulatorClient simulatorClient;
    private final DeliveryOutboxService deliveryOutboxService;

    public DispatchDocumentHandler(SimulatorClient simulatorClient, DeliveryOutboxService deliveryOutboxService) {
        this.simulatorClient = simulatorClient;
        this.deliveryOutboxService = deliveryOutboxService;
    }

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        String documentJobId = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_DOCUMENT_JOB_ID);
        MDC.put("documentJobId", documentJobId);
        MDC.put("externalTaskId", externalTask.getId());
        try {
            dispatch(externalTask, externalTaskService, documentJobId);
        } finally {
            MDC.clear();
        }
    }

    private void dispatch(ExternalTask externalTask, ExternalTaskService externalTaskService, String documentJobId) {
        String customerId = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_CUSTOMER_ID);
        String documentUri = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_DOCUMENT_URI);
        String documentSha256 = externalTask.getVariable(ProcessConstants.VAR_DOCUMENT_SHA256);
        FailureProfile profile = HandlerSupport.failureProfile(externalTask);
        DeliveryChannel channel = channel(externalTask);
        String priority = HandlerSupport.optionalString(externalTask, ProcessConstants.VAR_DELIVERY_PRIORITY, "NORMAL");

        CustomerData customer = simulatorClient.loadCustomer(customerId, profile);
        String recipient = recipient(externalTask, customer, channel);

        // Lokale Transaktion: Delivery Request + Outbox Event (idempotent je documentJobId)
        DeliveryRequestEntity request = deliveryOutboxService.createOrGet(new DeliveryOutboxService.Command(
                documentJobId, channel.name(), recipient, documentUri, documentSha256, priority, profile.name()));

        // Erst nach erfolgreichem Commit den External Task abschliessen
        Map<String, Object> variables =
                Map.of(ProcessConstants.VAR_DELIVERY_REQUEST_ID, request.getDeliveryRequestId());
        externalTaskService.complete(externalTask, variables);
        log.info(
                "dispatch-document documentJobId={} deliveryRequestId={} (Outbox angelegt)",
                documentJobId,
                request.getDeliveryRequestId());
    }

    private DeliveryChannel channel(ExternalTask task) {
        String raw = HandlerSupport.optionalString(
                task, ProcessConstants.VAR_DELIVERY_CHANNEL, DeliveryChannel.EMAIL.name());
        try {
            return DeliveryChannel.valueOf(raw);
        } catch (IllegalArgumentException e) {
            return DeliveryChannel.EMAIL;
        }
    }

    private String recipient(ExternalTask task, CustomerData customer, DeliveryChannel channel) {
        String correctedEmail = task.getVariable("correctedEmail");
        String correctedPostal = task.getVariable("correctedPostalAddress");
        return switch (channel) {
            case PRINT -> firstNonBlank(correctedPostal, customer.postalAddress(), "Unbekannte Anschrift");
            case EMAIL, CUSTOMER_PORTAL -> firstNonBlank(correctedEmail, customer.email(), "unknown@example.test");
        };
    }

    private static String firstNonBlank(String... values) {
        for (String v : values) {
            if (v != null && !v.isBlank()) {
                return v;
            }
        }
        return "";
    }
}
