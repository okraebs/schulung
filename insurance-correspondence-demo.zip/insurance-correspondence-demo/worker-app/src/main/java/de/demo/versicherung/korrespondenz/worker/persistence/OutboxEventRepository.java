package de.demo.versicherung.korrespondenz.worker.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OutboxEventRepository extends JpaRepository<OutboxEventEntity, String> {

    List<OutboxEventEntity> findByStatus(OutboxEventEntity.Status status);
}
