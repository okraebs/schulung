package de.demo.versicherung.korrespondenz.worker.render;

import de.demo.versicherung.korrespondenz.worker.WorkerProperties;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import org.springframework.stereotype.Component;

/**
 * Legt gerenderte Dokumente unter {@code var/documents/{documentJobId}/} ab (Auftrag 13.3),
 * normalisiert Dateinamen und verhindert einen Pfadausbruch ueber documentJobId (Auftrag 21.5).
 * Berechnet SHA-256 und Metadaten.
 */
@Component
public class DocumentStore {

    private static final String CONTENT_TYPE = "application/pdf";
    private final Path baseDir;

    public DocumentStore(WorkerProperties properties) {
        this.baseDir = Path.of(properties.documentBaseDir()).toAbsolutePath().normalize();
    }

    /** Schreibt das PDF und liefert die Referenz (REAL_PDF-Modus). Idempotent: ueberschreibt deterministisch. */
    public DocumentArtifact store(String documentJobId, byte[] pdf) {
        Path dir = safeDirectory(documentJobId);
        try {
            Files.createDirectories(dir);
            Path file = dir.resolve("document.pdf");
            Files.write(file, pdf);
            return new DocumentArtifact(file.toUri().toString(), sha256Hex(pdf), pdf.length, CONTENT_TYPE);
        } catch (IOException e) {
            throw new UncheckedIOException("Konnte Dokument nicht speichern: " + documentJobId, e);
        }
    }

    /** METADATA_ONLY-Modus (Last, Auftrag 13.4): keine Datei, nur deterministische Metadaten. */
    public DocumentArtifact storeMetadataOnly(String documentJobId, byte[] syntheticContent) {
        // Validiert den documentJobId ebenfalls (Pfadsicherheit), schreibt aber nichts.
        Path dir = safeDirectory(documentJobId);
        String uri = "metadata://" + baseDir.relativize(dir).toString().replace('\\', '/');
        return new DocumentArtifact(uri, sha256Hex(syntheticContent), syntheticContent.length, CONTENT_TYPE);
    }

    private Path safeDirectory(String documentJobId) {
        String sanitized = sanitize(documentJobId);
        Path dir = baseDir.resolve(sanitized).normalize();
        if (!dir.startsWith(baseDir)) {
            throw new IllegalArgumentException("Unzulaessiger documentJobId (Pfadausbruch): " + documentJobId);
        }
        return dir;
    }

    private static String sanitize(String documentJobId) {
        if (documentJobId == null || documentJobId.isBlank()) {
            throw new IllegalArgumentException("documentJobId darf nicht leer sein");
        }
        String sanitized = documentJobId.replaceAll("[^A-Za-z0-9._-]", "_");
        if (sanitized.equals(".") || sanitized.equals("..") || sanitized.isBlank()) {
            throw new IllegalArgumentException("Unzulaessiger documentJobId: " + documentJobId);
        }
        return sanitized;
    }

    private static String sha256Hex(byte[] content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(content));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 nicht verfuegbar", e);
        }
    }

    public Path baseDir() {
        return baseDir;
    }
}
