package de.demo.versicherung.korrespondenz.worker.handler;

import de.demo.versicherung.korrespondenz.contracts.DeliveryResultStatus;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.contracts.ProviderStatusResponse;
import de.demo.versicherung.korrespondenz.worker.client.SimulatorClient;
import java.util.HashMap;
import java.util.Map;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Handler {@code reconcile-delivery} (Auftrag 6.1.11 / 8.6): fragt den Providerstatus beim Simulator
 * anhand der {@code deliveryRequestId} ab und liefert ACCEPTED, PENDING, REJECTED oder UNKNOWN.
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_RECONCILE_DELIVERY)
public class ReconcileDeliveryHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(ReconcileDeliveryHandler.class);

    private final SimulatorClient simulatorClient;

    public ReconcileDeliveryHandler(SimulatorClient simulatorClient) {
        this.simulatorClient = simulatorClient;
    }

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        String deliveryRequestId =
                HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_DELIVERY_REQUEST_ID);

        DeliveryResultStatus status;
        String providerReference = null;
        try {
            ProviderStatusResponse response = simulatorClient.deliveryStatus(deliveryRequestId);
            status = response.deliveryResultStatus();
            providerReference = response.providerReference();
        } catch (RuntimeException e) {
            // Unbekannter/abgefragter Zustand nicht ermittelbar -> UNKNOWN (fuehrt zur Klaerung)
            status = DeliveryResultStatus.UNKNOWN;
        }

        Map<String, Object> variables = new HashMap<>();
        variables.put(ProcessConstants.VAR_DELIVERY_RESULT_STATUS, status.name());
        variables.put(ProcessConstants.VAR_PROVIDER_REFERENCE, providerReference);

        externalTaskService.complete(externalTask, variables);
        log.info(
                "reconcile-delivery documentJobId={} deliveryRequestId={} -> {}",
                externalTask.getVariable(ProcessConstants.VAR_DOCUMENT_JOB_ID),
                deliveryRequestId,
                status);
    }
}
