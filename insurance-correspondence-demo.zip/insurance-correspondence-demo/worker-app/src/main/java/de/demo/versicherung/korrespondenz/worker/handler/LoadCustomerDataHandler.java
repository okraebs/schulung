package de.demo.versicherung.korrespondenz.worker.handler;

import de.demo.versicherung.korrespondenz.contracts.CustomerData;
import de.demo.versicherung.korrespondenz.contracts.DataStatus;
import de.demo.versicherung.korrespondenz.contracts.DeliveryChannel;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.worker.client.SimulatorClient;
import java.util.HashMap;
import java.util.Map;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Handler {@code load-customer-data} (Auftrag 8.1): laedt Kundendaten und leitet
 * {@code customerDataStatus} sowie kleine, DMN-relevante Skalare ab. Es gelangen keine
 * personenbezogenen Inhalte in Prozessvariablen – nur Sprache, Bundesland, Kanal und Status.
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_LOAD_CUSTOMER)
public class LoadCustomerDataHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(LoadCustomerDataHandler.class);

    private final SimulatorClient simulatorClient;

    public LoadCustomerDataHandler(SimulatorClient simulatorClient) {
        this.simulatorClient = simulatorClient;
    }

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        String customerId = HandlerSupport.requiredString(externalTask, ProcessConstants.VAR_CUSTOMER_ID);
        FailureProfile profile = HandlerSupport.failureProfile(externalTask);

        CustomerData customer = simulatorClient.loadCustomer(customerId, profile);
        // Korrekturen aus einer vorangegangenen manuellen Klaerung beruecksichtigen (RETRY nach Korrektur)
        String correctedEmail = externalTask.getVariable("correctedEmail");
        String correctedPostal = externalTask.getVariable("correctedPostalAddress");
        DataStatus status = deriveStatus(customer, correctedEmail, correctedPostal);

        Map<String, Object> variables = new HashMap<>();
        variables.put(ProcessConstants.VAR_CUSTOMER_DATA_STATUS, status.name());
        variables.put(ProcessConstants.VAR_LANGUAGE, defaultIfNull(customer.preferredLanguage(), "de"));
        variables.put("customerFederalState", defaultIfNull(customer.federalState(), "BY"));
        variables.put("customerHasAdvisor", customer.advisorName() != null);
        variables.put("customerHasMarketingInsert", customer.marketingInsert() != null);
        // Default-Kanal aus Kundenpraeferenz (delivery-policy.dmn kann das in Phase 3 ueberschreiben)
        variables.put(
                ProcessConstants.VAR_DELIVERY_CHANNEL, defaultChannel(customer).name());

        externalTaskService.complete(externalTask, variables);
        log.info("load-customer-data documentJobId={} status={}", documentJobId(externalTask), status);
    }

    private DataStatus deriveStatus(CustomerData c, String correctedEmail, String correctedPostal) {
        boolean hasAddress = isNotBlank(c.email())
                || isNotBlank(c.postalAddress())
                || isNotBlank(correctedEmail)
                || isNotBlank(correctedPostal);
        boolean mandatoryPresent = isNotBlank(c.fullName()) && hasAddress;
        boolean optionalPresent = isNotBlank(c.advisorName()) && isNotBlank(c.marketingInsert());
        if (!mandatoryPresent) {
            return DataStatus.MANDATORY_MISSING;
        }
        return optionalPresent ? DataStatus.OK : DataStatus.OPTIONAL_MISSING;
    }

    private DeliveryChannel defaultChannel(CustomerData c) {
        if (c.preferredChannel() != null) {
            try {
                return DeliveryChannel.valueOf(c.preferredChannel());
            } catch (IllegalArgumentException ignored) {
                // faellt auf E-Mail zurueck
            }
        }
        return DeliveryChannel.EMAIL;
    }

    private static boolean isNotBlank(String s) {
        return s != null && !s.isBlank();
    }

    private static String defaultIfNull(String value, String fallback) {
        return value == null ? fallback : value;
    }

    private static String documentJobId(ExternalTask task) {
        return task.getVariable(ProcessConstants.VAR_DOCUMENT_JOB_ID);
    }
}
