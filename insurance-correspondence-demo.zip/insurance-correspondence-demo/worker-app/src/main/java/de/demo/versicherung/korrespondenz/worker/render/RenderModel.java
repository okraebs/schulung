package de.demo.versicherung.korrespondenz.worker.render;

import java.util.List;

/**
 * Kompaktes Eingabemodell fuer das PDF-Rendering. Enthaelt nur die fuer das Dokument benoetigten
 * Werte; wird vom Render-Handler aus frisch geladenen Simulatordaten zusammengesetzt (keine PII in
 * Prozessvariablen).
 */
public record RenderModel(
        String documentJobId,
        String documentType,
        String language,
        String templateId,
        String legalTextKey,
        String customerName,
        String contractNumber,
        String effectiveDate,
        String product,
        String tariffName,
        String premiumOld,
        String premiumNew,
        String advisorName,
        boolean degraded,
        List<String> degradationReasons) {}
