package de.demo.versicherung.korrespondenz.worker.persistence;

import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Schreibt Delivery Request und Outbox Event in einer lokalen Transaktion (Auftrag 9.5). Idempotent
 * über {@code documentJobId}: ein wiederholter Aufruf liefert den bestehenden Request zurueck und
 * erzeugt keinen zweiten Request/Outbox-Eintrag.
 */
@Service
public class DeliveryOutboxService {

    private final DeliveryRequestRepository requestRepository;
    private final OutboxEventRepository outboxRepository;

    public DeliveryOutboxService(DeliveryRequestRepository requestRepository, OutboxEventRepository outboxRepository) {
        this.requestRepository = requestRepository;
        this.outboxRepository = outboxRepository;
    }

    @Transactional
    public DeliveryRequestEntity createOrGet(Command command) {
        return requestRepository.findByDocumentJobId(command.documentJobId()).orElseGet(() -> {
            String deliveryRequestId = "DR-" + command.documentJobId();
            DeliveryRequestEntity request = new DeliveryRequestEntity(
                    deliveryRequestId,
                    command.documentJobId(),
                    command.deliveryChannel(),
                    command.recipient(),
                    command.documentUri(),
                    command.documentSha256(),
                    command.priority(),
                    command.failureProfile(),
                    Instant.now());
            requestRepository.save(request);
            outboxRepository.save(new OutboxEventEntity(
                    UUID.randomUUID().toString(), deliveryRequestId, command.documentJobId(), Instant.now()));
            return request;
        });
    }

    @Transactional(readOnly = true)
    public List<OutboxEventEntity> pendingNew() {
        return outboxRepository.findByStatus(OutboxEventEntity.Status.NEW);
    }

    @Transactional(readOnly = true)
    public DeliveryRequestEntity requireRequest(String deliveryRequestId) {
        return requestRepository
                .findById(deliveryRequestId)
                .orElseThrow(() -> new IllegalStateException("Delivery Request weg: " + deliveryRequestId));
    }

    /** Markiert Outbox-Eintrag und Request nach bestaetigter Annahme als SENT. */
    @Transactional
    public void markSent(String outboxId) {
        OutboxEventEntity event = outboxRepository
                .findById(outboxId)
                .orElseThrow(() -> new IllegalStateException("Outbox-Eintrag weg: " + outboxId));
        event.markSent(Instant.now());
        requestRepository.findById(event.getDeliveryRequestId()).ifPresent(DeliveryRequestEntity::markSent);
    }

    @Transactional
    public void recordAttempt(String outboxId) {
        outboxRepository.findById(outboxId).ifPresent(OutboxEventEntity::recordAttempt);
    }

    /** Eingabe fuer das Anlegen eines Delivery Requests. */
    public record Command(
            String documentJobId,
            String deliveryChannel,
            String recipient,
            String documentUri,
            String documentSha256,
            String priority,
            String failureProfile) {}
}
