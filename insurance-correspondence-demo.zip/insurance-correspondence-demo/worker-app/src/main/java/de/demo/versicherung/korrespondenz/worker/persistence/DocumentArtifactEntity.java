package de.demo.versicherung.korrespondenz.worker.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

/** Persistierte Referenz auf ein gerendertes Dokument (Auftrag 10.6). PK = documentJobId (idempotent). */
@Entity
@Table(name = "document_artifact")
public class DocumentArtifactEntity {

    @Id
    @Column(name = "document_job_id", length = 100)
    private String documentJobId;

    @Column(name = "document_uri", nullable = false, length = 500)
    private String documentUri;

    @Column(name = "document_sha256", nullable = false, length = 64)
    private String documentSha256;

    @Column(name = "document_size", nullable = false)
    private long documentSize;

    @Column(name = "content_type", nullable = false, length = 50)
    private String contentType;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    protected DocumentArtifactEntity() {}

    public DocumentArtifactEntity(
            String documentJobId,
            String documentUri,
            String documentSha256,
            long documentSize,
            String contentType,
            Instant createdAt) {
        this.documentJobId = documentJobId;
        this.documentUri = documentUri;
        this.documentSha256 = documentSha256;
        this.documentSize = documentSize;
        this.contentType = contentType;
        this.createdAt = createdAt;
    }

    public String getDocumentJobId() {
        return documentJobId;
    }

    public String getDocumentUri() {
        return documentUri;
    }

    public String getDocumentSha256() {
        return documentSha256;
    }

    public long getDocumentSize() {
        return documentSize;
    }

    public String getContentType() {
        return contentType;
    }
}
