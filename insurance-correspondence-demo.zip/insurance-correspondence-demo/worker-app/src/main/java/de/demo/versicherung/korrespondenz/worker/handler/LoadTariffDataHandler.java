package de.demo.versicherung.korrespondenz.worker.handler;

import de.demo.versicherung.korrespondenz.contracts.DataStatus;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import de.demo.versicherung.korrespondenz.contracts.TariffData;
import de.demo.versicherung.korrespondenz.worker.client.SimulatorClient;
import java.util.HashMap;
import java.util.Map;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Handler {@code load-tariff-data} (Auftrag 8.3): laedt Tarifdaten anhand des Produkts und setzt
 * {@code tariffDataStatus}.
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_LOAD_TARIFF)
public class LoadTariffDataHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(LoadTariffDataHandler.class);

    private final SimulatorClient simulatorClient;

    public LoadTariffDataHandler(SimulatorClient simulatorClient) {
        this.simulatorClient = simulatorClient;
    }

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        String product = HandlerSupport.optionalString(externalTask, "product", "UNKNOWN");
        FailureProfile profile = HandlerSupport.failureProfile(externalTask);

        TariffData tariff = simulatorClient.loadTariff(product, profile);
        DataStatus status = deriveStatus(tariff);

        Map<String, Object> variables = new HashMap<>();
        variables.put(ProcessConstants.VAR_TARIFF_DATA_STATUS, status.name());

        externalTaskService.complete(externalTask, variables);
        log.info(
                "load-tariff-data documentJobId={} product={} status={}",
                externalTask.getVariable(ProcessConstants.VAR_DOCUMENT_JOB_ID),
                product,
                status);
    }

    private DataStatus deriveStatus(TariffData t) {
        boolean mandatoryPresent = isNotBlank(t.tariffName()) && isNotBlank(t.premiumNew());
        boolean optionalPresent = isNotBlank(t.adjustmentReason());
        if (!mandatoryPresent) {
            return DataStatus.MANDATORY_MISSING;
        }
        return optionalPresent ? DataStatus.OK : DataStatus.OPTIONAL_MISSING;
    }

    private static boolean isNotBlank(String s) {
        return s != null && !s.isBlank();
    }
}
