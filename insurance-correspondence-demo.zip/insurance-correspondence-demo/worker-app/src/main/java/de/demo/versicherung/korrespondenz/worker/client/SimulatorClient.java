package de.demo.versicherung.korrespondenz.worker.client;

import de.demo.versicherung.korrespondenz.contracts.ContractData;
import de.demo.versicherung.korrespondenz.contracts.CustomerData;
import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchRequest;
import de.demo.versicherung.korrespondenz.contracts.DeliveryDispatchResponse;
import de.demo.versicherung.korrespondenz.contracts.FailureProfile;
import de.demo.versicherung.korrespondenz.contracts.ProviderStatusResponse;
import de.demo.versicherung.korrespondenz.contracts.TariffData;
import de.demo.versicherung.korrespondenz.worker.WorkerProperties;
import java.time.Duration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * HTTP-Client zu den Quellsystemen und zum Output-Management des Simulators. Alle Aufrufe haben
 * endliche Connect-/Read-Timeouts (Auftrag 21.4).
 */
@Component
public class SimulatorClient {

    private final RestClient restClient;

    public SimulatorClient(WorkerProperties properties) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Duration.ofSeconds(3));
        factory.setReadTimeout(Duration.ofSeconds(10));
        this.restClient = RestClient.builder()
                .baseUrl(properties.simulatorBaseUrl())
                .requestFactory(factory)
                .build();
    }

    public CustomerData loadCustomer(String customerId, FailureProfile profile) {
        return restClient
                .get()
                .uri("/sim/customers/{id}?profile={p}", customerId, profile.name())
                .retrieve()
                .body(CustomerData.class);
    }

    public ContractData loadContract(String contractId, FailureProfile profile) {
        return restClient
                .get()
                .uri("/sim/contracts/{id}?profile={p}", contractId, profile.name())
                .retrieve()
                .body(ContractData.class);
    }

    public TariffData loadTariff(String product, FailureProfile profile) {
        return restClient
                .get()
                .uri("/sim/tariffs/{product}?profile={p}", product, profile.name())
                .retrieve()
                .body(TariffData.class);
    }

    public DeliveryDispatchResponse dispatch(DeliveryDispatchRequest request) {
        return restClient
                .post()
                .uri("/sim/output/delivery-requests")
                .body(request)
                .retrieve()
                .body(DeliveryDispatchResponse.class);
    }

    public ProviderStatusResponse deliveryStatus(String deliveryRequestId) {
        return restClient
                .get()
                .uri("/sim/output/delivery-requests/{id}/status", deliveryRequestId)
                .retrieve()
                .body(ProviderStatusResponse.class);
    }
}
