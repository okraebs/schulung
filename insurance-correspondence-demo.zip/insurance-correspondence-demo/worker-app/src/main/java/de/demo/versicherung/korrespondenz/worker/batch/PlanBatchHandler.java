package de.demo.versicherung.korrespondenz.worker.batch;

import de.demo.versicherung.korrespondenz.contracts.ProcessConstants;
import java.util.HashMap;
import java.util.Map;
import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Handler {@code plan-batch} (Auftrag 8.7): erzeugt einen reproduzierbaren Plan (Seed) und setzt die
 * Steuervariablen. Speichert NIEMALS alle Auftraege als Prozessvariable – nur kleine Zahlen.
 */
@Component
@ExternalTaskSubscription(topicName = ProcessConstants.TOPIC_PLAN_BATCH)
public class PlanBatchHandler implements ExternalTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(PlanBatchHandler.class);

    @Override
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
        int totalCount = intVar(externalTask, "count", 20);
        int pageSize = intVar(externalTask, "pageSize", 25);
        int maxInFlight = intVar(externalTask, "maxInFlight", 100);
        int targetRate = intVar(externalTask, "targetRate", 3);

        Map<String, Object> variables = new HashMap<>();
        variables.put("totalCount", totalCount);
        variables.put("pageSize", pageSize);
        variables.put("maxInFlight", maxInFlight);
        variables.put("targetRate", targetRate);
        variables.put("publishedCount", 0);

        externalTaskService.complete(externalTask, variables);
        log.info(
                "plan-batch batchId={} totalCount={} pageSize={} maxInFlight={}",
                externalTask.getVariable(ProcessConstants.VAR_BATCH_ID),
                totalCount,
                pageSize,
                maxInFlight);
    }

    private int intVar(ExternalTask task, String name, int fallback) {
        Object value = task.getVariable(name);
        return value instanceof Number number ? number.intValue() : fallback;
    }
}
