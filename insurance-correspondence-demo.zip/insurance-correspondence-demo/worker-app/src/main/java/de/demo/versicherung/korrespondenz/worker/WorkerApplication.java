package de.demo.versicherung.korrespondenz.worker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Worker-Anwendung: bindet External-Task-Handler an die Engine (ausschliesslich via REST) und
 * fuehrt die fachliche I/O-Arbeit aus (Datenbeschaffung, PDF-Erzeugung, Dispatch, Reconciliation).
 * Port 8081 dient nur Health/Metrics.
 */
@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties(WorkerProperties.class)
public class WorkerApplication {

    public static void main(String[] args) {
        SpringApplication.run(WorkerApplication.class, args);
    }
}
