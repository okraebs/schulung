-- Worker-Tabellen (Auftrag 9.5 / 10.6). document_job_id ist je Tabelle eindeutig und sichert die
-- Idempotenz: ein wiederholter Render-/Dispatch-Lauf erzeugt kein zweites Artefakt bzw. keinen
-- zweiten Delivery Request.

CREATE TABLE document_artifact (
    document_job_id  VARCHAR(100) NOT NULL,
    document_uri     VARCHAR(500) NOT NULL,
    document_sha256  VARCHAR(64)  NOT NULL,
    document_size    BIGINT       NOT NULL,
    content_type     VARCHAR(50)  NOT NULL,
    created_at       TIMESTAMP    NOT NULL,
    CONSTRAINT pk_document_artifact PRIMARY KEY (document_job_id)
);

CREATE TABLE delivery_request (
    delivery_request_id VARCHAR(100) NOT NULL,
    document_job_id     VARCHAR(100) NOT NULL,
    delivery_channel    VARCHAR(30)  NOT NULL,
    recipient           VARCHAR(300),
    document_uri        VARCHAR(500),
    document_sha256     VARCHAR(64),
    priority            VARCHAR(20),
    failure_profile     VARCHAR(40),
    status              VARCHAR(20)  NOT NULL,
    created_at          TIMESTAMP    NOT NULL,
    CONSTRAINT pk_delivery_request PRIMARY KEY (delivery_request_id),
    CONSTRAINT uq_delivery_request_job UNIQUE (document_job_id)
);

CREATE TABLE outbox_event (
    id                  VARCHAR(36)  NOT NULL,
    delivery_request_id VARCHAR(100) NOT NULL,
    document_job_id     VARCHAR(100) NOT NULL,
    status              VARCHAR(20)  NOT NULL,
    attempts            INT          NOT NULL,
    created_at          TIMESTAMP    NOT NULL,
    sent_at             TIMESTAMP,
    CONSTRAINT pk_outbox_event PRIMARY KEY (id),
    CONSTRAINT uq_outbox_delivery_request UNIQUE (delivery_request_id)
);

CREATE INDEX idx_outbox_status ON outbox_event (status);
