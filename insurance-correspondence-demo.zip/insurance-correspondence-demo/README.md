# insurance-correspondence-demo

Didaktische **Camunda-7-Demoanwendung** für Versicherungskorrespondenz. Sie orchestriert die
Erzeugung, Anreicherung, Prüfung, Herstellung und technische Übergabe von Kundenkorrespondenz –
ereignisgetrieben (einzelne Vertragsänderung) und im Batch (Beitragsanpassung).

> Zielplattform: **Windows 11, ohne Docker, ohne WSL**. Java 17, Maven 3.9.16,
> Camunda Platform 7.24.0 Community, Spring Boot 3.5.5.

## Zweck und Lernziele
- External-Task-Worker vs. JavaDelegate, Message-Korrelation, Receive Task, Timer, User Task, DMN.
- **Langlaufende Transaktionen** ohne verteilte ACID-TX: Wait-State-Persistenz, Idempotenz,
  Outbox, Inbox, Reconciliation, bewusste asynchrone Fortsetzung (`asyncBefore`).
- Backpressure-gesteuerter Batch über unabhängige Instanzen statt riesiger Multi-Instance.

## Architekturüberblick
Maven-Multi-Modul-Projekt mit fünf Modulen:

| Modul | Rolle | Port |
|---|---|---|
| `shared-contracts` | DTOs, Enums, Verträge, `ProcessConstants`, Fixtures | – |
| `orchestrator-app` | Camunda-Engine, Webapps, REST, BPMN/DMN, Inbox | 8080 |
| `worker-app` | External Task Client: Daten, PDF, Dispatch, Outbox, Reconcile | 8081 |
| `external-systems-simulator` | Quellsysteme + Output-Management, Fehlerprofile | 8082 |
| `load-generator` | Last-CLI (event/batch/mixed) | – |

Details: [docs/architecture.md](docs/architecture.md), [docs/process-model.md](docs/process-model.md).

## Voraussetzungen
Siehe die mitgelieferte PDF *Camunda 7 Schulungsumgebung – Windows 11*. Tooling prüfen:
```powershell
.\scripts\setup-check.ps1
```

## Schnellstart
```powershell
# 1. Bauen und testen (ohne externe Dienste)
.\scripts\build.ps1          # = .\mvnw.cmd clean verify

# 2. Demo starten (Orchestrator 8080, Simulator 8082, Worker 8081)
.\scripts\start-demo.ps1

# 3. Happy Path mit echtem PDF
.\scripts\run-smoke.ps1

# 4. Stoppen
.\scripts\stop-demo.ps1
```

## Ports und Benutzer
- Cockpit/Tasklist/Admin: <http://127.0.0.1:8080/camunda>
- Demo-Benutzer (**nur Demo-Profil**, nicht produktionsgeeignet):
  - `demo` / `demo` – administrativ
  - `ops` / `ops` – Gruppe `document-ops` (bearbeitet die User Task)
- Alle Dienste binden nur an `127.0.0.1`.

## Erste Demo (Kurzfassung)
1. `start-demo.ps1` → in Cockpit mit `demo`/`demo` anmelden.
2. `run-smoke.ps1` → Auftrag endet `FULLY_DISPATCHED`, PDF unter `var/documents/<id>/`.
3. `run-manual-review-demo.ps1` → User Task in Tasklist (`ops`/`ops`).
4. `run-incident-demo.ps1 -AutoFix` → Incident und Recovery.
5. `run-restart-demo.ps1` → Wait-State überlebt Orchestrator-Neustart.
6. `run-load.ps1 -Count 20` → Batch + Lastlauf mit Konsistenzbilanz.

Ausführlich: [docs/trainer-guide.md](docs/trainer-guide.md).

## Skripte (`scripts/`)
`setup-check`, `build`, `start-demo`, `stop-demo`, `reset-demo`, `run-smoke`,
`run-manual-review-demo`, `run-incident-demo`, `run-restart-demo`, `run-load`.
REST-Beispiele: [requests/demo.http](requests/demo.http).

## Profile
- `demo` (Standard): persistente H2-Dateien, echte kleine PDFs, kurze Timer.
- `test`: H2 in-memory, deterministische Tests.
- `postgres` / `load`: PostgreSQL aus Umgebungsvariablen, mehrere Worker, METADATA_ONLY-Rendering
  ([docs/load-test.md](docs/load-test.md)).

## Weitere Dokumentation
- 📚 **[Referenz-Handbuch: BPMN · DMN · Skripte](docs/referenz/README.md)** — je ein ausführliches Dokument pro Artefakt
- [Architektur](docs/architecture.md) · [Prozessmodell](docs/process-model.md)
- [Transaktionskonzept](docs/transaction-boundaries.md) · [Fehlerkonzept](docs/error-handling.md)
- [Idempotenz/Outbox/Reconciliation](docs/idempotency-outbox-reconciliation.md)
- [Trainerleitfaden](docs/trainer-guide.md) · [Übungen](docs/exercises.md)
- [Lastleitfaden](docs/load-test.md) · [Camunda-8-Ausblick](docs/camunda8-outlook.md)
- [ADRs](docs/adr/) · [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md) · [FINAL_REPORT.md](FINAL_REPORT.md)

## Hinweise
- Synthetische Daten, keine echten personenbezogenen Daten; Logs ohne vollständige PII.
- H2-Ergebnisse sind **keine** produktiven Leistungswerte (siehe Lastleitfaden).
