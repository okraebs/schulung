# Stoppt die Demo und loescht anschliessend NUR projektlokale Daten (var/db, var/documents,
# var/reports) nach Bestaetigung oder mit -Force (Auftrag 13.5 / 19.5). Niemals ausserhalb von var.
param([switch]$Force)
. "$PSScriptRoot\_common.ps1"

& "$PSScriptRoot\stop-demo.ps1"

if (-not $Force) {
    $answer = Read-Host "Projektlokale Demo-Daten unter '$VarDir' (db/documents/reports) wirklich loeschen? (j/N)"
    if ($answer -ne "j") { Write-Host "Abgebrochen."; return }
}

foreach ($sub in @("db", "documents", "reports")) {
    $target = Join-Path $VarDir $sub
    if (Test-Path $target) {
        Get-ChildItem $target -Recurse -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "Geleert: $target"
    }
}
Write-Host "Reset abgeschlossen." -ForegroundColor Green
