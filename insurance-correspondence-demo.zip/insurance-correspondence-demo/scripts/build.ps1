# Vollstaendiger Verify ueber den Maven Wrapper (Auftrag 19.2).
. "$PSScriptRoot\_common.ps1"
Push-Location $Root
try {
    & "$Root\mvnw.cmd" -B clean verify
    if ($LASTEXITCODE -ne 0) { throw "Build fehlgeschlagen (Exit $LASTEXITCODE)" }
    Write-Host "Build erfolgreich." -ForegroundColor Green
}
finally { Pop-Location }
