# Erzeugt reproduzierbar einen technischen Incident (PERMANENT_RENDER_FAILURE) und beschreibt die
# Cockpit-Schritte; mit -AutoFix wird die Ursache behoben und die Retries via REST hochgesetzt
# (Auftrag 19.8 / 18.8). Setzt eine laufende Demo voraus.
param([switch]$AutoFix)
. "$PSScriptRoot\_common.ps1"

$id = "INCIDENT-" + (Get-Random -Maximum 99999)
Write-Host "Sende Auftrag $id mit PERMANENT_RENDER_FAILURE ..."
Submit-DocumentRequest $id "PERMANENT_RENDER_FAILURE" | Out-Null
$pi = (Get-RequestStatus $id).processInstanceId

Write-Host "Warte auf Incident (Worker dekrementiert Retries bis 0) ..."
$incidents = 0
for ($i = 0; $i -lt 45; $i++) {
    Start-Sleep -Seconds 2
    $incidents = Get-IncidentCount $pi
    if ($incidents -ge 1) { break }
}
Write-Host "Incidents fuer Instanz $pi : $incidents" -ForegroundColor $(if ($incidents -ge 1) { "Green" } else { "Red" })
Write-Host ""
Write-Host "Cockpit-Schritte:" -ForegroundColor Cyan
Write-Host "  1. $Orchestrator/camunda -> als 'demo'/'demo' anmelden -> Cockpit"
Write-Host "  2. Prozessinstanz $pi oeffnen -> Incident an 'Dokument erzeugen' (render-document)"
Write-Host "  3. Ursache beheben (hier: Variable failureProfile = HAPPY) und Retries erhoehen"

if ($AutoFix) {
    Write-Host "`n-AutoFix: behebe Ursache und setze Retries hoch ..." -ForegroundColor Yellow
    Invoke-RestMethod -Method Put "$Orchestrator/engine-rest/process-instance/$pi/variables/failureProfile" `
        -ContentType "application/json" -Body (@{ value = "HAPPY"; type = "String" } | ConvertTo-Json) | Out-Null
    $tid = (@(Invoke-RestMethod "$Orchestrator/engine-rest/external-task?processInstanceId=$pi" | Where-Object { $_.id })[0]).id
    Invoke-RestMethod -Method Put "$Orchestrator/engine-rest/external-task/$tid/retries" `
        -ContentType "application/json" -Body (@{ retries = 3 } | ConvertTo-Json) | Out-Null
    $outcome = Wait-Outcome $id 90
    $after = Get-IncidentCount $pi
    Write-Host "Nach Fix: Outcome=$outcome, verbleibende Incidents=$after" -ForegroundColor Green
}
