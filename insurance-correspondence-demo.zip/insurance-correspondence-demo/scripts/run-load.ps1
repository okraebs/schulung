# Startet einen konfigurierbaren Lastlauf (Batch + Load-Generator) und speichert Ergebnisse unter
# var/reports (Auftrag 19.10 / 15). Setzt eine laufende Demo voraus.
param(
    [int]$Count = 20,
    [int]$PageSize = 10,
    [int]$Rate = 3,
    [int]$Concurrency = 4,
    [string]$FailureProfile = "HAPPY"
)
. "$PSScriptRoot\_common.ps1"
Initialize-Dirs

Write-Host "== Batchlauf ($Count Dokumente) ==" -ForegroundColor Cyan
$batch = Invoke-RestMethod -Method Post "$Orchestrator/api/demo/batches" -ContentType "application/json" `
    -Body (@{ count = $Count; pageSize = $PageSize; maxInFlight = 100; failureProfile = $FailureProfile } | ConvertTo-Json)
$batchId = $batch.batchId
Write-Host "batchId=$batchId"

$status = $null
for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Seconds 3
    $status = Invoke-RestMethod "$Orchestrator/api/demo/batches/$batchId"
    if ($status.active -eq 0 -and $status.started -ge $Count) { break }
}
$balance = $status.started -eq ($status.fullyDispatched + $status.degradedDispatched + $status.cancelled + $status.active + $status.manual)
Write-Host ("Bilanz: started={0} active={1} fully={2} degraded={3} cancelled={4} manual={5} incident={6} | konsistent={7}" -f `
    $status.started, $status.active, $status.fullyDispatched, $status.degradedDispatched, $status.cancelled, $status.manual, $status.incident, $balance)

Write-Host "== Load-Generator (event) ==" -ForegroundColor Cyan
$gen = Join-Path $Root "load-generator\target\load-generator.jar"
if (Test-Path $gen) {
    & java -jar $gen "--mode=event" "--count=$Count" "--rate=$Rate" "--concurrency=$Concurrency" "--failureProfile=$FailureProfile" "--orchestrator=$Orchestrator"
} else {
    Write-Host "load-generator.jar fehlt – zuerst build.ps1." -ForegroundColor Yellow
}

$status | ConvertTo-Json | Out-File (Join-Path $VarDir "reports\batch-$batchId.json")
Write-Host "Bericht gespeichert unter var/reports." -ForegroundColor Green
