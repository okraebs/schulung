# Beendet ausschliesslich die in PID-Dateien registrierten Prozesse (Auftrag 19.4).
. "$PSScriptRoot\_common.ps1"

foreach ($app in $Apps) {
    $pidFile = Join-Path $RunDir "$($app.Name).pid"
    if (Test-Path $pidFile) {
        $processId = [int](Get-Content $pidFile | Select-Object -First 1)
        $proc = Get-Process -Id $processId -ErrorAction SilentlyContinue
        if ($proc) { Stop-Process -Id $processId -Force; Write-Host "$($app.Name) (PID $processId) gestoppt." }
        else { Write-Host "$($app.Name) (PID $processId) lief nicht mehr." }
        Remove-Item $pidFile -Force
    } else {
        Write-Host "Keine PID-Datei fuer $($app.Name)."
    }
}
Write-Host "Demo gestoppt." -ForegroundColor Green
