# Langlaufender Wait-State-Neustartnachweis (Auftrag 19.9 / 9.3): fuehrt einen Auftrag bis zur
# Receive Task, startet NUR den Orchestrator neu und weist nach, dass der Zustand erhalten bleibt
# und nach einem gepufferten Callback fortgesetzt wird. Setzt eine laufende Demo voraus.
. "$PSScriptRoot\_common.ps1"

$id = "RESTART-" + (Get-Random -Maximum 99999)
Write-Host "Sende Auftrag $id (DELIVERY_TIMEOUT: keine automatische Annahme) ..."
Submit-DocumentRequest $id "DELIVERY_TIMEOUT" | Out-Null

Write-Host "Warte, bis der Prozess an der Receive Task wartet ..."
$reached = $false
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 2
    $s = Get-RequestStatus $id
    if ($s -and $s.activeActivity -match "receiveResult") { $reached = $true; break }
}
Write-Host "Receive Task erreicht: $reached"

# Nur den Orchestrator neu starten
$pidFile = Join-Path $RunDir "orchestrator.pid"
$oldPid = [int](Get-Content $pidFile | Select-Object -First 1)
Write-Host "Stoppe Orchestrator (PID $oldPid) ..."
Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 4
$jar = Join-Path $Root "orchestrator-app\target\orchestrator-app.jar"
$p = Start-Process -FilePath "java" -ArgumentList @("-jar", $jar) -WorkingDirectory $Root `
    -RedirectStandardOutput (Join-Path $LogDir "orchestrator.out.log") `
    -RedirectStandardError  (Join-Path $LogDir "orchestrator.err.log") -PassThru
$p.Id | Out-File $pidFile
Write-Host "Orchestrator neu gestartet (PID $($p.Id)). Warte auf Health ..."
$null = Wait-Health "$Orchestrator/actuator/health" 120

$after = Get-RequestStatus $id
Write-Host "Nach Neustart: status=$($after.status) (Zustand ueberlebt: $($after.status -eq 'ACTIVE'))" -ForegroundColor Green

# Gepufferten Callback senden -> Fortsetzung
$cb = @{ documentJobId = $id; deliveryRequestId = "DR-$id"; deliveryResultStatus = "ACCEPTED"; providerReference = "prov"; callbackEventId = "cb-$id" } | ConvertTo-Json
Invoke-RestMethod -Method Post "$Orchestrator/api/delivery-results" -ContentType "application/json" -Body $cb | Out-Null
$outcome = Wait-Outcome $id 90
Write-Host "Outcome nach gepuffertem Callback: $outcome"

if ($reached -and $after.status -eq "ACTIVE" -and $outcome -eq "FULLY_DISPATCHED") {
    Write-Host "RESTART-NACHWEIS OK." -ForegroundColor Green
} else { Write-Host "RESTART-NACHWEIS FEHLGESCHLAGEN." -ForegroundColor Red; exit 1 }
