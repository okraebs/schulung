# Erzeugt einen Fall fuer die Tasklist (fehlende Pflichtdaten) und gibt die Anmelde- und
# Pruefschritte aus (Auftrag 19.7). Setzt eine laufende Demo voraus.
. "$PSScriptRoot\_common.ps1"

$id = "MANUAL-" + (Get-Random -Maximum 99999)
Write-Host "Sende Auftrag $id mit fehlenden Pflichtdaten (MANDATORY_DATA_MISSING) ..."
Submit-DocumentRequest $id "MANDATORY_DATA_MISSING" | Out-Null

Write-Host "Warte, bis die User Task erscheint ..."
$task = $null
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 2
    $t = @(Invoke-RestMethod "$Orchestrator/engine-rest/task?processInstanceBusinessKey=$id" | Where-Object { $_.id })
    if ($t.Count -ge 1) { $task = $t[0]; break }
}

if (-not $task) { Write-Host "Keine User Task erschienen." -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "User Task vorhanden: '$($task.name)'" -ForegroundColor Green
Write-Host "Naechste Schritte in Tasklist:" -ForegroundColor Cyan
Write-Host "  1. $Orchestrator/camunda  -> als 'ops' / 'ops' anmelden"
Write-Host "  2. Tasklist oeffnen, Aufgabe '$($task.name)' beanspruchen (Claim)"
Write-Host "  3. Formular pruefen: Klaerungsgrund, fehlende Pflichtfelder"
Write-Host "  4. Entscheidung waehlen:"
Write-Host "     - RETRY_ENRICHMENT (+ korrigierte E-Mail/Anschrift) -> Auftrag wird wieder vollstaendig"
Write-Host "     - CANCEL_REQUEST -> Outcome CANCELLED_AFTER_MANUAL_REVIEW"
Write-Host "     - DELIVER_REDUCED -> nur zulaessig, wenn Degradation erlaubt ist"
Write-Host ""
Write-Host "Alternativ per REST (CANCEL):"
Write-Host "  PUT $Orchestrator/engine-rest/task/$($task.id)/... (siehe requests/demo.http)"
