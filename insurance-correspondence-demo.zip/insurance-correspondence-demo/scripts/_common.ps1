# Gemeinsame Hilfsfunktionen fuer die Demo-Skripte (reines PowerShell, keine cmd.exe-Syntax).
$ErrorActionPreference = "Stop"

$script:Root = Split-Path -Parent $PSScriptRoot
$script:VarDir = Join-Path $Root "var"
$script:LogDir = Join-Path $VarDir "logs"
$script:RunDir = Join-Path $VarDir "run"
$script:Orchestrator = "http://127.0.0.1:8080"
$script:Worker = "http://127.0.0.1:8081"
$script:Simulator = "http://127.0.0.1:8082"

$script:Apps = @(
    @{ Name = "orchestrator"; Jar = "orchestrator-app\target\orchestrator-app.jar"; Health = "$Orchestrator/actuator/health" },
    @{ Name = "simulator";    Jar = "external-systems-simulator\target\external-systems-simulator.jar"; Health = "$Simulator/actuator/health" },
    @{ Name = "worker";       Jar = "worker-app\target\worker-app.jar"; Health = "$Worker/actuator/health" }
)

function Initialize-Dirs {
    foreach ($d in @($VarDir, $LogDir, $RunDir, (Join-Path $VarDir "db"), (Join-Path $VarDir "documents"), (Join-Path $VarDir "reports"))) {
        New-Item -ItemType Directory -Force -Path $d | Out-Null
    }
}

function Wait-Health([string]$Url, [int]$TimeoutSec = 120) {
    for ($i = 0; $i -lt ($TimeoutSec / 2); $i++) {
        Start-Sleep -Seconds 2
        try { if ((Invoke-RestMethod $Url -TimeoutSec 3).status -eq "UP") { return $true } } catch { }
    }
    return $false
}

function Submit-DocumentRequest([string]$DocumentJobId, [string]$FailureProfile = "HAPPY", [string]$DocumentType = "CONTRACT_CHANGE_CONFIRMATION") {
    $body = @{
        documentJobId = $DocumentJobId; sourceEventId = "evt-$DocumentJobId"; requestSource = "SINGLE_EVENT"
        documentType = $DocumentType; customerId = "C-1001"; contractId = "V-2001"
        requestedAt = "2026-06-20T08:00:00Z"; failureProfile = $FailureProfile
    } | ConvertTo-Json
    return Invoke-RestMethod -Method Post "$Orchestrator/api/document-requests" -ContentType "application/json" -Body $body
}

function Get-RequestStatus([string]$DocumentJobId) {
    try { return Invoke-RestMethod "$Orchestrator/api/document-requests/$DocumentJobId" } catch { return $null }
}

function Wait-Outcome([string]$DocumentJobId, [int]$TimeoutSec = 90) {
    for ($i = 0; $i -lt ($TimeoutSec / 2); $i++) {
        Start-Sleep -Seconds 2
        $s = Get-RequestStatus $DocumentJobId
        if ($s -and $s.outcome) { return $s.outcome }
    }
    return "(timeout)"
}

# Robuste Zaehlung: filtert $null heraus (PowerShell macht aus leerem [] sonst @($null).Count=1).
function Get-IncidentCount([string]$ProcessInstanceId) {
    return @(Invoke-RestMethod "$Orchestrator/engine-rest/incident?processInstanceId=$ProcessInstanceId" | Where-Object { $_.id }).Count
}
