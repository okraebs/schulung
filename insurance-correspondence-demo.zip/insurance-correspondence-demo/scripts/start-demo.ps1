# Startet Orchestrator, Simulator und Worker in getrennten Prozessen, schreibt PID-Dateien und Logs
# unter var/logs und wartet auf die Health Checks (Auftrag 19.3).
. "$PSScriptRoot\_common.ps1"
Initialize-Dirs

foreach ($app in $Apps) {
    $jar = Join-Path $Root $app.Jar
    if (-not (Test-Path $jar)) { Write-Host "Jar fehlt: $jar – zuerst build.ps1 ausfuehren." -ForegroundColor Red; exit 1 }
    $p = Start-Process -FilePath "java" -ArgumentList @("-jar", $jar) -WorkingDirectory $Root `
        -RedirectStandardOutput (Join-Path $LogDir "$($app.Name).out.log") `
        -RedirectStandardError  (Join-Path $LogDir "$($app.Name).err.log") -PassThru
    $p.Id | Out-File (Join-Path $RunDir "$($app.Name).pid")
    Write-Host "$($app.Name) gestartet (PID $($p.Id))"
}

Write-Host "Warte auf Health Checks ..."
$allUp = $true
foreach ($app in $Apps) {
    $up = Wait-Health $app.Health 120
    Write-Host ("  {0}: {1}" -f $app.Name, $(if ($up) { "UP" } else { "NICHT ERREICHBAR" }))
    if (-not $up) { $allUp = $false }
}

if ($allUp) {
    Write-Host "Demo laeuft. Cockpit/Tasklist: $Orchestrator/camunda  (demo/demo, ops/ops)" -ForegroundColor Green
} else {
    Write-Host "Mindestens ein Dienst ist nicht hochgekommen – siehe var/logs." -ForegroundColor Red; exit 1
}
