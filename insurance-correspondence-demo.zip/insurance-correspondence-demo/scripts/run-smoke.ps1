# Vollstaendiger Happy Path: erzeugt einen Auftrag und prueft Status sowie PDF-Datei (Auftrag 19.6).
# Setzt eine laufende Demo voraus (start-demo.ps1).
. "$PSScriptRoot\_common.ps1"

$id = "SMOKE-" + (Get-Random -Maximum 99999)
Write-Host "Sende Happy-Path-Auftrag $id ..."
Submit-DocumentRequest $id "HAPPY" | Out-Null
$outcome = Wait-Outcome $id 90
Write-Host "Outcome: $outcome"

$pdf = Join-Path $VarDir "documents\$id\document.pdf"
$pdfOk = $false
if (Test-Path $pdf) {
    $bytes = [System.IO.File]::ReadAllBytes($pdf)
    $sig = [System.Text.Encoding]::ASCII.GetString($bytes[0..4])
    $pdfOk = ($sig -eq "%PDF-")
    Write-Host "PDF: $pdf ($($bytes.Length) Bytes, Signatur $sig)"
} else {
    Write-Host "PDF nicht gefunden: $pdf" -ForegroundColor Yellow
}

if ($outcome -eq "FULLY_DISPATCHED" -and $pdfOk) { Write-Host "SMOKE OK." -ForegroundColor Green }
else { Write-Host "SMOKE FEHLGESCHLAGEN." -ForegroundColor Red; exit 1 }
