# Prueft Java 17, javac, Git, Maven/Wrapper und die Ports 8080-8082. Veraendert nichts global.
. "$PSScriptRoot\_common.ps1"

Write-Host "== Setup-Check ==" -ForegroundColor Cyan
$ok = $true

function Check([string]$label, [scriptblock]$test) {
    try { $r = & $test; Write-Host ("[ OK ] {0}: {1}" -f $label, $r) }
    catch { Write-Host ("[FAIL] {0}: {1}" -f $label, $_.Exception.Message) -ForegroundColor Red; $script:ok = $false }
}

Check "Java" { $v = (java -version 2>&1)[0]; if ($v -notmatch '17\.') { throw "Java 17 erwartet: $v" }; $v }
Check "javac" { $v = (javac -version 2>&1); if ($v -notmatch '17\.') { throw "javac 17 erwartet: $v" }; $v }
Check "Git" { (git --version) }
Check "Maven Wrapper" { if (Test-Path "$Root\mvnw.cmd") { "mvnw.cmd vorhanden" } else { throw "mvnw.cmd fehlt" } }

foreach ($port in 8080, 8081, 8082) {
    $busy = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if ($busy) { Write-Host "[WARN] Port $port belegt (PID $($busy.OwningProcess))" -ForegroundColor Yellow }
    else { Write-Host "[ OK ] Port $port frei" }
}

if ($ok) { Write-Host "Setup-Check bestanden." -ForegroundColor Green }
else { Write-Host "Setup-Check mit Fehlern." -ForegroundColor Red; exit 1 }
