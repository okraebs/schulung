# FINAL_REPORT — insurance-correspondence-demo

Camunda-7-Demoanwendung für Versicherungskorrespondenz. Stand: 2026-06-20.
Alle hier genannten Ergebnisse wurden tatsächlich ausgeführt (keine unbelegten Aussagen).

## Implementierter Umfang
Vollständige 10-Phasen-Umsetzung (Phasen 0–9), siehe `IMPLEMENTATION_STATUS.md`:
- Maven-Multi-Modul-Projekt (5 Module), Maven Wrapper 3.9.16, Enforcer (Java 17 / Maven [3.9,4)),
  Spotless (palantir-java-format), JaCoCo.
- Orchestrator (Camunda 7.24, Webapps, REST, persistentes H2, demo/ops, Inbox via Flyway/JPA).
- Worker (External Task Client, OpenPDF, Delivery-Outbox via Flyway/JPA, Reconcile).
- Simulator (Quellsysteme + Output-Management, deterministische Fehlerprofile, async Callback).
- Load-Generator (CLI event/batch/mixed, Perzentile).
- Kernprozess `document_fulfillment` (Message Start, External Tasks, 3 DMN, asyncBefore, User Task,
  Receive Task + interrupting Timer + Reconcile-Loop, finales Outcome).
- Batch-Planer `document_batch_planner` (Timer-/REST-Start, Backpressure, seitenweise Veröffentlichung).

## Architekturentscheidungen
Siehe `docs/adr/ADR-001..007`. Kern: Camunda orchestriert, External Tasks für I/O; eine Instanz pro
Dokument; keine Binär-Prozessvariablen; manuelle Klärung statt blindem Versenden; Konsistenz über
Idempotenz/Outbox/Inbox/Reconciliation; H2 (demo) vs. PostgreSQL (Last).

## Startbefehle
```powershell
.\scripts\setup-check.ps1
.\scripts\build.ps1            # .\mvnw.cmd clean verify
.\scripts\start-demo.ps1       # 8080 / 8081 / 8082
.\scripts\run-smoke.ps1
.\scripts\stop-demo.ps1
```

## Demo-Zugangsdaten (nur Demo-Profil, nicht produktionsgeeignet)
- `demo` / `demo` (administrativ) · `ops` / `ops` (Gruppe `document-ops`).
- Webapps: http://127.0.0.1:8080/camunda · Bindung nur 127.0.0.1.

## Ausgeführte Tests und Ergebnisse
- **`.\mvnw.cmd clean verify` (voller Reactor): BUILD SUCCESS.** Enthält u. a.:
  - shared-contracts: Validierung/Fixtures.
  - DMN-Tests (parametrisiert): data-completeness (inkl. FIRST-Vorrang/Default), variant, policy.
  - BPMN-Prozesstests: FULLY_DISPATCHED, DEGRADED_DISPATCHED, MANUAL→User-Task,
    Cancel→CANCELLED_AFTER_MANUAL_REVIEW, Retry→FULLY, DELIVER_REDUCED (erlaubt/abgelehnt),
    Duplicate-Callback (ein Fortschritt), Timeout→Reconcile-Loop→Accept, Rejection→User-Task.
  - Worker: echtes PDF + SHA-256 + Pfadsicherheit; Outbox-/Render-Idempotenz.
  - Simulator-Integration; Load-Metrics-Perzentile.
- **Realer End-to-End-Nachweis über die Skripte (laufende Apps):**
  - `run-smoke` → **FULLY_DISPATCHED**, echtes PDF (`%PDF-`, ~1,3 KB).
  - `failureProfile=OPTIONAL_DATA_MISSING` → **DEGRADED_DISPATCHED**.
  - `run-manual-review-demo` → User Task „Dokumentauftrag manuell klären: <id>" in Tasklist;
    CANCEL→CANCELLED, RETRY+Korrektur→FULLY (real via Engine-REST geprüft).
  - `run-incident-demo -AutoFix` → reproduzierbarer **Incident** (Zähler `documents.incidents`,
    Engine-Incident), nach Fix (Ursache + Retries) **FULLY_DISPATCHED**, verbleibende Incidents 0.
  - `run-restart-demo` → Auftrag wartet an der Receive Task, **Orchestrator-Neustart**, Zustand
    `ACTIVE` überlebt, gepufferter Callback → **FULLY_DISPATCHED**. Analog überlebt eine User Task.
  - `run-load -Count 20` → Batch-Bilanz **konsistent** (started=20, active=0, fully=20);
    Load-Generator 20/20 akzeptiert, 0 Dubletten, 0 HTTP-Fehler, ~3/s, p50≈24 ms.

## Ausgeführte Lastversuche
Kleiner Last-Smoke (Batch 20 + Event 20) in dieser Umgebung erfolgreich, konsistente Bilanz.
Ein großer 20.000–30.000er-Lauf wurde **nicht** ausgeführt (kein PostgreSQL/Docker vorhanden); der
Load-Generator und das `postgres`/`load`-Profil sind dafür vollständig vorbereitet
(`docs/load-test.md`).

## Security-Review (Auftrag 21)
- Enforcer für Java-/Maven-Mindestversionen; feste Dependency-Versionen (keine `latest`).
- Bean Validation an REST-Eingaben; RFC-7807-ähnliche Fehlerantworten (`spring.mvc.problemdetails`).
- Endliche Connect-/Read-Timeouts für alle HTTP-Clients (Worker→Simulator, Worker→Orchestrator,
  Simulator→Orchestrator).
- Pfad-/Dateinamen-Normalisierung; `documentJobId` kann keinen Pfadausbruch erzeugen (getestet).
- Keine Secrets/Tokens/DBs in Git (`.gitignore`); PostgreSQL-Zugangsdaten nur aus Umgebungsvariablen.
- Nur synthetische Daten; Logs ohne vollständige PII (MDC nur mit IDs).
- Keine sensiblen Actuator-Endpunkte exponiert (nur health/info/metrics/prometheus).

## Bekannte Einschränkungen / nicht ausgeführte optionale Punkte
- Großer 30.000er-Lastlauf (s. o.), nur vorbereitet.
- Webapp-Authorization im Demo-Profil bewusst nicht hart erzwungen (Login funktioniert; produktiv
  würde Authorization feingranular aktiviert).
- `document-variant.dmn` nutzt documentType+language; Produkt/Bundesland sind als Übung angelegt.
- Compensation ist bewusst kein Hauptmechanismus (kleine optionale Übung).
- Worker loggt beim Start eine harmlose Warnung „no Bean Validation provider" (er validiert keine
  REST-Eingaben).

## Hinweise für die erste Vorführung
1. `setup-check.ps1` → `build.ps1` → `start-demo.ps1` (Health grün abwarten).
2. Reihenfolge wie im Trainerleitfaden: Smoke → Degradation → User Task → Incident → Restart → Batch.
3. Bei wiederholten Demos ggf. `reset-demo.ps1 -Force` (löscht nur projektlokale `var`-Daten).
4. Cockpit/Tasklist sind die primären Oberflächen; `/api/demo/summary` liefert eine schnelle Bilanz.
