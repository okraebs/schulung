package de.training.camunda;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/**
 * Zahlung innerhalb des Transaction-Subprozesses.
 *
 * - technischerFehler=true  -> wirft einen BpmnError (KEINE technische Exception!).
 *   Der BpmnError ist ein BPMN-Steuersignal und wird vom Error-Boundary-Event am
 *   Transaction-Rahmen gefangen -> KEINE Kompensation (Kontrast zu Cancel).
 * - sonst                   -> setzt bezahlt=true (Geld ist raus, muss bei Storno
 *   kompensiert werden).
 *
 * errorCode "ZAHLUNG_TECHNISCH" muss exakt zur bpmn:error errorCode im Modell passen.
 */
public class ZahlungTxDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {
        Boolean fehler = (Boolean) execution.getVariable("technischerFehler");
        System.out.println(">> Zahlung anweisen (TX) | Thread: " + Thread.currentThread().getName()
            + " | ProcessInstanceId: " + execution.getProcessInstanceId());

        if (Boolean.TRUE.equals(fehler)) {
            throw new BpmnError("ZAHLUNG_TECHNISCH", "Zahlungssystem technisch nicht verfuegbar (simuliert)");
        }
        execution.setVariable("bezahlt", true);
    }
}
