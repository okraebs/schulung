package de.training.camunda;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/**
 * Zahlt den Schaden aus - oder wirft eine Exception, wenn fehlerBeiZahlung=true.
 * Simuliert z.B. einen nicht erreichbaren Zahlungs-Provider.
 *
 * Wegen async before/after laeuft diese Aktivitaet (im async-Modell) in einer EIGENEN
 * Transaktion. Bei der Exception wird NUR diese Transaktion zurueckgerollt und der Job
 * gemaess R3/PT10S erneut versucht; danach entsteht ein Incident.
 */
public class ZahlungAnweisenDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {
        Boolean fehler = (Boolean) execution.getVariable("fehlerBeiZahlung");
        System.out.println(">> Zahlung anweisen | Thread: " + Thread.currentThread().getName()
            + " | ProcessInstanceId: " + execution.getProcessInstanceId());

        if (Boolean.TRUE.equals(fehler)) {
            throw new RuntimeException("Zahlungs-Gateway nicht erreichbar (simulierter Fehler)");
        }
        execution.setVariable("bezahlt", true);
    }
}
