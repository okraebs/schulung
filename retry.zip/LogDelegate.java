package de.training.camunda;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/**
 * Harmlose Service-Logik. Loggt Aktivitaet, Thread und Transaktions-Info.
 * Am Thread-Namen sieht man, ob die Aktivitaet synchron (Aufrufer-Thread)
 * oder asynchron (Job-Executor-Thread) laeuft.
 */
public class LogDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {
        System.out.println(">> Aktivitaet: " + execution.getCurrentActivityName()
            + " | Thread: " + Thread.currentThread().getName()
            + " | ProcessInstanceId: " + execution.getProcessInstanceId());
    }
}
