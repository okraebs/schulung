package de.training.camunda;

import java.util.concurrent.ConcurrentHashMap;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/**
 * TECHNISCHE Retries (JobExecutor + camunda:failedJobRetryTimeCycle).
 *
 * technVerhalten:
 *   "ok"        -> Erfolg beim 1. Versuch.
 *   "dauerhaft" -> wirft IMMER eine RuntimeException -> Retries laut DMN-Zyklus
 *                  erschoepft -> Incident.
 *   "transient" -> schlaegt die ersten TRANSIENT_FEHLVERSUCHE Versuche fehl, dann Erfolg
 *                  (der JobExecutor wiederholt und faengt sich selbst -> kein Incident).
 *
 * WICHTIG (Retry-Lehre): Der Versuchszaehler liegt in einem STATISCHEN, nicht-transaktionalen
 * Speicher. Eine Prozessvariable wuerde bei jedem fehlgeschlagenen Job ZURUECKGEROLLT
 * (die ganze Transaktion macht Rollback) -> der Zaehler bliebe ewig bei 1.
 */
public class PartneruebermittlungDelegate implements JavaDelegate {

    private static final ConcurrentHashMap<String, Integer> VERSUCHE = new ConcurrentHashMap<>();
    // 1 Fehlversuch, dann Erfolg beim 2. Versuch -> erholt sich innerhalb JEDES DMN-Budgets
    // (kleinster Zyklus ist R2 = 2 Ausfuehrungen). Vermeidet Off-by-one-Incidents.
    private static final int TRANSIENT_FEHLVERSUCHE = 1;

    @Override
    public void execute(DelegateExecution execution) {
        String verhalten = (String) execution.getVariable("technVerhalten");
        String piid = execution.getProcessInstanceId();
        int versuch = VERSUCHE.merge(piid, 1, Integer::sum);

        System.out.println(">> An Partnersystem uebermitteln | Versuch " + versuch
            + " | technVerhalten=" + verhalten
            + " | Thread: " + Thread.currentThread().getName()
            + " | ProcessInstanceId: " + piid);

        if ("dauerhaft".equals(verhalten)) {
            throw new RuntimeException("Partnersystem dauerhaft nicht erreichbar (simuliert) - Versuch " + versuch);
        }
        if ("transient".equals(verhalten) && versuch <= TRANSIENT_FEHLVERSUCHE) {
            throw new RuntimeException("Partnersystem temporaer nicht erreichbar (simuliert) - Versuch " + versuch);
        }

        execution.setVariable("uebermittelt", true);
        execution.setVariable("technVersuche", versuch);
        VERSUCHE.remove(piid);
        System.out.println(">> Uebermittlung ERFOLG nach Versuch " + versuch + " | ProcessInstanceId: " + piid);
    }
}
