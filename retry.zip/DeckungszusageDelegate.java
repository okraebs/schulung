package de.training.camunda;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/**
 * FACHLICHE Retries (Schleife im BPMN mit Zaehler + Timer + Eskalation).
 *
 * Erhoeht den Zaehler fachVersuch als PROZESSVARIABLE. Das ist hier korrekt, weil dieser
 * Task ERFOLGREICH committet (kein technischer Fehler) - im Gegensatz zur technischen
 * Retry-Seite, wo ein Variablen-Zaehler vom Rollback aufgefressen wuerde.
 *
 * fachVerhalten:
 *   "ok"         -> Antwort beim 1. Versuch.
 *   "retry"      -> Antwort ab dem 2. Versuch (eine fachliche Wiederholung noetig).
 *   "eskalation" -> nie eine Antwort -> Schleife laeuft bis maxVersuche -> Eskalation.
 */
public class DeckungszusageDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        String verhalten = (String) execution.getVariable("fachVerhalten");
        Integer vorher = (Integer) execution.getVariable("fachVersuch");
        int versuch = (vorher == null ? 0 : vorher) + 1;
        execution.setVariable("fachVersuch", versuch);

        boolean antwort;
        if ("ok".equals(verhalten)) {
            antwort = true;
        } else if ("retry".equals(verhalten)) {
            antwort = versuch >= 2;
        } else { // "eskalation"
            antwort = false;
        }
        execution.setVariable("antwortErhalten", antwort);

        System.out.println(">> Deckungszusage einholen | fachVersuch " + versuch
            + " | fachVerhalten=" + verhalten
            + " | antwortErhalten=" + antwort
            + " | Thread: " + Thread.currentThread().getName()
            + " | ProcessInstanceId: " + execution.getProcessInstanceId());
    }
}
