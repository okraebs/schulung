package org.camunda.bpm.getstarted.loanapproval.worker;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * EXTERNAL TASK (External Task Worker)
 * ----------------------------------------------------------------------------
 * Anders als beim Delegate fuehrt die Engine hier KEINEN Code selbst aus.
 * Stattdessen markiert die Engine den Service-Task nur als "wartend" und legt
 * ihn unter einem TOPIC ab. Ein eigenstaendiger Worker (dieser Client) holt die
 * Aufgabe aktiv ab (fetch & lock), erledigt die Arbeit und meldet das Ergebnis
 * zurueck (complete).
 *
 * Das Muster entkoppelt Engine und Arbeit:
 *   - Der Worker kann in einer anderen Anwendung, einem anderen Prozess oder
 *     sogar einer anderen Programmiersprache laufen.
 *   - Lastspitzen, langlaufende oder fehleranfaellige Aufrufe (z. B. ein
 *     externer Zahlungsdienst) belasten die Engine nicht.
 *   - Mehrere Worker-Instanzen koennen dasselbe Topic parallel abarbeiten.
 *
 * Verdrahtung:
 *   - Im BPMN:  camunda:type="external" camunda:topic="charge-payment"
 *   - Hier:     @ExternalTaskSubscription("charge-payment") abonniert das Topic.
 *   - Der Client (siehe application.yaml -> camunda.bpm.client) pollt die
 *     Engine ueber die REST-API.
 */
@Component
@ExternalTaskSubscription("charge-payment")
public class ChargePaymentWorker implements ExternalTaskHandler {

  private static final Logger LOG = LoggerFactory.getLogger(ChargePaymentWorker.class);

  /**
   * Wird vom Client aufgerufen, sobald eine Aufgabe des Topics
   * "charge-payment" abgeholt und gesperrt wurde.
   *
   * @param externalTask        gesperrte Aufgabe inkl. Prozessvariablen
   * @param externalTaskService API, um die Aufgabe abzuschliessen oder einen
   *                            Fehler/Bpmn-Error zu melden
   */
  @Override
  public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
    // Eingangsvariable lesen (kommt z. B. aus dem vorigen Delegate-Schritt).
    Number totalPrice = externalTask.getVariable("totalPrice");
    double amount = (totalPrice != null) ? totalPrice.doubleValue() : 0.0;

    // ---- Hier wuerde der echte Aufruf des Zahlungsdienstleisters stehen ----
    // Zur Demonstration erzeugen wir nur eine Pseudo-Zahlungsreferenz.
    String paymentId = "PAY-" + externalTask.getProcessInstanceId().substring(0, 8);

    // Ergebnis-Variablen, die an die Engine zurueckfliessen.
    Map<String, Object> result = new HashMap<>();
    result.put("paymentId", paymentId);
    result.put("paymentStatus", "CONFIRMED");
    result.put("chargedAmount", amount);

    // complete() schliesst den External Task ab -> das Prozess-Token laeuft
    // im BPMN weiter. (Bei Fehlern gaebe es handleFailure() / handleBpmnError().)
    externalTaskService.complete(externalTask, result);

    LOG.info("[ExternalTask] Zahlung eingezogen: {} ueber {} (Topic '{}', ProcessInstance {})",
        paymentId, amount, externalTask.getTopicName(), externalTask.getProcessInstanceId());
  }
}
