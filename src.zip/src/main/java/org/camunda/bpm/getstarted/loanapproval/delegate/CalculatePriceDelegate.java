package org.camunda.bpm.getstarted.loanapproval.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * DELEGATE TASK (Java Delegate)
 * ----------------------------------------------------------------------------
 * Ein JavaDelegate ist Code, der DIREKT IN DER PROZESS-ENGINE laeuft, also im
 * selben Thread/Transaktion wie der Prozessfortschritt. Sobald das Token den
 * Service-Task erreicht, ruft die Engine synchron die Methode execute() auf.
 *
 * Eingebunden wird die Klasse im BPMN ueber:
 *     camunda:delegateExpression="${calculatePriceDelegate}"
 * Der Ausdruck ${...} verweist auf einen Spring-Bean-Namen. Durch die
 * Annotation @Component("calculatePriceDelegate") registriert Spring genau
 * diesen Bean, und Camunda loest ihn beim Ausfuehren auf.
 *
 * Typischer Einsatz: kurze, schnelle, transaktionale Logik (Berechnungen,
 * Variablen setzen, internen Service-Aufruf). Fuer langlaufende oder in einer
 * anderen Technologie/Sprache umgesetzte Arbeit ist der EXTERNAL TASK besser
 * geeignet (siehe ChargePaymentWorker).
 */
@Component("calculatePriceDelegate")
public class CalculatePriceDelegate implements JavaDelegate {

  private static final Logger LOG = LoggerFactory.getLogger(CalculatePriceDelegate.class);

  @Override
  public void execute(DelegateExecution execution) {
    // Prozessvariablen lesen. Wir lesen sie als Number, damit es egal ist, ob
    // sie z. B. ueber die REST-API als Integer, Long oder Double ankommen.
    Number quantityVar = (Number) execution.getVariable("quantity");
    Number unitPriceVar = (Number) execution.getVariable("unitPrice");

    // Sinnvolle Defaults, falls der Prozess ohne Variablen gestartet wurde.
    int quantity = (quantityVar != null) ? quantityVar.intValue() : 1;
    double unitPrice = (unitPriceVar != null) ? unitPriceVar.doubleValue() : 9.99;

    // Eigentliche "Geschaeftslogik": Gesamtpreis berechnen.
    double totalPrice = quantity * unitPrice;

    // Ergebnis als Prozessvariable zuruckschreiben. Nachfolgende Schritte
    // (z. B. der External Task) koennen darauf zugreifen.
    execution.setVariable("totalPrice", totalPrice);

    LOG.info("[Delegate] Preis berechnet: {} x {} = {} (ProcessInstance {})",
        quantity, unitPrice, totalPrice, execution.getProcessInstanceId());
  }
}
